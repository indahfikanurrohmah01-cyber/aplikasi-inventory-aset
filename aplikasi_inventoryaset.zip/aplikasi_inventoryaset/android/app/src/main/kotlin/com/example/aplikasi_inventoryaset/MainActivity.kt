package com.example.aplikasi_inventoryaset

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
