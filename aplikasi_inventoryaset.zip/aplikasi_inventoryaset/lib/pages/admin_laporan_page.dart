import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'background_wrapper.dart';
import '../utils/placeholder_page.dart';
import 'user_dashboard_page.dart';
import 'daftar_barang_user_page.dart';
import 'status_permintaan_page.dart';
import 'pengaturan_profile_user.dart';

class AdminLaporanPage extends StatefulWidget {
  final String userId;
  const AdminLaporanPage({super.key, required this.userId});

  @override
  State<AdminLaporanPage> createState() => _AdminLaporanPageState();
}

class _AdminLaporanPageState extends State<AdminLaporanPage> {
  List<Map<String, dynamic>> _laporanList = [];
  bool _isLoading = true;
  String _errorMessage = '';
  String _adminName = 'Admin';

  @override
  void initState() {
    super.initState();
    _fetchLaporanAdmin();
    _loadAdminName();
  }

  Future<void> _loadAdminName() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    setState(() {
      _adminName = prefs.getString('user_name') ?? 'Admin';
    });
  }

  Future<void> _fetchLaporanAdmin() async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });

    final url = Uri.parse('http://localhost/api_inventory/get_all_laporan_user.php');

    try {
      final response = await http.get(url);
      if (mounted) {
        if (response.statusCode == 200) {
          final Map<String, dynamic> data = json.decode(response.body);
          if (data['success'] == true && data.containsKey('laporan') && data['laporan'] is List) {
            setState(() {
              _laporanList = List<Map<String, dynamic>>.from(data['laporan']);
              _isLoading = false;
              _errorMessage = '';
            });
          } else {
            setState(() {
              _isLoading = false;
              _errorMessage = data['message'] ?? 'Data laporan tidak valid atau API gagal.';
            });
          }
        } else {
          setState(() {
            _isLoading = false;
            _errorMessage = 'Gagal memuat laporan. Status: ${response.statusCode}';
          });
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Error fetching laporan: $e';
        });
      }
    }
  }

  Future<void> _updateLaporanStatus(String laporanId, String newStatus) async {
    setState(() {
      _isLoading = true;
    });
    final url = Uri.parse('http://localhost/api_inventory/update_status_laporan.php');

    try {
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'id': laporanId,
          'status': newStatus,
        }),
      );

      if (mounted) {
        if (response.statusCode == 200) {
          final result = json.decode(response.body);
          if (result['status'] == 'success') {
            _showSnackBar(result['message'] ?? 'Status laporan berhasil diperbarui!');
            await _fetchLaporanAdmin();
          } else {
            _showSnackBar(result['message'] ?? 'Gagal memperbarui status laporan.', isError: true);
          }
        } else {
          _showSnackBar('HTTP Error: ${response.statusCode}', isError: true);
        }
      }
    } catch (e) {
      if (mounted) {
        _showSnackBar('Terjadi kesalahan: $e', isError: true);
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red[600] : Colors.green[600],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'diterima':
        return Colors.green;
      case 'ditolak':
        return Colors.red;
      case 'diproses':
        return Colors.blue;
      case 'pending':
      default:
        return Colors.orange;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'diterima':
        return Icons.check_circle;
      case 'ditolak':
        return Icons.cancel;
      case 'diproses':
        return Icons.hourglass_full;
      case 'pending':
      default:
        return Icons.pending;
    }
  }

  String _formatDate(String? dateString) {
    if (dateString == null) return 'N/A';
    try {
      final dateTime = DateTime.parse(dateString);
      return DateFormat('dd MMMM yyyy, HH:mm').format(dateTime);
    } catch (e) {
      return dateString;
    }
  }

  Future<void> _handleLogout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Konfirmasi Logout'),
        content: const Text('Apakah Anda yakin ingin keluar?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(context, true), style: TextButton.styleFrom(foregroundColor: Colors.red), child: const Text('Logout')),
        ],
      ),
    );
    if (confirm == true && mounted) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      Navigator.pushReplacementNamed(context, '/');
    }
  }

  void _navigate(String route, String title) {
    Navigator.pop(context);
    if (route == '/admin-laporan') {
      return;
    }
    if (route == '/dashboard') {
      Navigator.pushReplacementNamed(context, '/dashboard');
    } else if (route == '/daftar-barang') {
      Navigator.pushReplacementNamed(context, '/daftar-barang');
    } else if (route == '/daftar-ruangan') {
      Navigator.pushReplacementNamed(context, '/daftar-ruangan');
    } else if (route == '/daftar-pengguna') {
      Navigator.pushReplacementNamed(context, '/daftar-pengguna');
    } else if (route == '/daftar-perolehan') {
      Navigator.pushReplacementNamed(context, '/daftar-perolehan');
    } else if (route == '/pengaturan-profile') {
      Navigator.pushReplacementNamed(context, '/pengaturan-profile');
    } else if (route == '/peran-hak-akses') {
      Navigator.pushReplacementNamed(context, '/peran-hak-akses');
    } else {
      Navigator.push(
        context,
        MaterialPageRoute(builder: (_) => PlaceholderPage(title: title)),
      );
    }
  }

  // Updated drawer with complete menu structure
  Drawer _buildDrawer() => Drawer(
    child: SafeArea(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          _drawerHeader(),
          _drawerItem(Icons.dashboard_outlined, 'Dashboard', false, () => _navigate('/dashboard', 'Dashboard')),
          const SizedBox(height: 8),
          _drawerSection('MANAJEMEN'),
          _drawerItem(Icons.inventory_2_outlined, 'Data Barang', false, () => _navigate('/daftar-barang', 'Data Barang')),
          _drawerItem(Icons.build_outlined, 'Daftar Perolehan', false, () => _navigate('/daftar-perolehan', 'Daftar Perolehan')),
          _drawerItem(Icons.meeting_room_outlined, 'Data Ruangan', false, () => _navigate('/daftar-ruangan', 'Data Ruangan')),
          _drawerItem(Icons.people_outline, 'Data Pengguna', false, () => _navigate('/daftar-pengguna', 'Data Pengguna')),
          _drawerItem(Icons.bar_chart_outlined, 'Laporan', true, () => _navigate('/admin-laporan', 'Laporan')),
          const SizedBox(height: 16),
          _drawerItem(Icons.person_outline, 'Pengaturan Profile', false, () => _navigate('/pengaturan-profile', 'Pengaturan Profile')),
          _drawerItem(Icons.admin_panel_settings_outlined, 'Peran & Hak Akses', false, () => _navigate('/peran-hak-akses', 'Peran & Hak Akses')),
          const SizedBox(height: 24),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: ElevatedButton.icon(
              onPressed: _handleLogout,
              icon: const Icon(Icons.logout, color: Colors.white),
              label: const Text('Logout', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red[600],
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 12),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                elevation: 2,
              ),
            ),
          ),
          const SizedBox(height: 16),
        ],
      ),
    ),
  );

  Widget _drawerHeader() => Container(
    height: 140,
    decoration: BoxDecoration(
      gradient: LinearGradient(
        colors: [Colors.blue[700]!, Colors.blue[500]!],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      ),
    ),
    child: const Padding(
      padding: EdgeInsets.all(20.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'INVENTRIS',
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: 28,
              letterSpacing: 1.2,
            ),
          ),
          SizedBox(height: 4),
          Text(
            'Sistem Manajemen Inventaris',
            style: TextStyle(
              color: Colors.white70,
              fontSize: 14,
              fontWeight: FontWeight.w400,
            ),
          ),
        ],
      ),
    ),
  );

  Widget _drawerSection(String title) => Padding(
    padding: const EdgeInsets.fromLTRB(20, 16, 16, 8),
    child: Text(
      title,
      style: TextStyle(
        fontSize: 12,
        fontWeight: FontWeight.w600,
        color: Colors.grey[600],
        letterSpacing: 0.5,
      ),
    ),
  );

  Widget _drawerItem(IconData icon, String title, bool active, VoidCallback onTap) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
    decoration: BoxDecoration(
      color: active ? Colors.blue[50] : Colors.transparent,
      borderRadius: BorderRadius.circular(8),
    ),
    child: ListTile(
      leading: Icon(
        icon,
        color: active ? Colors.blue[600] : Colors.grey[600],
        size: 22,
      ),
      title: Text(
        title,
        style: TextStyle(
          color: active ? Colors.blue[600] : Colors.grey[800],
          fontWeight: active ? FontWeight.w600 : FontWeight.w400,
          fontSize: 15,
        ),
      ),
      onTap: onTap,
      dense: true,
      visualDensity: VisualDensity.compact,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
    ),
  );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text('Manajemen Laporan', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              children: [
                Text(
                  'Halo, $_adminName',
                  style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
                ),
                const SizedBox(width: 8),
                TextButton(
                  onPressed: _handleLogout,
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.zero,
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: const Text(
                    'Logout',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: GradientBackgroundWrapper(
        child: RefreshIndicator(
          onRefresh: _fetchLaporanAdmin,
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _errorMessage.isNotEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.error_outline, color: Colors.red, size: 50),
                            const SizedBox(height: 10),
                            Text(_errorMessage, textAlign: TextAlign.center),
                            const SizedBox(height: 20),
                            ElevatedButton(
                              onPressed: _fetchLaporanAdmin,
                              child: const Text('Coba Lagi'),
                            ),
                          ],
                        ),
                      ),
                    )
                  : _laporanList.isEmpty
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.info_outline, size: 50, color: Colors.grey),
                              SizedBox(height: 10),
                              Text('Belum ada laporan yang diajukan.'),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: _laporanList.length,
                          itemBuilder: (context, index) {
                            final laporan = _laporanList[index];
                            final status = laporan['status'] ?? 'pending';
                            final statusColor = _getStatusColor(status);
                            final statusIcon = _getStatusIcon(status);
                            return Card(
                              elevation: 3,
                              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              child: InkWell(
                                onTap: () {
                                  _showStatusActionDialog(laporan);
                                },
                                borderRadius: BorderRadius.circular(12),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              laporan['nama_barang'] ?? 'Nama Barang Tidak Diketahui',
                                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                            decoration: BoxDecoration(
                                              color: statusColor.withOpacity(0.1),
                                              borderRadius: BorderRadius.circular(8),
                                            ),
                                            child: Row(
                                              mainAxisSize: MainAxisSize.min,
                                              children: [
                                                Icon(statusIcon, size: 16, color: statusColor),
                                                const SizedBox(width: 4),
                                                Text(
                                                  status.toUpperCase(),
                                                  style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 12),
                                                ),
                                              ],
                                            ),
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        'Pelapor: ${laporan['nama_user'] ?? 'Tidak Diketahui'}',
                                        style: TextStyle(color: Colors.grey[600], fontSize: 13),
                                      ),
                                      const SizedBox(height: 4),
                                      Text(
                                        laporan['deskripsi'] ?? 'Tidak ada deskripsi.',
                                        style: TextStyle(color: Colors.grey[700], fontSize: 14),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 8),
                                      Row(
                                        children: [
                                          const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                                          const SizedBox(width: 4),
                                          Text(
                                            _formatDate(laporan['tanggal_lapor']),
                                            style: TextStyle(color: Colors.grey[600], fontSize: 12),
                                          ),
                                          const Spacer(),
                                          Text(
                                            'Tap untuk aksi',
                                            style: TextStyle(color: Colors.grey[500], fontSize: 11, fontStyle: FontStyle.italic),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
        ),
      ),
    );
  }

  void _showStatusActionDialog(Map<String, dynamic> laporan) {
    if (!mounted) return;
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text('Aksi Laporan: ${laporan['nama_barang']}'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Status Saat Ini: ${laporan['status'] ?? 'Pending'}'),
              const SizedBox(height: 16),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  _updateLaporanStatus(laporan['id'].toString(), 'diterima');
                },
                icon: const Icon(Icons.check_circle, color: Colors.white),
                label: const Text('Setujui Laporan', style: TextStyle(color: Colors.white)),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.green),
              ),
              const SizedBox(height: 8),
              ElevatedButton.icon(
                onPressed: () {
                  Navigator.pop(context);
                  _updateLaporanStatus(laporan['id'].toString(), 'ditolak');
                },
                icon: const Icon(Icons.cancel, color: Colors.white),
                label: const Text('Tolak Laporan', style: TextStyle(color: Colors.white)),
                style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: const Text('Tutup'),
            ),
          ],
        );
      },
    );
  }
}
