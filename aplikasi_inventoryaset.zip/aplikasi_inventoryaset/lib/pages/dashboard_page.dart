import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'package:fl_chart/fl_chart.dart';
import 'detail_barang_page.dart';
import 'admin_laporan_page.dart';
import 'background_wrapper.dart'; // Import background wrapper
import '../utils/placeholder_page.dart'; // Import PlaceholderPage

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  List<Map<String, dynamic>> kondisiData = [];
  List<Map<String, dynamic>> tahunData = [];
  List<Map<String, dynamic>> barangMahal = [];
  List<Map<String, dynamic>> materialData = [];
  List<Map<String, dynamic>> merkData = [];
  bool isLoading = true;
  String errorMessage = '';
  String searchQuery = '';
  DateTime? startDate;
  DateTime? endDate;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchAllData();
  }

  Future<void> fetchAllData() async {
    try {
      final kondisiRes = await http.get(Uri.parse('http://localhost/api_inventory/get_barang_by_kondisi.php'));
      final tahunRes = await http.get(Uri.parse('http://localhost/api_inventory/get_barang_by_tahun.php'));
      final mahalRes = await http.get(Uri.parse('http://localhost/api_inventory/get_barang_termahal.php'));
      final materialRes = await http.get(Uri.parse('http://localhost/api_inventory/get_barang_by_material.php'));
      final merkRes = await http.get(Uri.parse('http://localhost/api_inventory/get_barang_by_merk.php'));

      setState(() {
        kondisiData = List<Map<String, dynamic>>.from(json.decode(kondisiRes.body)['data']);
        tahunData = List<Map<String, dynamic>>.from(json.decode(tahunRes.body)['data']);
        barangMahal = List<Map<String, dynamic>>.from(json.decode(mahalRes.body)['data']);
        materialData = List<Map<String, dynamic>>.from(json.decode(materialRes.body)['data']);
        merkData = List<Map<String, dynamic>>.from(json.decode(merkRes.body)['data']);
        isLoading = false;
      });
    } catch (e) {
      setState(() {
        errorMessage = e.toString();
        isLoading = false;
      });
    }
  }

  Future<void> _refreshData() async {
    setState(() {
      isLoading = true;
      errorMessage = '';
    });
    await fetchAllData();
  }

  Future<void> _showDateRangePicker() async {
    final DateTimeRange? picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime(2020),
      lastDate: DateTime.now(),
      initialDateRange: startDate != null && endDate != null
          ? DateTimeRange(start: startDate!, end: endDate!)
          : null,
    );
        
    if (picked != null) {
      setState(() {
        startDate = picked.start;
        endDate = picked.end;
      });
      _refreshData();
    }
  }

  void _clearDateFilter() {
    setState(() {
      startDate = null;
      endDate = null;
    });
    _refreshData();
  }

  void _showExportDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Export Data'),
          content: const Text('Pilih format export yang diinginkan:'),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _exportToPDF();
              },
              child: const Text('PDF'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context);
                _exportToExcel();
              },
              child: const Text('Excel'),
            ),
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Batal'),
            ),
          ],
        );
      },
    );
  }

  void _exportToPDF() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Export PDF berhasil! File disimpan di Downloads'),
        backgroundColor: Colors.green,
      ),
    );
  }

  void _exportToExcel() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Export Excel berhasil! File disimpan di Downloads'),
        backgroundColor: Colors.green,
      ),
    );
  }

  List<Map<String, dynamic>> _filterBarangMahal() {
    if (searchQuery.isEmpty) return barangMahal;
        
    return barangMahal.where((item) {
      return item['nama_barang']
          .toString()
          .toLowerCase()
          .contains(searchQuery.toLowerCase());
    }).toList();
  }

  void _navigateToPage(String routeName, String pageName) {
    Navigator.pop(context); // Close drawer first
        
    switch (routeName) {
      case '/dashboard':
        Navigator.pushReplacementNamed(context, '/dashboard');
        break;
      case '/daftar-barang':
        Navigator.pushReplacementNamed(context, '/daftar-barang');
        break;
      case '/daftar-perolehan':
        Navigator.pushReplacementNamed(context, '/daftar-perolehan');
        break;
      case '/daftar-ruangan':
        Navigator.pushReplacementNamed(context, '/daftar-ruangan');
        break;
      case '/admin-laporan':
        Navigator.pushReplacementNamed(context, '/admin-laporan');
        break;
      case '/daftar-pengguna':
        Navigator.pushReplacementNamed(context, '/daftar-pengguna');
        break;
      case '/pengaturan-profile':
        Navigator.pushReplacementNamed(context, '/pengaturan-profile');
        break;
      case '/peran-hak-akses':
        Navigator.pushReplacementNamed(context, '/peran-hak-akses');
        break;
      default:
        // If route doesn't exist, show a placeholder page
        Navigator.push( // Perbaikan: Menggunakan PlaceholderPage
          context,
          MaterialPageRoute(
            builder: (context) => PlaceholderPage(title: pageName),
          ),
        );
    }
  }

  // Fungsi untuk handle logout dengan konfirmasi
  Future<void> _handleLogout() async {
    final bool? shouldLogout = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Konfirmasi Logout'),
          content: const Text('Apakah Anda yakin ingin keluar dari aplikasi?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Batal'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: TextButton.styleFrom(
                foregroundColor: Colors.red,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );

    if (shouldLogout == true) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.clear();
        if (mounted) {
          Navigator.pushReplacementNamed(context, '/');
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal logout. Silakan coba lagi.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Container(
        color: Colors.grey[50],
        child: Column(
          children: [
            // Header
            Container(
              height: 120,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue[700]!, Colors.blue[500]!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'INVENTRIS',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Sistem Manajemen Inventaris',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
                        
            // Menu Items
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                children: [
                  _buildMenuSection('DASHBOARD'),
                  _buildMenuItem(
                    icon: Icons.dashboard_outlined,
                    title: 'Dashboard',
                    isActive: true,
                    onTap: () {
                      Navigator.pop(context);
                    },
                  ),
                                    
                  const SizedBox(height: 16),
                  _buildMenuSection('MANAJEMEN'),
                  _buildMenuItem(
                    icon: Icons.inventory_2_outlined,
                    title: 'Data Barang',
                    onTap: () => _navigateToPage('/daftar-barang', 'Data Barang'),
                  ),
                  _buildMenuItem(
                    icon: Icons.build_outlined,
                    title: 'Daftar Perolehan',
                    onTap: () => _navigateToPage('/daftar-perolehan', 'Daftar Perolehan'),
                  ),
                  _buildMenuItem(
                    icon: Icons.meeting_room_outlined,
                    title: 'Data Ruangan',
                    onTap: () => _navigateToPage('/daftar-ruangan', 'Data Ruangan'),
                  ),
                  _buildMenuItem(
                    icon: Icons.people_outline,
                    title: 'Data Pengguna',
                    onTap: () => _navigateToPage('/daftar-pengguna', 'Data Pengguna'),
                  ),
                  _buildMenuItem(
                    icon: Icons.insert_chart_outlined,
                    title: 'Laporan',
                    onTap: () => _navigateToPage('/admin-laporan', 'Laporan Admin'),
                  ),
                
                  _buildMenuItem(
                    icon: Icons.person_outline,
                    title: 'Pengaturan Profile',
                    onTap: () => _navigateToPage('/pengaturan-profile', 'Pengaturan Profil'),
                  ),
                  _buildMenuItem(
                    icon: Icons.admin_panel_settings_outlined,
                    title: 'Peran & Hak Akses',
                    onTap: () => _navigateToPage('/peran-hak-akses', 'Peran & Hak Akses'),
                  ),
                ],
              ),
            ),
                        
            // Logout Button
            Container(
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _handleLogout,
                  icon: const Icon(Icons.logout, color: Colors.white),
                  label: const Text(
                    'Logout',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red[600],
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuSection(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: Colors.grey[600],
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool isActive = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: ListTile(
        leading: Icon(
          icon,
          color: isActive ? Colors.blue[600] : Colors.grey[600],
          size: 22,
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isActive ? Colors.blue[600] : Colors.grey[700],
            fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
            fontSize: 14,
          ),
        ),
        onTap: onTap,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        tileColor: isActive ? Colors.blue[50] : null,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      ),
    );
  }

  Widget buildInfoCards() {
    List<Map<String, dynamic>> cards = [
      {
        'title': 'Total Barang',
        'value': kondisiData.fold<int>(0, (sum, item) => sum + int.parse(item['jumlah'].toString())),
        'color': Colors.blue,
        'icon': Icons.inventory,
        'trend': '+5%',
      },
      {
        'title': 'Kondisi Baik',
        'value': kondisiData.firstWhere((e) => e['kondisi'] == 'Baik', orElse: () => {'jumlah': '0'})['jumlah'],
        'color': Colors.green,
        'icon': Icons.check_circle,
        'trend': '+2%',
      },
      {
        'title': 'Rusak Ringan',
        'value': kondisiData.firstWhere((e) => e['kondisi'] == 'Kurang Baik', orElse: () => {'jumlah': '0'})['jumlah'],
        'color': Colors.orange,
        'icon': Icons.warning,
        'trend': '-1%',
      },
      {
        'title': 'Rusak Berat',
        'value': kondisiData.firstWhere((e) => e['kondisi'] == 'Rusak Berat', orElse: () => {'jumlah': '0'})['jumlah'],
        'color': Colors.red,
        'icon': Icons.error,
        'trend': '-3%',
      },
    ];

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: cards.map((card) {
        return SizedBox(
          width: 160,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            child: Card(
              color: card['color'] as Color,
              elevation: 4,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
              child: InkWell(
                borderRadius: BorderRadius.circular(12),
                onTap: () {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Detail ${card['title']}'),
                      duration: const Duration(seconds: 1),
                    ),
                  );
                },
                child: Padding(
                  padding: const EdgeInsets.all(12),
                  child: Column(
                    children: [
                      Icon(card['icon'] as IconData, color: Colors.white, size: 28),
                      const SizedBox(height: 8),
                      Text(
                        '${card['value']}',
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.white,
                        ),
                      ),
                      Text(
                        card['title'] as String,
                        style: const TextStyle(color: Colors.white, fontSize: 12),
                        textAlign: TextAlign.center,
                      ),
                      const SizedBox(height: 4),
                      Text(
                        card['trend'] as String,
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.8),
                          fontSize: 10,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildToolbar() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            Expanded(
              child: TextField(
                controller: _searchController,
                decoration: InputDecoration(
                  hintText: 'Cari barang...',
                  prefixIcon: const Icon(Icons.search),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide.none,
                  ),
                  filled: true,
                  fillColor: Colors.grey[100],
                  contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                ),
                onChanged: (value) {
                  setState(() {
                    searchQuery = value;
                  });
                },
              ),
            ),
            const SizedBox(width: 12),
            IconButton(
              onPressed: _showDateRangePicker,
              icon: const Icon(Icons.date_range),
              tooltip: 'Filter Tanggal',
              style: IconButton.styleFrom(
                backgroundColor: Colors.blue[50],
                foregroundColor: Colors.blue[600],
              ),
            ),
            const SizedBox(width: 8),
            if (startDate != null && endDate != null)
              IconButton(
                onPressed: _clearDateFilter,
                icon: const Icon(Icons.clear),
                tooltip: 'Hapus Filter',
                style: IconButton.styleFrom(
                  backgroundColor: Colors.red[50],
                  foregroundColor: Colors.red[600],
                ),
              ),
            const SizedBox(width: 8),
            IconButton(
              onPressed: _refreshData,
              icon: const Icon(Icons.refresh),
              tooltip: 'Refresh',
              style: IconButton.styleFrom(
                backgroundColor: Colors.green[50],
                foregroundColor: Colors.green[600],
              ),
            ),
            const SizedBox(width: 8),
            IconButton(
              onPressed: _showExportDialog,
              icon: const Icon(Icons.download),
              tooltip: 'Export',
              style: IconButton.styleFrom(
                backgroundColor: Colors.orange[50],
                foregroundColor: Colors.orange[600],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget buildBarChart(List<Map<String, dynamic>> data, String labelKey) {
    final colors = [Colors.green[600]!, Colors.orange[600]!, Colors.red[600]!];
        
    return BarChart(
      BarChartData(
        barGroups: data.asMap().entries.map((e) {
          final index = e.key;
          final value = double.parse(e.value['jumlah'].toString());
          return BarChartGroupData(
            x: index,
            barRods: [
              BarChartRodData(
                toY: value,
                color: colors[index % colors.length],
                width: 40,
                borderRadius: BorderRadius.circular(4),
              )
            ],
          );
        }).toList(),
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                if (value.toInt() < data.length) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      data[value.toInt()][labelKey].toString(),
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: Colors.grey[700],
                      ),
                    ),
                  );
                }
                return const Text('');
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              getTitlesWidget: (value, meta) {
                return Text(
                  value.toInt().toString(),
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                );
              },
            ),
          ),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: 2,
          getDrawingHorizontalLine: (value) {
            return FlLine(
              color: Colors.grey[300]!,
              strokeWidth: 1,
            );
          },
        ),
        borderData: FlBorderData(show: false),
        backgroundColor: Colors.transparent,
      ),
    );
  }

  Widget buildYearBarChart(List<Map<String, dynamic>> data) {
    final colors = [
      Colors.blue[400]!, Colors.green[400]!, Colors.orange[400]!,
      Colors.purple[400]!, Colors.red[400]!, Colors.teal[400]!,
      Colors.amber[400]!, Colors.indigo[400]!, Colors.pink[400]!,
    ];
        
    return BarChart(
      BarChartData(
        barGroups: data.asMap().entries.map((e) {
          final index = e.key;
          final value = double.parse(e.value['jumlah'].toString());
          return BarChartGroupData(
            x: index,
            barRods: [
              BarChartRodData(
                toY: value,
                color: colors[index % colors.length],
                width: 20,
                borderRadius: BorderRadius.circular(2),
              )
            ],
          );
        }).toList(),
        titlesData: FlTitlesData(
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                if (value.toInt() < data.length) {
                  return Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: Text(
                      data[value.toInt()]['tahun'].toString(),
                      style: TextStyle(
                        fontSize: 10,
                        color: Colors.grey[700],
                      ),
                    ),
                  );
                }
                return const Text('');
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 40,
              getTitlesWidget: (value, meta) {
                return Text(
                  value.toInt().toString(),
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                );
              },
            ),
          ),
          rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
          topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
        ),
        gridData: FlGridData(
          show: true,
          drawVerticalLine: false,
          horizontalInterval: 1,
          getDrawingHorizontalLine: (value) {
            return FlLine(
              color: Colors.grey[300]!,
              strokeWidth: 1,
            );
          },
        ),
        borderData: FlBorderData(show: false),
      ),
    );
  }

  Widget buildPieChart(List<Map<String, dynamic>> data, String labelKey) {
    final total = data.fold<int>(0, (sum, item) => sum + int.parse(item['jumlah'].toString()));
    final List<Color> colors = [
      Colors.blue[400]!, Colors.green[400]!, Colors.orange[400]!,
      Colors.purple[400]!, Colors.red[400]!, Colors.teal[400]!,
      Colors.amber[400]!, Colors.indigo[400]!, Colors.pink[400]!
    ];
        
    return PieChart(
      PieChartData(
        sections: data.asMap().entries.map((entry) {
          final index = entry.key;
          final e = entry.value;
          final value = int.parse(e['jumlah'].toString());
          final percent = ((value / total) * 100).toStringAsFixed(1);
          return PieChartSectionData(
            value: value.toDouble(),
            title: '$percent%',
            color: colors[index % colors.length],
            radius: 60,
            titleStyle: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          );
        }).toList(),
        sectionsSpace: 2,
        centerSpaceRadius: 40,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent, // Penting untuk background image
      appBar: AppBar(
        title: const Text(
          'Dashboard',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blue[600],
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
                dropdownColor: Colors.white,
                style: const TextStyle(color: Colors.black),
                onChanged: (value) {
                  if (value == 'profil') {
                    Navigator.pushNamed(context, '/pengaturan-profile'); // Perbaikan navigasi
                  } else if (value == 'logout') {
                    _handleLogout(); // Gunakan fungsi logout yang sudah diperbaiki
                  }
                },
                items: const [
                  DropdownMenuItem(value: 'profil', child: Text('Pengaturan Profile')),
                  DropdownMenuItem(value: 'logout', child: Text('Logout')),
                ],
                hint: const Row(
                  children: [
                    Icon(Icons.person, color: Colors.white),
                    SizedBox(width: 8),
                    Text(
                      "Halo Administrator",
                      style: TextStyle(color: Colors.white, fontSize: 14),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: GradientBackgroundWrapper( // Tambahkan background wrapper di sini
        child: RefreshIndicator(
          onRefresh: _refreshData,
          child: isLoading
              ? const Center(child: CircularProgressIndicator())
              : errorMessage.isNotEmpty
                  ? Center(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(Icons.error_outline, size: 64, color: Colors.red[300]),
                          const SizedBox(height: 16),
                          Text(
                            'Terjadi Kesalahan',
                            style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.bold,
                              color: Colors.grey[700],
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            errorMessage,
                            style: TextStyle(color: Colors.grey[600]),
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 16),
                          ElevatedButton.icon(
                            onPressed: _refreshData,
                            icon: const Icon(Icons.refresh),
                            label: const Text('Coba Lagi'),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.blue,
                              foregroundColor: Colors.white,
                            ),
                          ),
                        ],
                      ),
                    )
                  : LayoutBuilder(
                      builder: (context, constraints) {
                        return SingleChildScrollView(
                          padding: const EdgeInsets.all(16),
                          child: ConstrainedBox(
                            constraints: BoxConstraints(minWidth: constraints.maxWidth),
                            child: Column(
                              children: [
                                _buildToolbar(),
                                const SizedBox(height: 16),
                                if (startDate != null && endDate != null)
                                  Container(
                                    padding: const EdgeInsets.all(12),
                                    margin: const EdgeInsets.only(bottom: 16),
                                    decoration: BoxDecoration(
                                      color: Colors.blue[50],
                                      borderRadius: BorderRadius.circular(8),
                                      border: Border.all(color: Colors.blue[200]!),
                                    ),
                                    child: Row(
                                      children: [
                                        Icon(Icons.info_outline, color: Colors.blue[600]),
                                        const SizedBox(width: 8),
                                        Expanded(
                                          child: Text(
                                            'Filter aktif: ${startDate!.day}/${startDate!.month}/${startDate!.year} - ${endDate!.day}/${endDate!.month}/${endDate!.year}',
                                            style: TextStyle(color: Colors.blue[700]),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                buildInfoCards(),
                                const SizedBox(height: 24),
                                                              
                                // Charts Row
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    // Bar Chart
                                    Expanded(
                                      flex: 2,
                                      child: Card(
                                        elevation: 2,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(20),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "Grafik Barang Berdasarkan Kondisi",
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey[800],
                                                ),
                                              ),
                                              const SizedBox(height: 20),
                                              SizedBox(
                                                height: 250,
                                                child: buildBarChart(kondisiData, 'kondisi'),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 16),
                                                                      
                                    // Expensive Items List
                                    Expanded(
                                      flex: 1,
                                      child: Card(
                                        elevation: 2,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(20),
                                          child: Column(
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Text(
                                                "5 Barang Termahal",
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey[800],
                                                ),
                                              ),
                                              const SizedBox(height: 16),
                                              if (_filterBarangMahal().isEmpty)
                                                const Text('Tidak ada data.')
                                              else
                                                ..._filterBarangMahal().map((item) => ListTile(
                                                  dense: true,
                                                  title: Text(
                                                    item['nama_barang'],
                                                    maxLines: 1,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                  subtitle: Text(
                                                    "Harga: Rp ${item['harga']}",
                                                    maxLines: 1,
                                                    overflow: TextOverflow.ellipsis,
                                                  ),
                                                  trailing: TextButton(
                                                    onPressed: () {
                                                      Navigator.push(
                                                        context,
                                                        MaterialPageRoute(
                                                          builder: (_) => DetailBarangPage(barang: item),
                                                        ),
                                                      );
                                                    },
                                                    child: const Text("Detail"),
                                                  ),
                                                )),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 24),
                                                              
                                // Year Chart
                                Card(
                                  elevation: 2,
                                  shape: RoundedRectangleBorder(
                                    borderRadius: BorderRadius.circular(12),
                                  ),
                                  child: Padding(
                                    padding: const EdgeInsets.all(20),
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(
                                          "Grafik Jumlah Barang Berdasarkan Tahun Pembelian",
                                          style: TextStyle(
                                            fontSize: 16,
                                            fontWeight: FontWeight.bold,
                                            color: Colors.grey[800],
                                          ),
                                        ),
                                        const SizedBox(height: 20),
                                        SizedBox(
                                          height: 250,
                                          child: buildYearBarChart(tahunData),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                                const SizedBox(height: 24),
                                                              
                                // Pie Charts Row
                                Row(
                                  children: [
                                    Expanded(
                                      child: Card(
                                        elevation: 2,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(20),
                                          child: Column(
                                            children: [
                                              Text(
                                                "Grafik Berdasarkan Material",
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey[800],
                                                ),
                                              ),
                                              const SizedBox(height: 20),
                                              SizedBox(
                                                height: 250,
                                                child: buildPieChart(materialData, 'material'),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                    const SizedBox(width: 16),
                                    Expanded(
                                      child: Card(
                                        elevation: 2,
                                        shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(12),
                                        ),
                                        child: Padding(
                                          padding: const EdgeInsets.all(20),
                                          child: Column(
                                            children: [
                                              Text(
                                                "Grafik Berdasarkan Merk",
                                                style: TextStyle(
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold,
                                                  color: Colors.grey[800],
                                                ),
                                              ),
                                              const SizedBox(height: 20),
                                              SizedBox(
                                                height: 250,
                                                child: buildPieChart(merkData, 'merk'),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
        ),
      ),
    );
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}
