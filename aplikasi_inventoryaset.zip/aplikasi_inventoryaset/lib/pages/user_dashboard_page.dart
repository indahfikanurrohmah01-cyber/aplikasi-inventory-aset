import 'package:aplikasi_inventoryaset/pages/daftar_ruangan_user_page.dart';
import 'package:aplikasi_inventoryaset/pages/laporan_saya_page.dart';
import 'package:aplikasi_inventoryaset/pages/pengaturan_profile_user.dart';
import 'package:aplikasi_inventoryaset/pages/status_permintaan_page.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:fl_chart/fl_chart.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'background_wrapper.dart';
import '../utils/placeholder_page.dart';
import 'daftar_barang_user_page.dart'; 

class UserDashboardPage extends StatefulWidget {
  const UserDashboardPage({super.key});

  @override
  State<UserDashboardPage> createState() => _UserDashboardPageState();
}

class _UserDashboardPageState extends State<UserDashboardPage> {
  String _userName = 'User';
  bool _loading = true;

  int totalBarang = 0;
  int kondisiBaik = 0;
  int rusakRingan = 0;
  int rusakBerat = 0;

  Map<String, int> barangPerKategori = {
    'Elektronik': 0,
    'Alat Tulis': 0,
    'Furniture': 0,
    'Peralatan Kebersihan': 0,
  };

  List<Map<String, dynamic>> topExpensiveItems = [];

  @override
  void initState() {
    super.initState();
    _fetchData();
  }

  Future<void> _fetchData() async {
    setState(() => _loading = true);
    final prefs = await SharedPreferences.getInstance();
    _userName = prefs.getString('user_name') ?? 'User';

    try {
      final response = await http.get(
        Uri.parse("http://localhost/api_inventory/get_dashboard_summary.php"),
      );

      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        if (result['success']) {
          final data = result['data'];
          setState(() {
            totalBarang = data['total_barang'] ?? 0;
            kondisiBaik = data['kondisi_baik'] ?? 0;
            rusakRingan = data['rusak_ringan'] ?? 0;
            rusakBerat = data['rusak_berat'] ?? 0;

            if (data['barang_per_kategori'] != null) {
              final raw = Map<String, dynamic>.from(data['barang_per_kategori']);
              barangPerKategori = {
                for (var nama in barangPerKategori.keys)
                  nama: raw[nama] is int ? raw[nama] : 0,
              };
            }

            if (data['top_expensive_items'] != null) {
              topExpensiveItems = List<Map<String, dynamic>>.from(data['top_expensive_items']);
            }
          });
        } else {
          _setDummyData();
        }
      } else {
        _setDummyData();
      }
    } catch (_) {
      _setDummyData();
    } finally {
      setState(() => _loading = false);
    }
  }

  void _setDummyData() {
    setState(() {
      totalBarang = 10;
      kondisiBaik = 6;
      rusakRingan = 3;
      rusakBerat = 1;
      barangPerKategori = {
        'Elektronik': 4,
        'Alat Tulis': 2,
        'Furniture': 3,
        'Peralatan Kebersihan': 1,
      };
      topExpensiveItems = [
        {'nama_barang': 'Laptop Gaming', 'harga': 15000000},
        {'nama_barang': 'Proyektor 4K', 'harga': 8500000},
        {'nama_barang': 'Server Rack', 'harga': 7200000},
        {'nama_barang': 'Printer Laser', 'harga': 3100000},
        {'nama_barang': 'Meja Ergonomis', 'harga': 2500000},
      ];
    });
  }

  Future<void> _handleLogout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Konfirmasi Logout'),
        content: const Text('Apakah Anda yakin ingin keluar?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          TextButton(
              onPressed: () => Navigator.pop(context, true),
              style: TextButton.styleFrom(foregroundColor: Colors.red),
              child: const Text('Logout')),
        ],
      ),
    );
    if (confirm == true && mounted) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      Navigator.pushReplacementNamed(context, '/');
    }
  }
Future<void> _navigate(String route, String title) async {
  Navigator.pop(context); // Tutup drawer/menu terlebih dahulu

  if (route == '/user-dashboard') return;

  // Navigasi berdasarkan route
  if (route == '/daftar-barang-user') {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const DaftarBarangUserPage()));
  } else if (route == '/daftar-ruangan-user') {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const DaftarRuanganUserPage()));
  } else if (route == '/laporan-saya') {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const LaporanSayaPage()));
  } else if (route == '/status-permintaan') {
    final prefs = await SharedPreferences.getInstance();
    final userId = prefs.getInt('user_id')?.toString() ?? '0';

    if (!mounted) return;

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StatusPermintaanPage(userId: userId),
      ),
    );
  } else if (route == '/riwayat-pemakaian') {
    Navigator.pushNamed(context, '/riwayat-pemakaian');
  } else if (route == '/pengaturan-profile-user') {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PengaturanProfilUserPage()),
    );
  } else {
    // Fallback ke halaman placeholder jika route tidak ditemukan
    Navigator.push(context, MaterialPageRoute(builder: (_) => PlaceholderPage(title: title)));
  }
}

 

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: _buildAppBar(),
      drawer: _buildDrawer(),
      body: GradientBackgroundWrapper(
        child: _loading
            ? const Center(child: CircularProgressIndicator())
            : RefreshIndicator(
                onRefresh: _fetchData,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(24),
                  physics: const AlwaysScrollableScrollPhysics(),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _greetingCard(),
                      const SizedBox(height: 24),
                      _statisticRow(),
                      const SizedBox(height: 24),
                      _quickActionGrid(),
                      const SizedBox(height: 24),
                      _chartSection(),
                      const SizedBox(height: 24),
                      _topExpensiveItemsSection(),
                    ],
                  ),
                ),
              ),
      ),
    );
  }

  AppBar _buildAppBar() => AppBar(
        title: Text('Halo, $_userName!', style: const TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blue[600],
        elevation: 0,
        actions: [
          IconButton(onPressed: () => _navigate('/notifications', 'Notifikasi'), icon: const Icon(Icons.notifications)),
          PopupMenuButton<String>(
            onSelected: (value) =>
                value == 'logout' ? _handleLogout() : _navigate('/pengaturan-profile-user', 'Pengaturan Profil'),
            itemBuilder: (_) => [
              const PopupMenuItem(value: 'profil', child: Text('Pengaturan Profil')),
              const PopupMenuItem(value: 'logout', child: Text('Logout')),
            ],
          ),
        ],
      );

  Drawer _buildDrawer() => Drawer(
        child: SafeArea(
          child: ListView(
            children: [
              _drawerHeader(),
              _drawerSection('DASHBOARD'),
              _drawerItem(Icons.dashboard_outlined, 'Dashboard', true,
                  () => _navigate('/user-dashboard', 'Dashboard')),
              _drawerSection('MANAJEMEN BARANG'),
              _drawerItem(Icons.inventory_2_outlined, 'Daftar Barang', false,
                  () => _navigate('/daftar-barang-user', 'Daftar Barang')),
              _drawerItem(Icons.location_city, 'Daftar Ruangan', false,
                  () => _navigate('/daftar-ruangan-user', 'Daftar Ruangan')),
              _drawerItem(Icons.history, 'Riwayat Pemakaian', false,
                  () => _navigate('/riwayat-pemakaian', 'Riwayat Pemakaian')),
              _drawerItem(Icons.receipt_long, 'Laporan Saya', false,
                  () => _navigate('/laporan-saya', 'Laporan Saya')),
              _drawerSection('PENGATURAN'),
              _drawerItem(Icons.person_outline, 'Pengaturan Profil', false,
                  () => _navigate('/pengaturan-profile-user', 'Pengaturan Profil')),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.red),
                title: const Text('Logout', style: TextStyle(color: Colors.red)),
                onTap: _handleLogout,
              ),
            ],
          ),
        ),
      );

  Widget _drawerHeader() => Container(
        height: 120,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.blue[700]!, Colors.blue[500]!]),
        ),
        child: const Center(
          child: ListTile(
            title: Text('INVENTRIS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20)),
            subtitle: Text('Diskominfotik Bengkalis', style: TextStyle(color: Colors.white70)),
          ),
        ),
      );

  Widget _drawerSection(String title) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: Text(title, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.grey[600])),
      );

  Widget _drawerItem(IconData icon, String title, bool active, VoidCallback onTap) => ListTile(
        leading: Icon(icon, color: active ? Colors.blue : Colors.grey[600]),
        title: Text(title, style: TextStyle(color: active ? Colors.blue : Colors.grey[800])),
        tileColor: active ? Colors.blue[50] : null,
        onTap: onTap,
      );

  Widget _greetingCard() => Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        elevation: 4,
        child: Padding(
          padding: const EdgeInsets.all(20),
          child: Row(
            children: [
              CircleAvatar(radius: 28, backgroundColor: Colors.blue[100], child: const Icon(Icons.person, size: 32, color: Colors.blue)),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Selamat datang, $_userName', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 4),
                    const Text('Semoga harimu menyenangkan!', style: TextStyle(color: Colors.grey)),
                  ],
                ),
              ),
            ],
          ),
        ),
      );

  Widget _statisticRow() => Row(
        children: [
          _statCard('Total Barang', totalBarang, Icons.widgets, Colors.blue),
          _statCard('Kondisi Baik', kondisiBaik, Icons.check_circle_outline, Colors.green),
          _statCard('Rusak Ringan', rusakRingan, Icons.warning_amber_outlined, Colors.orange),
          _statCard('Rusak Berat', rusakBerat, Icons.cancel_outlined, Colors.red),
        ],
      );

  Widget _statCard(String label, int value, IconData icon, Color color) => Expanded(
        child: Card(
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 12),
            child: Column(
              children: [
                Icon(icon, color: color),
                const SizedBox(height: 8),
                Text('$value', style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
                const SizedBox(height: 4),
                Text(label, style: const TextStyle(fontSize: 12, color: Colors.grey)),
              ],
            ),
          ),
        ),
      );

  Widget _quickActionGrid() => GridView.count(
        crossAxisCount: 2,
        crossAxisSpacing: 16,
        mainAxisSpacing: 16,
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        children: [
          _quickAction(Icons.inventory_2_outlined, 'Daftar Barang', () => _navigate('/daftar-barang-user', 'Daftar Barang')),
          _quickAction(Icons.location_city, 'Daftar Ruangan', () => _navigate('/daftar-ruangan-user', 'Daftar Ruangan')),
          _quickAction(Icons.receipt_long, 'Laporan Saya', () => _navigate('/laporan-saya', 'Laporan Saya')),
          _quickAction(Icons.history, 'Riwayat Pemakaian', () => _navigate('/riwayat-pemakaian', 'Riwayat Pemakaian')),
        ],
      );

  Widget _quickAction(IconData icon, String label, VoidCallback onTap) => InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        child: Card(
          elevation: 3,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(icon, size: 40, color: Colors.blue[600]),
                const SizedBox(height: 12),
                Text(label, style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600), textAlign: TextAlign.center),
              ],
            ),
          ),
        ),
      );

  Widget _chartSection() {
    final List<BarChartGroupData> barGroups = [
      BarChartGroupData(x: 0, barRods: [BarChartRodData(toY: barangPerKategori['Elektronik']!.toDouble(), width: 18, color: Colors.blue)]),
      BarChartGroupData(x: 1, barRods: [BarChartRodData(toY: barangPerKategori['Alat Tulis']!.toDouble(), width: 18, color: Colors.cyan)]),
      BarChartGroupData(x: 2, barRods: [BarChartRodData(toY: barangPerKategori['Furniture']!.toDouble(), width: 18, color: Colors.indigo)]),
      BarChartGroupData(x: 3, barRods: [BarChartRodData(toY: barangPerKategori['Peralatan Kebersihan']!.toDouble(), width: 18, color: Colors.purple)]),
    ];

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Distribusi Barang per Kategori', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            SizedBox(
              height: 200,
              child: BarChart(
                BarChartData(
                  alignment: BarChartAlignment.spaceAround,
                  borderData: FlBorderData(show: false),
                  titlesData: FlTitlesData(
                    leftTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        interval: 1,
                        getTitlesWidget: (value, meta) => Text(value.toInt().toString(), style: const TextStyle(fontSize: 10)),
                      ),
                    ),
                    rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    bottomTitles: AxisTitles(
                      sideTitles: SideTitles(
                        showTitles: true,
                        getTitlesWidget: (value, meta) {
                          final labels = ['Elektronik', 'Alat Tulis', 'Furniture', 'Peralatan\nKebersihan'];
                          return Text(labels[value.toInt()], style: const TextStyle(fontSize: 9), textAlign: TextAlign.center);
                        },
                      ),
                    ),
                  ),
                  barGroups: barGroups,
                  gridData: FlGridData(
                    show: true,
                    drawVerticalLine: false,
                    getDrawingHorizontalLine: (_) => const FlLine(color: Color(0xffe7e8ec), strokeWidth: 1),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _topExpensiveItemsSection() {
    final currencyFormatter = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp ', decimalDigits: 0);

    return Card(
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      elevation: 4,
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('5 Barang Termahal', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 16),
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: topExpensiveItems.length,
              itemBuilder: (context, index) {
                final item = topExpensiveItems[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8.0),
                  child: Row(
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(item['nama_barang']!, style: const TextStyle(fontWeight: FontWeight.w500)),
                            Text(currencyFormatter.format(item['harga']), style: const TextStyle(color: Colors.grey, fontSize: 12)),
                          ],
                        ),
                      ),
                      TextButton(
                        onPressed: () {
                          _navigate('/item-detail/${item['nama_barang']}', 'Detail Barang');
                        },
                        child: const Text('Detail'),
                      ),
                    ],
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
