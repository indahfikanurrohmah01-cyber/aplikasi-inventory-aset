import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/foundation.dart'; // Untuk debugPrint

class TambahLaporanPage extends StatefulWidget {
  const TambahLaporanPage({super.key});

  @override
  State<TambahLaporanPage> createState() => _TambahLaporanPageState();
}

class _TambahLaporanPageState extends State<TambahLaporanPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController namaBarangController = TextEditingController();
  final TextEditingController deskripsiController = TextEditingController();
  
  bool _isSubmitting = false;

  @override
  void dispose() {
    namaBarangController.dispose();
    deskripsiController.dispose();
    super.dispose();
  }

  Future<void> submitLaporan() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('userId');
    
    // Konsisten dengan LaporanSayaPage - gunakan hardcoded jika tidak ada
    if (userId == null) {
      userId = '4'; // Sama dengan yang digunakan di LaporanSayaPage
      await prefs.setString('userId', userId);
      debugPrint('User ID set to hardcoded value for testing: $userId');
    }
    
    debugPrint('Submitting laporan with User ID: $userId');
    debugPrint('Nama Barang: ${namaBarangController.text}');
    debugPrint('Deskripsi: ${deskripsiController.text}');

    setState(() {
      _isSubmitting = true;
    });

    try {
      // Gunakan API tambah_laporan.php yang sesuai dengan struktur database Anda
      final url = Uri.parse('http://localhost/api_inventory/tambah_laporan.php');
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'id_user': userId,
          'nama_barang': namaBarangController.text,
          'deskripsi': deskripsiController.text, // Sesuai dengan field database
        }),
      );

      debugPrint('Response status: ${response.statusCode}');
      debugPrint('Response body: ${response.body}');

      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });

        if (response.statusCode == 200) {
          try {
            final result = json.decode(response.body);
            // Sesuaikan dengan format response API Anda (menggunakan 'status' bukan 'success')
            if (result['status'] == 'success') {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(result['message'] ?? 'Laporan berhasil dikirim')),
              );
              // Bersihkan form
              namaBarangController.clear();
              deskripsiController.clear();
              // Kembali ke halaman sebelumnya dengan hasil success
              Navigator.pop(context, true);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Gagal: ${result['message'] ?? 'Terjadi kesalahan'}')),
              );
            }
          } catch (e) {
            debugPrint('Error parsing JSON: $e');
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Error parsing response: $e')),
            );
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('HTTP Error: ${response.statusCode}')),
          );
        }
      }
    } catch (e) {
      debugPrint('Error submitting laporan: $e');
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Tambah Laporan', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blue[600], // Konsisten dengan tema
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Card(
          elevation: 5,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Icon(Icons.report_problem, size: 64, color: Colors.blue[600]),
                  const SizedBox(height: 10),
                  Text(
                    'Isi Formulir Laporan',
                    style: TextStyle(
                      fontSize: 18, 
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[700],
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  TextFormField(
                    controller: namaBarangController,
                    decoration: InputDecoration(
                      labelText: 'Nama Barang',
                      hintText: 'Contoh: Laptop, Proyektor',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      prefixIcon: const Icon(Icons.laptop_mac),
                    ),
                    validator: (value) =>
                        value == null || value.trim().isEmpty ? 'Nama barang wajib diisi' : null,
                  ),
                  const SizedBox(height: 16),
                  
                  TextFormField(
                    controller: deskripsiController,
                    decoration: InputDecoration(
                      labelText: 'Deskripsi Laporan',
                      hintText: 'Jelaskan detail masalah atau kondisi barang...',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      prefixIcon: const Icon(Icons.description),
                      alignLabelWithHint: true,
                    ),
                    maxLines: 4,
                    validator: (value) =>
                        value == null || value.trim().isEmpty ? 'Deskripsi wajib diisi' : null,
                  ),
                  const SizedBox(height: 24),
                  
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _isSubmitting
                          ? null
                          : () {
                              if (_formKey.currentState!.validate()) {
                                submitLaporan();
                              }
                            },
                      icon: _isSubmitting
                          ? const SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: Colors.white,
                              ),
                            )
                          : const Icon(Icons.send),
                      label: Text(_isSubmitting ? 'Mengirim...' : 'Kirim Laporan'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.blue[600], // Konsisten dengan tema
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 14),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
