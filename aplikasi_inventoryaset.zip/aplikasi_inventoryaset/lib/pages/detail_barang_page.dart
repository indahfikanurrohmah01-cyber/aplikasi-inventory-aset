import 'package:flutter/material.dart';

class DetailBarangPage extends StatefulWidget {
  final Map<String, dynamic> barang;

  const DetailBarangPage({super.key, required this.barang});

  @override
  State<DetailBarangPage> createState() => _DetailBarangPageState();
}

class _DetailBarangPageState extends State<DetailBarangPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController _namaController;
  late TextEditingController _merkController;
  late TextEditingController _materialController;
  late TextEditingController _hargaController;
  late TextEditingController _tahunController;
  late TextEditingController _kondisiController;

  final List<String> _ruanganList = ['PBE', 'SDKI', 'PPIP', 'BSP'];
  final List<String> _kategoriList = ['Elektronik', 'Meubel', 'ATK', 'Lainnya'];

  String? _selectedRuangan;
  String? _selectedKategori;

  @override
  void initState() {
    super.initState();
    _namaController = TextEditingController(text: widget.barang['nama_barang']);
    _merkController = TextEditingController(text: widget.barang['merk']);
    _materialController = TextEditingController(text: widget.barang['material']);
    _hargaController = TextEditingController(text: widget.barang['harga']?.toString());
    _tahunController = TextEditingController(text: widget.barang['tahun']);
    _kondisiController = TextEditingController(text: widget.barang['kondisi']);

    _selectedRuangan = widget.barang['nama_ruangan'];
    _selectedKategori = widget.barang['kategori'] ?? _kategoriList.first;
  }

  @override
  void dispose() {
    _namaController.dispose();
    _merkController.dispose();
    _materialController.dispose();
    _hargaController.dispose();
    _tahunController.dispose();
    _kondisiController.dispose();
    super.dispose();
  }

  void _simpanData() {
    if (_formKey.currentState!.validate()) {
      final dataBaru = {
        'nama_barang': _namaController.text,
        'merk': _merkController.text,
        'material': _materialController.text,
        'harga': _hargaController.text,
        'tahun': _tahunController.text,
        'kondisi': _kondisiController.text,
        'nama_ruangan': _selectedRuangan,
        'kategori': _selectedKategori,
      };

      // Simulasi update API
      print('Update data ke server: $dataBaru');

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Data berhasil diperbarui')),
      );
    }
  }

  void _hapusBarang() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Konfirmasi'),
        content: const Text('Apakah Anda yakin ingin menghapus barang ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(ctx, false),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(ctx, true),
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );

    if (confirm == true) {
      print('Barang dengan ID ${widget.barang['id']} dihapus');

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Barang berhasil dihapus')),
      );

      Navigator.pop(context);
    }
  }

  Widget _buildTextField(String label, TextEditingController controller, {TextInputType? keyboardType}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
        validator: (value) {
          if (value == null || value.isEmpty) return 'Field tidak boleh kosong';
          return null;
        },
      ),
    );
  }

  Widget _buildDropdown(String label, List<String> items, String? selected, ValueChanged<String?> onChanged) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: DropdownButtonFormField<String>(
        value: selected,
        items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        onChanged: onChanged,
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        ),
        validator: (value) => value == null || value.isEmpty ? 'Harus dipilih' : null,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Detail Barang'),
        backgroundColor: Colors.blue,
        actions: [
          IconButton(
            icon: const Icon(Icons.delete),
            onPressed: _hapusBarang,
            tooltip: 'Hapus Barang',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Card(
          elevation: 6,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: ListView(
                children: [
                  _buildTextField("Nama Barang", _namaController),
                  _buildTextField("Merk", _merkController),
                  _buildTextField("Material", _materialController),
                  _buildTextField("Harga", _hargaController, keyboardType: TextInputType.number),
                  _buildTextField("Tahun Pembelian", _tahunController, keyboardType: TextInputType.number),
                  _buildTextField("Kondisi", _kondisiController),
                  _buildDropdown("Kategori", _kategoriList, _selectedKategori, (val) {
                    setState(() => _selectedKategori = val);
                  }),
                  _buildDropdown("Ruangan", _ruanganList, _selectedRuangan, (val) {
                    setState(() => _selectedRuangan = val);
                  }),
                  const SizedBox(height: 20),
                  ElevatedButton.icon(
                    onPressed: _simpanData,
                    icon: const Icon(Icons.save),
                    label: const Text("Simpan Perubahan"),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
