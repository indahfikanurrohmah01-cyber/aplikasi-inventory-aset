import 'package:flutter/material.dart';

class BackgroundWrapper extends StatelessWidget {
  final Widget child;
  final bool showOverlay;
  final double overlayOpacity;
  final Color overlayColor;

  const BackgroundWrapper({
    Key? key,
    required this.child,
    this.showOverlay = true,
    this.overlayOpacity = 0.85,
    this.overlayColor = Colors.white,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: NetworkImage('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-G0vswoxbNB5BxwViFb6VNhmskcXuly.png'), // Gambar gedung Diskominfo
          fit: BoxFit.cover,
        ),
      ),
      child: showOverlay
          ? Container(
              decoration: BoxDecoration(
                color: overlayColor.withOpacity(overlayOpacity),
              ),
              child: child,
            )
          : child,
    );
  }
}

// Alternative dengan gradient overlay yang lebih cantik
class GradientBackgroundWrapper extends StatelessWidget {
  final Widget child;
  final bool showGradient;
  final List<Color>? gradientColors;

  const GradientBackgroundWrapper({
    Key? key,
    required this.child,
    this.showGradient = true,
    this.gradientColors,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: NetworkImage('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-G0vswoxbNB5BxwViFb6VNhmskcXuly.png'),
          fit: BoxFit.cover,
        ),
      ),
      child: showGradient
          ? Container(
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: gradientColors ?? [
                    Colors.white.withOpacity(0.9),
                    Colors.white.withOpacity(0.8),
                    Colors.white.withOpacity(0.85),
                  ],
                ),
              ),
              child: child,
            )
          : child,
    );
  }
}
