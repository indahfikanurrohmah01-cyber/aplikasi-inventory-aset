import 'dart:convert';
import 'dart:io';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'detail_barang_page.dart'; 
import 'background_wrapper.dart';
import 'package:flutter/foundation.dart' as foundation; 

class DaftarBarangPage extends StatefulWidget {
  const DaftarBarangPage({super.key});

  @override
  State<DaftarBarangPage> createState() => _DaftarBarangPageState();
}

class _DaftarBarangPageState extends State<DaftarBarangPage> {
  List<dynamic> barangList = [];
  List<dynamic> filteredList = [];
  String? lokasi;
  String? kondisi;
  String? tahun;
  String? material;
  String? merk;
  bool _isFilterExpanded = false;

  @override
  void initState() {
    super.initState();
    fetchBarang();
  }

  Future<void> fetchBarang() async {
    try {
      final response = await http.get(Uri.parse('http://localhost/api_inventory/get_barang.php'));
      if (!mounted) return;
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          setState(() {
            barangList = data['barang'];
            filteredList = barangList;
          });
        }
      }
    } catch (e) {
      if (!mounted) return;
      debugPrint('Error fetching: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal memuat data barang: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void applyFilter() {
    setState(() {
      filteredList = barangList.where((item) {
        return (lokasi == null || item['lokasi'] == lokasi) &&
            (kondisi == null || item['kondisi'] == kondisi) &&
            (tahun == null || item['tahun'].toString() == tahun) &&
            (material == null || item['material'] == material) &&
            (merk == null || item['merk'] == merk);
      }).toList();
    });
  }

  void applySingleFilter(String field, String? value) {
    setState(() {
      switch (field) {
        case 'lokasi':
          lokasi = value;
          break;
        case 'kondisi':
          kondisi = value;
          break;
        case 'tahun':
          tahun = value;
          break;
        case 'material':
          material = value;
          break;
        case 'merk':
          merk = value;
          break;
      }
      applyFilter();
    });
  }

  void resetFilter() {
    setState(() {
      lokasi = kondisi = tahun = material = merk = null;
      filteredList = barangList;
    });
  }

  void editBarang(Map<String, dynamic> item) async {
    final updatedItem = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => DetailBarangPage(barang: item),
      ),
    );

    if (!mounted) return;
    if (updatedItem != null && updatedItem is Map<String, dynamic>) {
      setState(() {
        int indexInBarangList = barangList.indexWhere((b) => b['id_barang'] == updatedItem['id_barang']);
        if (indexInBarangList != -1) {
          barangList[indexInBarangList] = updatedItem;
        }

        int indexInFilteredList = filteredList.indexWhere((f) => f['id_barang'] == updatedItem['id_barang']);
        if (indexInFilteredList != -1) {
          filteredList[indexInFilteredList] = updatedItem;
        } else {
          fetchBarang();
        }
      });
    } else {
      fetchBarang();
    }
  }

  void confirmDelete(String id) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        title: const Row(
          children: [
            Icon(Icons.warning, color: Colors.orange),
            SizedBox(width: 8),
            Text('Konfirmasi Hapus'),
          ],
        ),
        content: const Text('Apakah Anda yakin ingin menghapus barang ini?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              deleteBarang(id);
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );
  }

  Future<void> deleteBarang(String id) async {
    final response = await http.post(
      Uri.parse('http://localhost/api_inventory/delete_barang.php'),
      body: {'id_barang': id},
    );
    if (!mounted) return;
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Barang berhasil dihapus'),
            backgroundColor: Colors.green,
          ),
        );
        fetchBarang();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(data['message'] ?? 'Gagal menghapus'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> importFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );
    if (!mounted) return;
    if (result != null) {
      File file = File(result.files.single.path!);
      var bytes = file.readAsBytesSync();
      var excel = Excel.decodeBytes(bytes);
      for (var table in excel.tables.keys) {
        for (var row in excel.tables[table]!.rows.skip(1)) {
          debugPrint(row.map((e) => e?.value).join(', '));
        }
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Import berhasil dibaca'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  Future<void> exportToExcel() async {
    var excel = Excel.createExcel();
    Sheet sheet = excel['Sheet1'];
    sheet.appendRow(['Kode', 'Nama', 'Material', 'Merk', 'Kondisi', 'Tahun']);
    for (var item in filteredList) {
      sheet.appendRow([
        item['kode_barang'],
        item['nama_barang'],
        item['material'],
        item['merk'],
        item['kondisi'],
        item['tahun'].toString()
      ]);
    }
    final fileBytes = excel.save();

    if (foundation.kIsWeb) {
      // For web, excel.save() automatically triggers a download.
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Export Excel berhasil! File akan diunduh.'),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      // For non-web platforms (mobile/desktop), use file_picker to save.
      try {
        final String? directory = await FilePicker.platform.getDirectoryPath();
        if (!mounted) return;
        if (directory != null) {
          final file = File('$directory/export_barang.xlsx');
          await file.writeAsBytes(fileBytes!);
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Export berhasil disimpan'),
              backgroundColor: Colors.green,
            ),
          );
        } else {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Penyimpanan dibatalkan atau tidak ada folder dipilih.'),
              backgroundColor: Colors.orange,
            ),
          );
        }
      } catch (e) {
        if (!mounted) return;
        debugPrint("Error exporting on platform: $e");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error export: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> printData() async {
    final pdf = pw.Document();
    pdf.addPage(pw.Page(
        pageFormat: PdfPageFormat.a4.landscape,
        build: (pw.Context context) {
          return pw.TableHelper.fromTextArray(
            headers: ['Kode', 'Nama', 'Material', 'Merk', 'Kondisi', 'Tahun'],
            data: filteredList.map((item) => [
                  item['kode_barang'],
                  item['nama_barang'],
                  item['material'],
                  item['merk'],
                  item['kondisi'],
                  item['tahun'].toString()
                ]).toList(),
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white),
            headerDecoration: const pw.BoxDecoration(color: PdfColors.indigo600),
            cellAlignment: pw.Alignment.centerLeft,
            cellPadding: const pw.EdgeInsets.all(8),
            border: pw.TableBorder.all(color: PdfColors.grey),
          );
        }));
    await Printing.layoutPdf(onLayout: (PdfPageFormat format) async => pdf.save());
  }

  List<String> _getUniqueList(String field) {
    final set = <String>{};
    for (var item in barangList) {
      if (item[field] != null && item[field].toString().isNotEmpty) {
        set.add(item[field].toString());
      }
    }
    return set.toList();
  }

  Widget buildStatBox(Color color, IconData icon, String title, int value) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 1,
              blurRadius: 6,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontSize: 12,
                color: Colors.grey,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            Text(
              value.toString(),
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown(
      String label, String? value, List<String> options, void Function(String?) onChanged) {
    return Flexible(
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: const BoxConstraints(minWidth: 150, maxWidth: 200),
        child: DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(
            labelText: label,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: Colors.indigo[400]!, width: 2),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          ),
          items: [
            DropdownMenuItem<String>(value: null, child: Text('Semua $label')),
            ...options.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          ],
          onChanged: onChanged,
        ),
      ),
    );
  }

  // Fungsi untuk handle logout dengan konfirmasi
  Future<void> _handleLogout() async {
    final bool? shouldLogout = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Konfirmasi Logout'),
          content: const Text('Apakah Anda yakin ingin keluar dari aplikasi?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Batal'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: TextButton.styleFrom(
                foregroundColor: Colors.red,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );
    if (shouldLogout == true) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.clear();
        if (mounted) {
          Navigator.pushReplacementNamed(context, '/');
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Gagal logout. Silakan coba lagi.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _navigateToPage(String routeName, String pageName) async {
    Navigator.pop(context); // Close drawer first
    
    // Get user data from SharedPreferences for navigation
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String username = prefs.getString('username') ?? 'Guest';
    String namaLengkap = prefs.getString('nama_lengkap') ?? 'Pengguna';
    String role = prefs.getString('role') ?? 'User';

    switch (routeName) {
      case '/dashboard':
        Navigator.pushReplacementNamed(context, '/dashboard', arguments: {
          'username': username,
          'nama_lengkap': namaLengkap,
          'role': role,
        });
        break;
      case '/daftar-barang':
        // Already on this page, do nothing
        break;
      case '/daftar-perolehan':
        Navigator.pushReplacementNamed(context, '/daftar-perolehan');
        break;
      case '/daftar-ruangan':
        Navigator.pushReplacementNamed(context, '/daftar-ruangan');
        break;
      case '/daftar-pengguna':
        // Navigate to Data Pengguna page
        Navigator.pushReplacementNamed(context, '/daftar-pengguna');
        break;
      case '/pengaturan-profile':
        // Navigate to Pengaturan Profil page
        Navigator.pushReplacementNamed(context, '/pengaturan-profile', arguments: {
          'username': username,
          'nama_lengkap': namaLengkap,
          'role': role,
        });
        break;
      case '/peran-hak-akses':
        // Navigate to Peran & Hak Akses page
        Navigator.pushReplacementNamed(context, '/peran-hak-akses');
        break;
      case '/admin-laporan':
        // Navigate to Admin Laporan page
        Navigator.pushReplacementNamed(context, '/admin-laporan');
        break;
      case '/laporan':
        // Navigate to Laporan page (fallback for general laporan)
        Navigator.pushReplacementNamed(context, '/admin-laporan');
        break;
      default:
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Navigasi ke $pageName belum tersedia'),
            backgroundColor: Colors.orange,
          ),
        );
    }
  }

  Future<Map<String, String>> _getUserData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    return {
      'username': prefs.getString('username') ?? 'Guest',
      'nama_lengkap': prefs.getString('nama_lengkap') ?? 'Pengguna',
      'role': prefs.getString('role') ?? 'User',
    };
  }

  Widget _buildDrawer() {
    return FutureBuilder<Map<String, String>>(
      future: _getUserData(),
      builder: (context, snapshot) {
        String role = snapshot.data?['role'] ?? 'User';
        
        return Drawer(
          child: Container(
            color: Colors.white,
            child: Column(
              children: [
                // Header dengan gradient biru
                Container(
                  height: 160,
                  width: double.infinity,
                  decoration: const BoxDecoration(
                    gradient: LinearGradient(
                      colors: [Color(0xFF1976D2), Color(0xFF42A5F5)],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                  ),
                  child: SafeArea(
                    child: Padding(
                      padding: const EdgeInsets.all(20),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text(
                            'INVENTRIS',
                            style: TextStyle(
                              color: Colors.white,
                              fontSize: 24,
                              fontWeight: FontWeight.bold,
                              letterSpacing: 1.5,
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            'Sistem Manajemen Inventaris',
                            style: TextStyle(
                              color: Colors.white.withOpacity(0.9),
                              fontSize: 14,
                              fontWeight: FontWeight.w400,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                // Menu Items
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                    children: [
                      _buildMenuItem(
                        icon: Icons.dashboard_outlined,
                        title: 'Dashboard',
                        isActive: false,
                        onTap: () => _navigateToPage('/dashboard', 'Dashboard'),
                      ),
                      const SizedBox(height: 24),
                      _buildMenuSection('MANAJEMEN'),
                      _buildMenuItem(
                        icon: Icons.inventory_2_outlined,
                        title: 'Data Barang',
                        isActive: true,
                        onTap: () {
                          Navigator.pop(context);
                        },
                      ),
                      _buildMenuItem(
                        icon: Icons.build_outlined,
                        title: 'Daftar Perolehan',
                        isActive: false,
                        onTap: () => _navigateToPage('/daftar-perolehan', 'Daftar Perolehan'),
                      ),
                      _buildMenuItem(
                        icon: Icons.meeting_room_outlined,
                        title: 'Data Ruangan',
                        isActive: false,
                        onTap: () => _navigateToPage('/daftar-ruangan', 'Data Ruangan'),
                      ),
                      _buildMenuItem(
                        icon: Icons.people_outline,
                        title: 'Data Pengguna',
                        isActive: false,
                        onTap: () => _navigateToPage('/daftar-pengguna', 'Data Pengguna'),
                      ),
                      _buildMenuItem(
                        icon: Icons.bar_chart_outlined,
                        title: 'Laporan',
                        isActive: false,
                        onTap: () => _navigateToPage('/admin-laporan', 'Laporan'),
                      ),
                      _buildMenuItem(
                        icon: Icons.person_outline,
                        title: 'Pengaturan Profile',
                        isActive: false,
                        onTap: () => _navigateToPage('/pengaturan-profile', 'Pengaturan Profile'),
                      ),
                      _buildMenuItem(
                        icon: Icons.admin_panel_settings_outlined,
                        title: 'Peran & Hak Akses',
                        isActive: false,
                        onTap: () => _navigateToPage('/peran-hak-akses', 'Peran & Hak Akses'),
                      ),
                    ],
                  ),
                ),
                // Logout Button
                Container(
                  padding: const EdgeInsets.all(20),
                  child: SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      onPressed: _handleLogout,
                      icon: const Icon(Icons.logout, color: Colors.white, size: 20),
                      label: const Text(
                        'Logout',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                          fontSize: 16,
                        ),
                      ),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFFE53935),
                        padding: const EdgeInsets.symmetric(vertical: 16),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        elevation: 0,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _buildMenuSection(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 0, 20, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: Colors.grey[600],
          letterSpacing: 0.8,
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    required bool isActive,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 2),
      child: ListTile(
        leading: Icon(
          icon,
          color: isActive ? const Color(0xFF1976D2) : Colors.grey[600],
          size: 24,
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isActive ? const Color(0xFF1976D2) : Colors.grey[700],
            fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
            fontSize: 16,
          ),
        ),
        onTap: onTap,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        tileColor: isActive ? const Color(0xFF1976D2).withOpacity(0.1) : null,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        dense: false,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent, // Penting untuk background image
      drawer: _buildDrawer(), // Updated drawer method
      appBar: AppBar(
        title: const Text(
          'Daftar Barang',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.indigo[400],
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
                dropdownColor: Colors.white,
                style: const TextStyle(color: Colors.black),
                onChanged: (value) {
                  if (value == 'profil') {
                    _navigateToPage('/pengaturan-profile', 'Pengaturan Profile');
                  } else if (value == 'logout') {
                    _handleLogout();
                  }
                },
                items: const [
                  DropdownMenuItem(value: 'profil', child: Text('Pengaturan Profile')),
                  DropdownMenuItem(value: 'logout', child: Text('Logout')),
                ],
                hint: const Row(
                  children: [
                    Icon(Icons.person, color: Colors.white),
                    SizedBox(width: 8),
                    Text(
                      "Halo Administrator",
                      style: TextStyle(color: Colors.white, fontSize: 14),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      body: GradientBackgroundWrapper( // Tambahkan background wrapper di sini
        // Tidak perlu lagi gradientColors: BackgroundConfig.defaultGradientColors,
        // karena GradientBackgroundWrapper sudah memiliki default-nya sendiri
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Statistics Cards
              LayoutBuilder(
                builder: (context, constraints) {
                  if (constraints.maxWidth < 600) {
                    return Column(
                      children: [
                        Row(
                          children: [
                            buildStatBox(Colors.indigo, Icons.inventory, "Total Barang",
                                barangList.length),
                            buildStatBox(Colors.green, Icons.check_circle, "Kondisi Baik",
                                barangList.where((e) => e['kondisi'] == 'Baik').length),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            buildStatBox(Colors.orange, Icons.warning, "Rusak Ringan",
                                barangList.where((e) => e['kondisi'] == 'Kurang Baik' || e['kondisi'] == 'Rusak Ringan').length),
                            buildStatBox(Colors.red, Icons.cancel, "Rusak Berat",
                                barangList.where((e) => e['kondisi'] == 'Rusak Berat').length),
                          ],
                        ),
                      ],
                    );
                  } else {
                    return Row(
                      children: [
                        buildStatBox(
                            Colors.indigo, Icons.inventory, "Total Barang", barangList.length),
                        buildStatBox(Colors.green, Icons.check_circle, "Kondisi Baik",
                            barangList.where((e) => e['kondisi'] == 'Baik').length),
                        buildStatBox(Colors.orange, Icons.warning, "Rusak Ringan",
                            barangList.where((e) => e['kondisi'] == 'Kurang Baik' || e['kondisi'] == 'Rusak Ringan').length),
                        buildStatBox(Colors.red, Icons.cancel, "Rusak Berat",
                            barangList.where((e) => e['kondisi'] == 'Rusak Berat').length),
                      ],
                    );
                  }
                },
              ),
              const SizedBox(height: 24),
              // Action Buttons
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Aksi Data',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 12),
                    LayoutBuilder(builder: (context, constraints) {
                      if (constraints.maxWidth < 600) {
                        return Column(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: importFile,
                                icon: const Icon(Icons.upload_file, color: Colors.white),
                                label: const Text('Import Excel',
                                    style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.indigo[400],
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: exportToExcel,
                                icon: const Icon(Icons.download, color: Colors.white),
                                label: const Text('Export Excel',
                                    style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: printData,
                                icon: const Icon(Icons.print, color: Colors.white),
                                label: const Text('Print', style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.black87,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                          ],
                        );
                      } else {
                        return Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: importFile,
                                icon: const Icon(Icons.upload_file, color: Colors.white),
                                label: const Text('Import Excel',
                                    style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.indigo[400],
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: exportToExcel,
                                icon: const Icon(Icons.download, color: Colors.white),
                                label: const Text('Export Excel',
                                    style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: printData,
                                icon: const Icon(Icons.print, color: Colors.white),
                                label: const Text('Print', style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.black87,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                          ],
                        );
                      }
                    }),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Filter Section
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    InkWell(
                      onTap: () {
                        setState(() {
                          _isFilterExpanded = !_isFilterExpanded;
                        });
                      },
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.indigo[400],
                          borderRadius: _isFilterExpanded
                              ? const BorderRadius.only(
                                  topLeft: Radius.circular(12),
                                  topRight: Radius.circular(12),
                                )
                              : BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Filter Data Barang',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Icon(
                              _isFilterExpanded ? Icons.expand_less : Icons.expand_more,
                              color: Colors.white,
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (_isFilterExpanded)
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Wrap(
                              spacing: 12,
                              runSpacing: 8,
                              alignment: WrapAlignment.center,
                              children: [
                                _buildDropdown("Lokasi", lokasi, _getUniqueList('lokasi'),
                                    (val) => applySingleFilter('lokasi', val)),
                                _buildDropdown("Kondisi", kondisi, _getUniqueList('kondisi'),
                                    (val) => applySingleFilter('kondisi', val)),
                                _buildDropdown("Tahun", tahun, _getUniqueList('tahun'),
                                    (val) => applySingleFilter('tahun', val)),
                                _buildDropdown("Bahan", material, _getUniqueList('material'),
                                    (val) => applySingleFilter('material', val)),
                                _buildDropdown("Merk", merk, _getUniqueList('merk'),
                                    (val) => applySingleFilter('merk', val)),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                Expanded(
                                  child: ElevatedButton.icon(
                                    onPressed: resetFilter,
                                    icon: const Icon(Icons.refresh, color: Colors.white),
                                    label:
                                        const Text('Reset Filter', style: TextStyle(color: Colors.white)),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.orange,
                                      padding: const EdgeInsets.symmetric(vertical: 12),
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8)),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              // Data Table Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Data Barang (${filteredList.length} item)',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Data Table
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    headingRowColor: MaterialStateColor.resolveWith((states) => Colors.grey[50]!),
                    headingTextStyle: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                    dataRowHeight: 60,
                    columns: const [
                      DataColumn(label: Text('Kode Barang')),
                      DataColumn(label: Text('Nama Barang')),
                      DataColumn(label: Text('Bahan')),
                      DataColumn(label: Text('Merk')),
                      DataColumn(label: Text('Kondisi')),
                      DataColumn(label: Text('Tahun')),
                      DataColumn(label: Text('Aksi')),
                    ],
                    rows: filteredList.map((item) {
                      return DataRow(
                        cells: [
                          DataCell(
                            Text(
                              item['kode_barang'] ?? '-',
                              style: const TextStyle(fontWeight: FontWeight.w500),
                            ),
                          ),
                          DataCell(Text(item['nama_barang'] ?? '-')),
                          DataCell(Text(item['material'] ?? '-')),
                          DataCell(Text(item['merk'] ?? '-')),
                          DataCell(
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Color.fromARGB(
                                  (255 * 0.1).round(),
                                  _getConditionColor(item['kondisi']).red,
                                  _getConditionColor(item['kondisi']).green,
                                  _getConditionColor(item['kondisi']).blue,
                                ),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                item['kondisi'] ?? '-',
                                style: TextStyle(
                                  color: _getConditionColor(item['kondisi']),
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                          DataCell(Text(item['tahun']?.toString() ?? '-')),
                          DataCell(
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.blue[50],
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: IconButton(
                                    icon: const Icon(Icons.edit, color: Colors.blue, size: 18),
                                    onPressed: () => editBarang(item),
                                    tooltip: 'Edit',
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.red[50],
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: IconButton(
                                    icon: const Icon(Icons.delete, color: Colors.red, size: 18),
                                    onPressed: () => confirmDelete(item['id_barang']),
                                    tooltip: 'Hapus',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
              if (filteredList.isEmpty)
                Container(
                  margin: const EdgeInsets.only(top: 20),
                  padding: const EdgeInsets.all(40),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Column(
                      children: [
                        Icon(Icons.inventory_outlined, size: 64, color: Colors.grey),
                        SizedBox(height: 16),
                        Text(
                          'Tidak ada data barang',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getConditionColor(String? kondisi) {
    switch (kondisi?.toLowerCase()) {
      case 'baik':
        return Colors.green;
      case 'kurang baik':
      case 'rusak ringan':
        return Colors.orange;
      case 'rusak berat':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}
