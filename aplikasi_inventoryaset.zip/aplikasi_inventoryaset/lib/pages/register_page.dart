import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class RegisterPage extends StatefulWidget {
  const RegisterPage({super.key});

  @override
  State<RegisterPage> createState() => _RegisterPageState();
}

class _RegisterPageState extends State<RegisterPage> {
  final usernameController = TextEditingController();
  final passwordController = TextEditingController();
  final namaController = TextEditingController();
  bool isLoading = false;

  Future<void> register() async {
    setState(() => isLoading = true);

    final response = await http.post(
      Uri.parse("http://localhost/api_inventory/register.php"),
      body: {
        'username': usernameController.text,
        'password': passwordController.text,
        'nama_lengkap': namaController.text,
        'role': 'user',
      },
    );

    final result = json.decode(response.body);
    setState(() => isLoading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(result['message'])),
    );

    if (result['success']) {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F9FC),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Container(
            constraints: const BoxConstraints(maxWidth: 500),
            padding: const EdgeInsets.all(32),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              boxShadow: const [
                BoxShadow(
                  color: Colors.black12,
                  blurRadius: 10,
                  offset: Offset(2, 4),
                ),
              ],
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Center(
                  child: Text(
                    "Daftar Akun Baru",
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 24),
                const Text("Nama Lengkap"),
                const SizedBox(height: 6),
                TextField(
                  controller: namaController,
                  decoration: const InputDecoration(
                    hintText: "Masukkan nama lengkap",
                    border: OutlineInputBorder(),
                    filled: true,
                    fillColor: Color(0xFFF0F4F8),
                  ),
                ),
                const SizedBox(height: 16),
                const Text("Username"),
                const SizedBox(height: 6),
                TextField(
                  controller: usernameController,
                  decoration: const InputDecoration(
                    hintText: "Masukkan username",
                    border: OutlineInputBorder(),
                    filled: true,
                    fillColor: Color(0xFFF0F4F8),
                  ),
                ),
                const SizedBox(height: 16),
                const Text("Password"),
                const SizedBox(height: 6),
                TextField(
                  controller: passwordController,
                  obscureText: true,
                  decoration: const InputDecoration(
                    hintText: "Masukkan password",
                    border: OutlineInputBorder(),
                    filled: true,
                    fillColor: Color(0xFFF0F4F8),
                  ),
                ),
                const SizedBox(height: 24),
                SizedBox(
                  width: double.infinity,
                  height: 48,
                  child: ElevatedButton.icon(
                    onPressed: isLoading ? null : register,
                    icon: const Icon(Icons.person_add),
                    label: isLoading
                        ? const CircularProgressIndicator(color: Colors.white)
                        : const Text("Daftar"),
                  ),
                ),
                const SizedBox(height: 12),
                Center(
                  child: TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: const Text("Sudah punya akun? Kembali ke login"),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
