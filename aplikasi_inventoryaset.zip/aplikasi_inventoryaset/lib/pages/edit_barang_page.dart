import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class EditBarangPage extends StatefulWidget {
  final Map<String, dynamic> barang;

  const EditBarangPage({super.key, required this.barang});

  @override
  State<EditBarangPage> createState() => _EditBarangPageState();
}

class _EditBarangPageState extends State<EditBarangPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController kodeController;
  late TextEditingController namaController;
  late TextEditingController materialController;
  late TextEditingController merkController;
  late TextEditingController kondisiController;
  late TextEditingController tahunController;
  late TextEditingController lokasiController; // Tambahkan controller untuk lokasi

  // Opsi untuk dropdown
  List<String> _kondisiOptions = ['Baik', 'Kurang Baik', 'Rusak Ringan', 'Rusak Berat'];
  List<String> _lokasiOptions = []; // Akan diisi dari database/API atau fixed list
  List<String> _materialOptions = []; // Akan diisi dari database/API atau fixed list
  List<String> _merkOptions = []; // Akan diisi dari database/API atau fixed list

  @override
  void initState() {
    super.initState();
    kodeController = TextEditingController(text: widget.barang['kode_barang'] ?? '');
    namaController = TextEditingController(text: widget.barang['nama_barang'] ?? '');
    materialController = TextEditingController(text: widget.barang['material'] ?? '');
    merkController = TextEditingController(text: widget.barang['merk'] ?? '');
    kondisiController = TextEditingController(text: widget.barang['kondisi'] ?? '');
    tahunController = TextEditingController(text: widget.barang['tahun']?.toString() ?? '');
    lokasiController = TextEditingController(text: widget.barang['lokasi'] ?? ''); // Inisialisasi lokasi

    _fetchDropdownOptions(); // Panggil fungsi untuk mengisi opsi dropdown
  }

  // Fungsi untuk mengambil semua barang untuk mengisi opsi dropdown unik
  Future<List<dynamic>> _getAllBarangForDropdowns() async {
    try {
      final response = await http.get(Uri.parse('http://192.168.88.9/api_inventory/get_barang.php')); // Ganti dengan endpoint Anda
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          return data['barang'];
        }
      }
    } catch (e) {
      debugPrint('Error fetching all barang for dropdowns: $e');
    }
    return [];
  }

  Future<void> _fetchDropdownOptions() async {
    List<dynamic> allBarang = await _getAllBarangForDropdowns();

    setState(() {
      // Mengisi opsi dropdown dari data barang yang ada
      _lokasiOptions = allBarang.map((e) => e['lokasi'].toString()).toSet().toList().where((e) => e.isNotEmpty).toList();
      _materialOptions = allBarang.map((e) => e['material'].toString()).toSet().toList().where((e) => e.isNotEmpty).toList();
      _merkOptions = allBarang.map((e) => e['merk'].toString()).toSet().toList().where((e) => e.isNotEmpty).toList();
      // Tambahkan opsi default jika tidak ada data dari server
      if (_lokasiOptions.isEmpty) _lokasiOptions.add(lokasiController.text);
      if (_materialOptions.isEmpty) _materialOptions.add(materialController.text);
      if (_merkOptions.isEmpty) _merkOptions.add(merkController.text);

      // Pastikan nilai saat ini ada dalam opsi jika belum ada
      if (lokasiController.text.isNotEmpty && !_lokasiOptions.contains(lokasiController.text)) {
        _lokasiOptions.add(lokasiController.text);
      }
      if (materialController.text.isNotEmpty && !_materialOptions.contains(materialController.text)) {
        _materialOptions.add(materialController.text);
      }
      if (merkController.text.isNotEmpty && !_merkOptions.contains(merkController.text)) {
        _merkOptions.add(merkController.text);
      }
    });
  }

  Future<void> updateBarang() async {
    if (!_formKey.currentState!.validate()) {
      return; // Stop jika validasi gagal
    }

    try {
      final response = await http.post(
        Uri.parse('http://localhost/api_inventory/update_barang.php'), // Sesuaikan dengan URL API Anda
        body: {
          'id_barang': widget.barang['id_barang'].toString(),
          'kode_barang': kodeController.text,
          'nama_barang': namaController.text,
          'material': materialController.text,
          'merk': merkController.text,
          'kondisi': kondisiController.text,
          'tahun': tahunController.text,
          'lokasi': lokasiController.text, // Tambahkan lokasi
        },
      );

      final data = json.decode(response.body);
      if (data['success'] == true) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Data berhasil diperbarui!'),
            backgroundColor: Color.fromARGB(255, 113, 148, 236),
          ),
        );
        Navigator.pop(context, true); // kirim balik tanda sukses
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(data['message'] ?? 'Gagal memperbarui data.'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      debugPrint('Error updating barang: $e'); // Untuk debugging
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Terjadi kesalahan: ${e.toString()}'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  void dispose() {
    kodeController.dispose();
    namaController.dispose();
    materialController.dispose();
    merkController.dispose();
    kondisiController.dispose();
    tahunController.dispose();
    lokasiController.dispose(); // Dispose lokasi controller
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text(
          'Edit Barang',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
        backgroundColor: const Color.fromARGB(255, 127, 178, 250), // Warna yang lebih gelap sedikit dari teal
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildTextField(
                controller: kodeController,
                label: 'Kode Barang',
                icon: Icons.qr_code,
              ),
              const SizedBox(height: 16),
              _buildTextField(
                controller: namaController,
                label: 'Nama Barang',
                icon: Icons.inventory,
              ),
              const SizedBox(height: 16),
              _buildDropdownField(
                controller: materialController,
                label: 'Material',
                icon: Icons.science,
                options: _materialOptions,
                hintText: 'Pilih Material',
              ),
              const SizedBox(height: 16),
              _buildDropdownField(
                controller: merkController,
                label: 'Merk',
                icon: Icons.branding_watermark,
                options: _merkOptions,
                hintText: 'Pilih Merk',
              ),
              const SizedBox(height: 16),
              _buildDropdownField(
                controller: kondisiController,
                label: 'Kondisi',
                icon: Icons.medical_services,
                options: _kondisiOptions,
                hintText: 'Pilih Kondisi',
              ),
              const SizedBox(height: 16),
              _buildTextField(
                controller: tahunController,
                label: 'Tahun Perolehan',
                icon: Icons.calendar_today,
                keyboardType: TextInputType.number,
              ),
              const SizedBox(height: 16),
              _buildDropdownField(
                controller: lokasiController,
                label: 'Lokasi',
                icon: Icons.location_on,
                options: _lokasiOptions,
                hintText: 'Pilih Lokasi',
              ),
              const SizedBox(height: 30),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: updateBarang,
                  icon: const Icon(Icons.save, color: Colors.white),
                  label: const Text(
                    'Simpan Perubahan',
                    style: TextStyle(color: Colors.white, fontSize: 16),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: const Color.fromARGB(255, 0, 12, 150), // Gunakan warna teal
                    padding: const EdgeInsets.symmetric(vertical: 15),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // Widget pembantu untuk TextFormField yang lebih baik
  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    IconData? icon,
    TextInputType? keyboardType,
  }) {
    return TextFormField(
      controller: controller,
      keyboardType: keyboardType,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        prefixIcon: icon != null ? Icon(icon) : null,
        filled: true,
        fillColor: Colors.teal.shade50, // Warna latar belakang field
      ),
      validator: (value) {
        if (value == null || value.isEmpty) {
          return '$label tidak boleh kosong';
        }
        if (keyboardType == TextInputType.number && int.tryParse(value) == null) {
          return 'Masukkan angka yang valid untuk $label';
        }
        return null;
      },
    );
  }

  // Widget pembantu untuk DropdownButtonFormField
  Widget _buildDropdownField({
    required TextEditingController controller,
    required String label,
    IconData? icon,
    required List<String> options,
    String? hintText,
  }) {
    return DropdownButtonFormField<String>(
      value: controller.text.isNotEmpty && options.contains(controller.text)
          ? controller.text
          : (options.isNotEmpty ? options.first : null), // Pastikan nilai saat ini ada dalam opsi atau default
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
        prefixIcon: icon != null ? Icon(icon) : null,
        filled: true,
        fillColor: Colors.teal.shade50,
      ),
      items: options.map((String option) {
        return DropdownMenuItem<String>(
          value: option,
          child: Text(option),
        );
      }).toList(),
      onChanged: (String? newValue) {
        if (newValue != null) {
          setState(() {
            controller.text = newValue;
          });
        }
      },
      validator: (value) {
        if (value == null || value.isEmpty) {
          return '$label tidak boleh kosong';
        }
        return null;
      },
      hint: hintText != null ? Text(hintText) : null,
    );
  }
}