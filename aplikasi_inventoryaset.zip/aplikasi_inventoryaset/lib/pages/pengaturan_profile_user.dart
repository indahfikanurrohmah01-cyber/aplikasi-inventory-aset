import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';

// Import pages
import 'package:aplikasi_inventoryaset/pages/daftar_barang_user_page.dart';
import 'package:aplikasi_inventoryaset/pages/daftar_ruangan_page.dart';
import 'package:aplikasi_inventoryaset/pages/status_permintaan_page.dart';
import 'package:aplikasi_inventoryaset/pages/laporan_saya_page.dart';

// Utils
import 'background_wrapper.dart';
import '../utils/placeholder_page.dart';

class PengaturanProfilUserPage extends StatefulWidget {
  const PengaturanProfilUserPage({super.key});

  @override
  State<PengaturanProfilUserPage> createState() => _PengaturanProfilUserPageState();
}

class _PengaturanProfilUserPageState extends State<PengaturanProfilUserPage> {
  final _formKey = GlobalKey<FormState>();

  // Controllers
  final TextEditingController namaController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController currentPassController = TextEditingController();
  final TextEditingController newPassController = TextEditingController();
  final TextEditingController confirmPassController = TextEditingController();

  bool isLoading = false;
  bool isPasswordVisible = false;
  bool isNewPasswordVisible = false;
  bool isConfirmPasswordVisible = false;
  bool isEditingPassword = false;

  String idUser = "user_123"; // Dummy userId
  String? profileImageUrl;
  File? _selectedImage;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    fetchProfile();
  }

  @override
  void dispose() {
    namaController.dispose();
    emailController.dispose();
    phoneController.dispose();
    addressController.dispose();
    currentPassController.dispose();
    newPassController.dispose();
    confirmPassController.dispose();
    super.dispose();
  }

  Future<void> fetchProfile() async {
    setState(() => isLoading = true);
    try {
      await Future.delayed(const Duration(seconds: 1));
      final result = {
        'success': true,
        'user': {
          'nama_lengkap': 'Nama Pengguna',
          'email': 'user@example.com',
          'phone': '081234567890',
          'address': 'Jl. Contoh No.1, Kota Anda',
          'profile_image': 'https://via.placeholder.com/150/FF0000/FFFFFF?text=US',
        }
      };
      if (result['success'] == true) {
        final user = result['user'] as Map<String, dynamic>;
        namaController.text = user['nama_lengkap'] ?? '';
        emailController.text = user['email'] ?? '';
        phoneController.text = user['phone'] ?? '';
        addressController.text = user['address'] ?? '';
        profileImageUrl = user['profile_image'];
      } else {
        _showSnackBar(result['message'] as String, isError: true);
      }
    } catch (e) {
      _showSnackBar('Terjadi kesalahan saat memuat profil: $e', isError: true);
    }
    setState(() => isLoading = false);
  }

  Future<void> updateProfile() async {
    if (!_formKey.currentState!.validate()) return;
    if (isEditingPassword) {
      if (newPassController.text != confirmPassController.text) {
        _showSnackBar('Password baru dan konfirmasi password tidak cocok', isError: true);
        return;
      }
      if (newPassController.text.length < 6) {
        _showSnackBar('Password baru minimal 6 karakter', isError: true);
        return;
      }
    }
    final data = {
      "id_user": idUser,
      "nama_lengkap": namaController.text.trim(),
      "email": emailController.text.trim(),
      "phone": phoneController.text.trim(),
      "address": addressController.text.trim(),
      if (isEditingPassword) ...{
        "current_password": currentPassController.text,
        "new_password": newPassController.text,
      }
    };
    setState(() => isLoading = true);
    try {
      await Future.delayed(const Duration(seconds: 1));
      final result = {'success': true, 'message': 'Profil berhasil diperbarui!'};
      _showSnackBar(result['message'] as String, isError: !(result['success'] == true));
      if (result['success'] == true) {
        currentPassController.clear();
        newPassController.clear();
        confirmPassController.clear();
        setState(() => isEditingPassword = false);
      }
    } catch (e) {
      _showSnackBar('Terjadi kesalahan saat menyimpan profil: $e', isError: true);
    }
    setState(() => isLoading = false);
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red[600] : Colors.green[600],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  Future<void> _navigateToPage(String routeName, String pageName) async {
    Navigator.pop(context);

    // Jika sudah di halaman yang sama, tidak perlu navigasi
    if (routeName == '/pengaturan-profil-user') {
      return;
    }

    switch (routeName) {
      case '/dashboard':
        Navigator.pushReplacementNamed(context, '/user-dashboard');
        break;

      case '/daftar-barang-user':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const DaftarBarangUserPage()),
        );
        break;

      case '/daftar-ruangan-user':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const DaftarRuanganPage()),
        );
        break;

      case '/laporan-saya':
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => const LaporanSayaPage()),
        );
        break;

      case '/status-permintaan':
        final prefs = await SharedPreferences.getInstance();
        final userId = prefs.getInt('user_id')?.toString() ?? '0';
        if (!mounted) return;
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => StatusPermintaanPage(userId: userId)),
        );
        break;

      case '/riwayat-pemakaian':
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PlaceholderPage(title: 'Riwayat Pemakaian'),
          ),
        );
        break;

      default:
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => PlaceholderPage(title: pageName)),
        );
    }
  }

  // Fungsi untuk handle logout dengan konfirmasi
  Future<void> _handleLogout() async {
    final bool? shouldLogout = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.logout, color: Colors.red),
              SizedBox(width: 8),
              Text('Konfirmasi Logout'),
            ],
          ),
          content: const Text('Apakah Anda yakin ingin keluar dari aplikasi?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );
    if (shouldLogout == true) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.clear();
        if (mounted) {
          Navigator.pushReplacementNamed(context, '/');
        }
      } catch (e) {
        _showSnackBar('Gagal logout. Silakan coba lagi.', isError: true);
      }
    }
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Column(
        children: [
          // Drawer Header
          Container(
            height: 200,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Colors.blue[600]!, Colors.blue[800]!],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/diskominfo.jpg',
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return const Icon(
                              Icons.inventory_2,
                              size: 30,
                              color: Colors.blue,
                            );
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'INVENTRIS',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Text(
                      'Sistem Manajemen Inventaris',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Menu Items
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _drawerItem(Icons.dashboard, 'Dashboard', '/dashboard', false),
                // User Section
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'PENGGUNA',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                _drawerItem(Icons.inventory_2, 'Data Barang', '/daftar-barang-user', false),
                _drawerItem(Icons.meeting_room, 'Data Ruangan', '/daftar-ruangan-user', false),
                _drawerItem(Icons.assignment, 'Laporan Saya', '/laporan-saya', false),
                _drawerItem(Icons.pending_actions, 'Status Permintaan', '/status-permintaan', false),
                _drawerItem(Icons.history, 'Riwayat Pemakaian', '/riwayat-pemakaian', false),
                // Settings Section
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'PENGATURAN',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                _drawerItem(Icons.settings, 'Pengaturan Profil', '/pengaturan-profil-user', true),
              ],
            ),
          ),
          // Logout Section
          Container(
            padding: const EdgeInsets.all(16),
            child: _drawerItem(Icons.logout, 'Logout', '', false, isLogout: true),
          ),
        ],
      ),
    );
  }

  Widget _drawerItem(IconData icon, String title, String route, bool isSelected, {bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: ListTile(
        leading: Icon(
          icon,
          color: isLogout
              ? Colors.red
              : isSelected
                  ? Colors.blue
                  : Colors.grey[600],
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isLogout
                ? Colors.red
                : isSelected
                    ? Colors.blue
                    : Colors.grey[800],
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        selected: isSelected,
        selectedTileColor: Colors.blue[50],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        onTap: () {
          if (isLogout) {
            _handleLogout();
          } else if (route.isNotEmpty) {
            _navigateToPage(route, title);
          } else {
            Navigator.pop(context);
          }
        },
      ),
    );
  }

  Widget _buildProfileHeader() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue[600]!, Colors.blue[400]!],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Stack(
            children: [
              CircleAvatar(
                radius: 40,
                backgroundColor: Colors.white,
                backgroundImage: _selectedImage != null
                    ? FileImage(_selectedImage!)
                    : (profileImageUrl != null
                            ? NetworkImage(profileImageUrl!)
                            : null) as ImageProvider<Object>?,
                child: _selectedImage == null && profileImageUrl == null
                    ? Icon(Icons.person, size: 40, color: Colors.blue[600])
                    : null,
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: IconButton(
                    icon: Icon(Icons.camera_alt, color: Colors.blue[600], size: 20),
                    onPressed: () {
                      _showImagePickerDialog();
                    },
                    padding: const EdgeInsets.all(8),
                    constraints: const BoxConstraints(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  namaController.text.isNotEmpty ? namaController.text : 'Nama Pengguna',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  emailController.text.isNotEmpty ? emailController.text : 'email@example.com',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
    bool obscureText = false,
    bool? isPasswordVisible,
    VoidCallback? toggleVisibility,
    int maxLines = 1,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        validator: validator,
        obscureText: obscureText && !(isPasswordVisible ?? false),
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: Colors.blue[600]),
          suffixIcon: toggleVisibility != null
              ? IconButton(
                  icon: Icon(
                    (isPasswordVisible ?? false) ? Icons.visibility : Icons.visibility_off,
                    color: Colors.grey[600],
                  ),
                  onPressed: toggleVisibility,
                )
              : null,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey[300]!),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey[300]!),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.blue[600]!, width: 2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Colors.red, width: 2),
          ),
          filled: true,
          fillColor: Colors.grey[50],
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }

  Widget _buildSectionCard({required String title, required List<Widget> children}) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            const SizedBox(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }

  void _showImagePickerDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Row(
            children: [
              Icon(Icons.camera_alt, color: Colors.blue[600]),
              const SizedBox(width: 8),
              const Text('Pilih Foto Profil'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text('Ambil Foto'),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('Pilih dari Galeri'),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Batal',
                style: TextStyle(color: Colors.grey[600]),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 80,
      );
      if (pickedFile != null) {
        setState(() {
          _selectedImage = File(pickedFile.path);
        });
        _showSnackBar('Foto berhasil dipilih');
      }
    } catch (e) {
      _showSnackBar('Gagal memilih foto: $e', isError: true);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text(
          'Pengaturan Profil',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light,
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Row(
              children: [
                const Icon(Icons.person, color: Colors.white),
                const SizedBox(width: 8),
                const Text(
                  'Halo User',
                  style: TextStyle(color: Colors.white, fontSize: 14),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 16),
                ),
              ],
            ),
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: GradientBackgroundWrapper(
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : Form(
                key: _formKey,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _buildProfileHeader(),
                      const SizedBox(height: 24),
                      _buildSectionCard(
                        title: 'Informasi Pribadi',
                        children: [
                          _buildTextField(
                            controller: namaController,
                            label: 'Nama Lengkap',
                            icon: Icons.person,
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'Nama lengkap tidak boleh kosong';
                              }
                              return null;
                            },
                          ),
                          _buildTextField(
                            controller: emailController,
                            label: 'Email',
                            icon: Icons.email,
                            keyboardType: TextInputType.emailAddress,
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'Email tidak boleh kosong';
                              }
                              if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
                                return 'Format email tidak valid';
                              }
                              return null;
                            },
                          ),
                          _buildTextField(
                            controller: phoneController,
                            label: 'Nomor Telepon',
                            icon: Icons.phone,
                            keyboardType: TextInputType.phone,
                            validator: (value) {
                              if (value != null && value.isNotEmpty) {
                                if (!RegExp(r'^[0-9+\-\s]+$').hasMatch(value)) {
                                  return 'Format nomor telepon tidak valid';
                                }
                              }
                              return null;
                            },
                          ),
                          _buildTextField(
                            controller: addressController,
                            label: 'Alamat',
                            icon: Icons.location_on,
                            maxLines: 3,
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                      _buildSectionCard(
                        title: 'Keamanan',
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Ubah Password',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[700],
                                ),
                              ),
                              Switch(
                                value: isEditingPassword,
                                onChanged: (value) {
                                  setState(() {
                                    isEditingPassword = value;
                                    if (!value) {
                                      currentPassController.clear();
                                      newPassController.clear();
                                      confirmPassController.clear();
                                    }
                                  });
                                },
                                activeColor: Colors.blue[600],
                              ),
                            ],
                          ),
                          if (isEditingPassword) ...[
                            const SizedBox(height: 16),
                            _buildTextField(
                              controller: currentPassController,
                              label: 'Password Saat Ini',
                              icon: Icons.lock_outline,
                              obscureText: true,
                              isPasswordVisible: isPasswordVisible,
                              toggleVisibility: () {
                                setState(() => isPasswordVisible = !isPasswordVisible);
                              },
                              validator: (value) {
                                if (isEditingPassword && (value == null || value.isEmpty)) {
                                  return 'Password saat ini tidak boleh kosong';
                                }
                                return null;
                              },
                            ),
                            _buildTextField(
                              controller: newPassController,
                              label: 'Password Baru',
                              icon: Icons.lock,
                              obscureText: true,
                              isPasswordVisible: isNewPasswordVisible,
                              toggleVisibility: () {
                                setState(() => isNewPasswordVisible = !isNewPasswordVisible);
                              },
                              validator: (value) {
                                if (isEditingPassword) {
                                  if (value == null || value.isEmpty) {
                                    return 'Password baru tidak boleh kosong';
                                  }
                                  if (value.length < 6) {
                                    return 'Password minimal 6 karakter';
                                  }
                                }
                                return null;
                              },
                            ),
                            _buildTextField(
                              controller: confirmPassController,
                              label: 'Konfirmasi Password Baru',
                              icon: Icons.lock_reset,
                              obscureText: true,
                              isPasswordVisible: isConfirmPasswordVisible,
                              toggleVisibility: () {
                                setState(() => isConfirmPasswordVisible = !isConfirmPasswordVisible);
                              },
                              validator: (value) {
                                if (isEditingPassword) {
                                  if (value == null || value.isEmpty) {
                                    return 'Konfirmasi password tidak boleh kosong';
                                  }
                                  if (value != newPassController.text) {
                                    return 'Password tidak cocok';
                                  }
                                }
                                return null;
                              },
                            ),
                          ],
                        ],
                      ),
                      const SizedBox(height: 32),
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: isLoading ? null : updateProfile,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[600],
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 2,
                          ),
                          child: isLoading
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                  ),
                                )
                              : const Text(
                                  'Simpan Perubahan',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          'Batal',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 16,
                          ),
                        ),
                      ),
                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}
