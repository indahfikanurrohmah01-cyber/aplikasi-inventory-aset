import 'package:flutter/material.dart';
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

// Background Wrapper Widget
class BackgroundWrapper extends StatelessWidget {
  final Widget child;
  final bool showOverlay;
  final double overlayOpacity;
  final Color overlayColor;

  const BackgroundWrapper({
    Key? key,
    required this.child,
    this.showOverlay = true,
    this.overlayOpacity = 0.85,
    this.overlayColor = Colors.white,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: NetworkImage('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-G0vswoxbNB5BxwViFb6VNhmskcXuly.png'),
          fit: BoxFit.cover,
        ),
      ),
      child: showOverlay
          ? Container(
              decoration: BoxDecoration(
                color: overlayColor.withOpacity(overlayOpacity),
              ),
              child: child,
            )
          : child,
    );
  }
}

class StatusPermintaanPage extends StatefulWidget {
  final String userId;
  const StatusPermintaanPage({Key? key, required this.userId}) : super(key: key);

  @override
  State<StatusPermintaanPage> createState() => _StatusPermintaanPageState();
}

class _StatusPermintaanPageState extends State<StatusPermintaanPage> {
  List<Map<String, dynamic>> barangList = [];
  String selectedStatus = 'semua';
  final List<String> statusOptions = ['semua', 'pending', 'diterima', 'ditolak'];
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    fetchBarang();
  }

  Future<void> fetchBarang() async {
    setState(() {
      isLoading = true;
    });
    final url = Uri.parse(
      'http://localhost/api_inventory/get_barang_by_user.php?userId=${widget.userId}&status=$selectedStatus',
    );
    try {
      final response = await http.get(url);
      final data = json.decode(response.body);
      if (data['success']) {
        setState(() {
          barangList = List<Map<String, dynamic>>.from(data['barang']);
        });
      } else {
        setState(() {
          barangList = [];
        });
      }
    } catch (e) {
      setState(() {
        barangList = [];
      });
      print('Error: $e');
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'diterima':
        return Colors.green;
      case 'ditolak':
        return Colors.red;
      case 'diproses':
        return Colors.blue;
      default:
        return Colors.orange;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'diterima':
        return Icons.check_circle;
      case 'ditolak':
        return Icons.cancel;
      case 'diproses':
        return Icons.hourglass_empty;
      default:
        return Icons.access_time;
    }
  }

  String _getStatusText(String status) {
    switch (status.toLowerCase()) {
      case 'diterima':
        return 'DITERIMA';
      case 'ditolak':
        return 'DITOLAK';
      case 'diproses':
        return 'DIPROSES';
      default:
        return 'PENDING';
    }
  }

  Widget _buildFilterChips() {
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        itemCount: statusOptions.length,
        itemBuilder: (context, index) {
          final status = statusOptions[index];
          final isSelected = selectedStatus == status;
          return Padding(
            padding: const EdgeInsets.only(right: 8),
            child: FilterChip(
              label: Text(
                status.toUpperCase(),
                style: TextStyle(
                  color: isSelected ? Colors.white : Colors.blue[700],
                  fontWeight: FontWeight.w600,
                ),
              ),
              selected: isSelected,
              onSelected: (bool selected) {
                if (selected) {
                  setState(() {
                    selectedStatus = status;
                  });
                  fetchBarang();
                }
              },
              backgroundColor: Colors.blue[50],
              selectedColor: Colors.blue[700],
              checkmarkColor: Colors.white,
              elevation: isSelected ? 4 : 1,
              shadowColor: Colors.blue[200],
            ),
          );
        },
      ),
    );
  }

  Widget _buildBarangCard(Map<String, dynamic> barang) {
    final status = barang['status_permintaan'] ?? 'pending';
    final statusColor = _getStatusColor(status);
    final statusIcon = _getStatusIcon(status);
    final statusText = _getStatusText(status);
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Header with status badge
          Container(
            padding: const EdgeInsets.all(16),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.blue[50],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(
                    Icons.inventory_2,
                    color: Colors.blue[700],
                    size: 24,
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        barang['nama_barang'] ?? '-',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                          color: Colors.black87,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        barang['deskripsi'] ?? 'Tidak ada deskripsi',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: statusColor.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: statusColor.withOpacity(0.3)),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Icon(
                        statusIcon,
                        size: 16,
                        color: statusColor,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        statusText,
                        style: TextStyle(
                          color: statusColor,
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(width: 8),
                PopupMenuButton<String>(
                  icon: Icon(Icons.more_vert, color: Colors.grey[400]),
                  onSelected: (value) {
                    // Handle menu actions
                    switch (value) {
                      case 'detail':
                        _showDetailDialog(barang);
                        break;
                      case 'edit':
                        // Navigate to edit page
                        break;
                      case 'delete':
                        _showDeleteDialog(barang);
                        break;
                    }
                  },
                  itemBuilder: (BuildContext context) => [
                    const PopupMenuItem<String>(
                      value: 'detail',
                      child: Row(
                        children: [
                          Icon(Icons.info_outline, size: 20),
                          SizedBox(width: 8),
                          Text('Detail'),
                        ],
                      ),
                    ),
                    const PopupMenuItem<String>(
                      value: 'edit',
                      child: Row(
                        children: [
                          Icon(Icons.edit_outlined, size: 20),
                          SizedBox(width: 8),
                          Text('Edit'),
                        ],
                      ),
                    ),
                    const PopupMenuItem<String>(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete_outline, size: 20, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Hapus', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
          // Footer with additional info
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.grey[50],
              borderRadius: const BorderRadius.only(
                bottomLeft: Radius.circular(12),
                bottomRight: Radius.circular(12),
              ),
            ),
            child: Row(
              children: [
                Icon(
                  Icons.calendar_today,
                  size: 16,
                  color: Colors.grey[600],
                ),
                const SizedBox(width: 6),
                Text(
                  barang['tanggal'] ?? '29 July 2025',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[600],
                  ),
                ),
                const Spacer(),
                if (barang['stok'] != null) ...[
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: Colors.blue[100],
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Text(
                      '${barang['stok']} ${barang['satuan'] ?? 'unit'}',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                        color: Colors.blue[700],
                      ),
                    ),
                  ),
                ],
                const SizedBox(width: 8),
                Text(
                  'Tap untuk opsi',
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey[500],
                    fontStyle: FontStyle.italic,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showDetailDialog(Map<String, dynamic> barang) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(barang['nama_barang'] ?? 'Detail Barang'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Status: ${barang['status_permintaan'] ?? 'pending'}'),
            Text('Deskripsi: ${barang['deskripsi'] ?? 'Tidak ada deskripsi'}'),
            Text('Stok: ${barang['stok'] ?? '0'} ${barang['satuan'] ?? 'unit'}'),
            Text('Tanggal: ${barang['tanggal'] ?? 'Tidak ada tanggal'}'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  void _showDeleteDialog(Map<String, dynamic> barang) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Hapus Permintaan'),
        content: Text('Apakah Anda yakin ingin menghapus permintaan "${barang['nama_barang']}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () {
              Navigator.pop(context); // Tutup dialog konfirmasi
              // Add delete logic here
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Permintaan berhasil dihapus')),
              );
            },
            child: const Text('Hapus', style: TextStyle(color: Colors.red)),
          ),
        ],
      ),
    );
  }

  Widget _buildListView() {
    if (isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.blue[700]!),
            ),
            const SizedBox(height: 16),
            Text(
              'Memuat data...',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 16,
              ),
            ),
          ],
        ),
      );
    }
    if (barangList.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.inventory_2_outlined,
              size: 80,
              color: Colors.grey[300],
            ),
            const SizedBox(height: 16),
            Text(
              'Tidak ada data barang',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Belum ada permintaan barang untuk status ini',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[500],
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 20),
      itemCount: barangList.length,
      itemBuilder: (context, index) {
        return _buildBarangCard(barangList[index]);
      },
    );
  }

  Widget _drawerHeader() {
    return DrawerHeader(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.blue[700]!, Colors.blue[800]!],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: Colors.white,
            child: Icon(
              Icons.person,
              size: 35,
              color: Colors.blue[700],
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Halo, Indahfika',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            'User ID: ${widget.userId}',
            style: TextStyle(
              color: Colors.white.withOpacity(0.8),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  Widget _drawerSection(String title) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: Colors.grey[600],
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _drawerItem(IconData icon, String title, bool isActive, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: isActive ? Colors.blue[50] : null,
      ),
      child: ListTile(
        leading: Icon(
          icon,
          color: isActive ? Colors.blue[700] : Colors.grey[600],
          size: 22,
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isActive ? Colors.blue[700] : Colors.grey[700],
            fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
            fontSize: 14,
          ),
        ),
        onTap: onTap,
        dense: true,
        visualDensity: const VisualDensity(vertical: -2),
      ),
    );
  }

  void _navigate(String route, String title) {
  Navigator.pop(context); // Pastikan Drawer ditutup dulu

  Future.delayed(const Duration(milliseconds: 200), () {
    if (!mounted) return;

    switch (route) {
      case '/user-dashboard':
        Navigator.pushReplacementNamed(context, '/user-dashboard');
        break;
      case '/daftar-barang-user':
        Navigator.pushNamed(context, '/daftar-barang-user');
        break;
      case '/daftar-ruangan-user':
        Navigator.pushNamed(context, '/daftar-ruangan-user');
        break;
      case '/riwayat-pemakaian':
        Navigator.pushNamed(context, '/riwayat-pemakaian');
        break;
      case '/laporan-saya':
        Navigator.pushNamed(context, '/laporan-saya');
        break;
      case '/login-page':
        Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
        break;
      case '/pengaturan-profile':
        Navigator.pushNamed(context, '/pengaturan-profile-user');
        break;
      default:
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Route "$route" tidak ditemukan'),
            backgroundColor: Colors.red,
            duration: const Duration(seconds: 2),
          ),
        );
    }
  });
}


  void _logout() {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        title: Row(
          children: [
            Icon(Icons.logout, color: Colors.red[600]),
            const SizedBox(width: 8),
            const Text('Logout'),
          ],
        ),
        content: const Text('Apakah Anda yakin ingin keluar dari aplikasi?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Batal',
              style: TextStyle(color: Colors.grey[600]),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(context); // Tutup dialog konfirmasi
              // Tutup drawer jika sedang terbuka
              if (Scaffold.maybeOf(context)?.isDrawerOpen ?? false) {
                Navigator.of(context).pop(); // Tutup drawer
              }
              // Hapus semua data dari SharedPreferences
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              // Tampilkan notifikasi logout berhasil
              if (mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(
                    content: Text('Berhasil logout'),
                    backgroundColor: Colors.green,
                    duration: Duration(seconds: 1),
                  ),
                );
                // Arahkan ke halaman login dan hapus semua route sebelumnya
                Navigator.of(context).pushNamedAndRemoveUntil(
                  '/',
                  (Route<dynamic> route) => false,
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red[600],
              foregroundColor: Colors.white,
            ),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  void _showProfile() {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        title: const Text('Profil Pengguna'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.blue[100],
                  child: Icon(Icons.person, size: 30, color: Colors.blue[700]),
                ),
                const SizedBox(width: 16),
                const Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Indahfika',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      SizedBox(height: 4),
                      Text(
                        'indahfika@diskominfo.go.id',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 8),
            _buildProfileInfo('User ID', widget.userId),
            _buildProfileInfo('Role', 'User'),
            _buildProfileInfo('Status', 'Aktif'),
            _buildProfileInfo('Department', 'Diskominfo'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: Text(
              'Tutup',
              style: TextStyle(color: Colors.grey[600]),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(context);
              // Navigate to profile settings
              _navigate('/pengaturan-profile-user', 'Pengaturan Profil');
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue[700],
              foregroundColor: Colors.white,
            ),
            child: const Text('Edit Profil'),
          ),
        ],
      ),
    );
  }

  Widget _buildProfileInfo(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              '$label:',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.grey[700],
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BackgroundWrapper(
      child: Scaffold(
        backgroundColor: Colors.transparent,
        appBar: AppBar(
          elevation: 0,
          backgroundColor: Colors.blue[700],
          foregroundColor: Colors.white,
          title: const Text(
            'Status Permintaan',
            style: TextStyle(
              fontWeight: FontWeight.w600,
              fontSize: 18,
            ),
          ),
          actions: [
            IconButton(
              icon: const Icon(Icons.refresh),
              onPressed: fetchBarang,
              tooltip: 'Refresh',
            ),
            IconButton(
              icon: const Icon(Icons.person_outline),
              onPressed: _showProfile,
              tooltip: 'Profil',
            ),
            PopupMenuButton<String>(
              icon: const Icon(Icons.more_vert),
              onSelected: (value) {
                switch (value) {
                  case 'profile':
                    _showProfile();
                    break;
                  case 'settings':
                    _navigate('/pengaturan-profile', 'Pengaturan Profil');
                    break;
                  case 'logout':
                    _logout();
                    break;
                }
              },
              itemBuilder: (BuildContext context) => [
                const PopupMenuItem<String>(
                  value: 'profile',
                  child: Row(
                    children: [
                      Icon(Icons.person_outline, size: 20),
                      SizedBox(width: 8),
                      Text('Profil'),
                    ],
                  ),
                ),
                const PopupMenuItem<String>(
                  value: 'settings',
                  child: Row(
                    children: [
                      Icon(Icons.settings_outlined, size: 20),
                      SizedBox(width: 8),
                      Text('Pengaturan'),
                    ],
                  ),
                ),
                const PopupMenuItem<String>(
                  value: 'logout',
                  child: Row(
                    children: [
                      Icon(Icons.logout, size: 20, color: Colors.red),
                      SizedBox(width: 8),
                      Text('Logout', style: TextStyle(color: Colors.red)),
                    ],
                  ),
                ),
              ],
            ),
          ],
        ),
        drawer: Drawer(
          child: Column(
            children: [
              _drawerHeader(),
              Expanded(
                child: ListView(
                  padding: EdgeInsets.zero,
                  children: [
                    _drawerSection('DASHBOARD'),
                    _drawerItem(Icons.dashboard_outlined, 'Dashboard', false,
                        () => _navigate('/user-dashboard', 'Dashboard')),
                    _drawerSection('MANAJEMEN BARANG'),
                    _drawerItem(Icons.inventory_2_outlined, 'Daftar Barang', false,
                        () => _navigate('/daftar-barang-user', 'Daftar Barang')),
                    _drawerItem(Icons.location_city, 'Daftar Ruangan', false,
                        () => _navigate('/daftar-ruangan-user', 'Daftar Ruangan')),
                    _drawerItem(Icons.history, 'Riwayat Pemakaian', false,
                        () => _navigate('/riwayat-pemakaian', 'Riwayat Pemakaian')),
                    _drawerItem(Icons.receipt_long, 'Laporan Saya', false,
                        () => _navigate('/laporan-saya', 'Laporan Saya')),
                    _drawerItem(Icons.assignment_outlined, 'Status Permintaan', true,
                        () => {}), // Current page, no navigation
                    _drawerSection('PENGATURAN'),
                    _drawerItem(Icons.person_outline, 'Pengaturan Profil', false,
                        () => _navigate('/pengaturan-profile', 'Pengaturan Profil')),
                  ],
                ),
              ),
              Container(
                margin: const EdgeInsets.all(16),
                child: ListTile(
                  leading: Icon(Icons.logout, color: Colors.red[600]),
                  title: Text(
                    'Logout',
                    style: TextStyle(
                      color: Colors.red[600],
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  onTap: _logout,
                ),
              ),
            ],
          ),
        ),
        body: Column(
          children: [
            // Filter section
            Container(
              color: Colors.white.withOpacity(0.9),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
                    child: Text(
                      'Filter Status',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w600,
                        color: Colors.grey[700],
                      ),
                    ),
                  ),
                  _buildFilterChips(),
                  const SizedBox(height: 8),
                ],
              ),
            ),
            // Content
            Expanded(child: _buildListView()),
          ],
        ),
      ),
    );
  }
}