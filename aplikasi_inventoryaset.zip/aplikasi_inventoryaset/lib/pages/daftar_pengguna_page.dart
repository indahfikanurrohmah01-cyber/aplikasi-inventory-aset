import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'background_wrapper.dart'; // Import background wrapper

class DaftarPenggunaPage extends StatefulWidget {
  const DaftarPenggunaPage({Key? key}) : super(key: key);

  @override
  State<DaftarPenggunaPage> createState() => _DaftarPenggunaPageState();
}

class _DaftarPenggunaPageState extends State<DaftarPenggunaPage> {
  List<dynamic> penggunaList = [];
  List<dynamic> filteredList = [];
  String? role;
  final TextEditingController _usernameController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _namaLengkapController = TextEditingController();
  String? _selectedRole;
  String? _selectedIdUser;

  @override
  void initState() {
    super.initState();
    fetchPengguna();
  }

  @override
  void dispose() {
    _usernameController.dispose();
    _passwordController.dispose();
    _namaLengkapController.dispose();
    super.dispose();
  }

  Future<void> fetchPengguna() async {
    try {
      final response = await http.get(Uri.parse('http://localhost/api_inventory/get_pengguna.php'));
      if (!mounted) return; // Check if widget is still mounted
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          setState(() {
            penggunaList = data['users'];
            filteredList = penggunaList;
          });
        }
      }
    } catch (e) {
      if (!mounted) return; // Check if widget is still mounted
      debugPrint('Error fetching: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal memuat data pengguna: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> addPengguna() async {
    final response = await http.post(
      Uri.parse('http://localhost/api_inventory/tambah_pengguna.php'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'username': _usernameController.text,
        'password': _passwordController.text,
        'nama_lengkap': _namaLengkapController.text,
        'role': _selectedRole,
      }),
    );
    if (!mounted) return; // Check if widget is still mounted
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(data['message']),
            backgroundColor: Colors.green,
          ),
        );
        fetchPengguna();
        Navigator.pop(context);
        _clearControllers();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(data['message'] ?? 'Gagal menambahkan pengguna'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> editPengguna() async {
    final response = await http.post(
      Uri.parse('http://localhost/api_inventory/edit_pengguna.php'),
      headers: {'Content-Type': 'application/json'},
      body: json.encode({
        'id_user': _selectedIdUser,
        'username': _usernameController.text,
        'password': _passwordController.text.isEmpty ? null : _passwordController.text,
        'nama_lengkap': _namaLengkapController.text,
        'role': _selectedRole,
      }),
    );
    if (!mounted) return; // Check if widget is still mounted
    if (response.statusCode == 200) {
      final data = json.decode(response.body);
      if (data['success'] == true) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(data['message']),
            backgroundColor: Colors.green,
          ),
        );
        fetchPengguna();
        Navigator.pop(context);
        _clearControllers();
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(data['message'] ?? 'Gagal mengedit pengguna'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> deletePengguna(String idUser) async {
    bool? confirm = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.warning, color: Colors.orange),
              SizedBox(width: 8),
              Text('Konfirmasi Hapus'),
            ],
          ),
          content: const Text('Apakah Anda yakin ingin menghapus pengguna ini?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Hapus'),
            ),
          ],
        );
      },
    );
    if (!mounted) return; // Check if widget is still mounted
    if (confirm == true) {
      final response = await http.post(
        Uri.parse('http://localhost/api_inventory/hapus_pengguna.php'),
        body: {'id_user': idUser},
      );
      if (!mounted) return; // Check if widget is still mounted
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Pengguna berhasil dihapus'),
              backgroundColor: Colors.green,
            ),
          );
          fetchPengguna();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Gagal menghapus pengguna'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    }
  }

  void _clearControllers() {
    _usernameController.clear();
    _passwordController.clear();
    _namaLengkapController.clear();
    _selectedRole = null;
    _selectedIdUser = null;
  }

  void _showAddPenggunaDialog() {
    _clearControllers();
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: const Row(
                children: [
                  Icon(Icons.person_add, color: Colors.blue),
                  SizedBox(width: 8),
                  Text("Tambah Pengguna"),
                ],
              ),
              content: SingleChildScrollView(
                child: SizedBox(
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildTextField(_usernameController, 'Username', Icons.person),
                      const SizedBox(height: 16),
                      _buildTextField(_passwordController, 'Password', Icons.lock, obscureText: true),
                      const SizedBox(height: 16),
                      _buildTextField(_namaLengkapController, 'Nama Lengkap', Icons.badge),
                      const SizedBox(height: 16),
                      _buildDropdown("Pilih Role", ['admin', 'user'], _selectedRole, (newValue) {
                        setState(() {
                          _selectedRole = newValue;
                        });
                      }),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Batal'),
                ),
                ElevatedButton(
                  onPressed: addPengguna,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Tambah'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showEditPenggunaDialog(dynamic pengguna) {
    _usernameController.text = pengguna['username'];
    _passwordController.text = ''; // Clear password for security, user can re-enter if needed
    _namaLengkapController.text = pengguna['nama_lengkap'];
    _selectedRole = pengguna['role'];
    _selectedIdUser = pengguna['id_user'];

    showDialog(
      context: context,
      builder: (BuildContext context) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: const Row(
                children: [
                  Icon(Icons.edit, color: Colors.orange),
                  SizedBox(width: 8),
                  Text("Edit Pengguna"),
                ],
              ),
              content: SingleChildScrollView(
                child: SizedBox(
                  width: MediaQuery.of(context).size.width * 0.8,
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildTextField(_usernameController, 'Username', Icons.person),
                      const SizedBox(height: 16),
                      _buildTextField(_passwordController, 'Password (kosongkan jika tidak diubah)', Icons.lock, obscureText: true),
                      const SizedBox(height: 16),
                      _buildTextField(_namaLengkapController, 'Nama Lengkap', Icons.badge),
                      const SizedBox(height: 16),
                      _buildDropdown("Pilih Role", ['admin', 'user'], _selectedRole, (newValue) {
                        setState(() {
                          _selectedRole = newValue;
                        });
                      }),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context),
                  child: const Text('Batal'),
                ),
                ElevatedButton(
                  onPressed: editPengguna,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Simpan'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon, {bool obscureText = false}) {
    return TextFormField(
      controller: controller,
      obscureText: obscureText,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.blue[600]),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blue[600]!, width: 2),
        ),
        filled: true,
        fillColor: Colors.grey[50],
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      ),
      validator: (value) {
        if (value == null || value.isEmpty) return 'Field tidak boleh kosong';
        return null;
      },
    );
  }

  Widget _buildDropdown(String label, List<String> items, String? selected, ValueChanged<String?> onChanged) {
    return DropdownButtonFormField<String>(
      value: selected,
      items: items.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
      onChanged: onChanged,
      decoration: InputDecoration(
        labelText: label,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.grey[300]!),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(12),
          borderSide: BorderSide(color: Colors.blue[600]!, width: 2),
        ),
        filled: true,
        fillColor: Colors.grey[50],
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
      ),
      validator: (value) => value == null || value.isEmpty ? 'Harus dipilih' : null,
    );
  }

  Widget _buildStatCard(String title, int count, IconData icon, Color color) {
    return Container(
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(0.1),
            spreadRadius: 1,
            blurRadius: 6,
            offset: const Offset(0, 3),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: color.withOpacity(0.1),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: color, size: 24),
          ),
          const SizedBox(width: 16),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: const TextStyle(
                    fontSize: 14,
                    color: Colors.grey,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  count.toString(),
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                    color: Colors.black87,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Column(
        children: [
          // Drawer Header
          Container(
            height: 200,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Colors.blue[600]!, Colors.blue[800]!],
              ),
            ),
            child: const SafeArea(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.white,
                      child: Icon(
                        Icons.inventory_2,
                        size: 30,
                        color: Colors.blue,
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      'INVENES',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'Inventory Management',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Menu Items
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _buildDrawerItem(
                  icon: Icons.dashboard,
                  title: 'Dashboard',
                  route: '/dashboard',
                  isSelected: false,
                ),
                // Management Section
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'MANAJEMEN',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                _buildDrawerItem(
                  icon: Icons.inventory,
                  title: 'Data Barang',
                  route: '/daftar-barang',
                  isSelected: false,
                ),
                _buildDrawerItem(
                  icon: Icons.category,
                  title: 'Data Perolehan',
                  route: '/daftar-perolehan',
                  isSelected: false,
                ),
                _buildDrawerItem(
                  icon: Icons.meeting_room,
                  title: 'Data Ruangan',
                  route: '/daftar-ruangan',
                  isSelected: false,
                ),
                _buildDrawerItem(
                  icon: Icons.people,
                  title: 'Data Pengguna',
                  route: '/daftar-pengguna',
                  isSelected: true, // Current page
                ),
                // Settings Section
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'PENGATURAN',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                _buildDrawerItem(
                  icon: Icons.person_outline, // Changed icon for profile settings
                  title: 'Pengaturan Profil',
                  route: '/pengaturan-profil',
                  isSelected: false,
                ),
                _buildDrawerItem(
                  icon: Icons.admin_panel_settings_outlined, // Changed icon for roles
                  title: 'Peran & Hak Akses',
                  route: '/peran-hak-akses',
                  isSelected: false,
                ),
                _buildDrawerItem(
                  icon: Icons.help,
                  title: 'Bantuan & Kontak',
                  route: '/bantuan-kontak', // Placeholder route
                  isSelected: false,
                ),
              ],
            ),
          ),
          // Logout Section
          Container(
            padding: const EdgeInsets.all(16),
            child: _buildDrawerItem(
              icon: Icons.logout,
              title: 'Logout',
              route: '/', // Route to login page
              isSelected: false,
              isLogout: true,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDrawerItem({
    required IconData icon,
    required String title,
    required String route,
    required bool isSelected,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: ListTile(
        leading: Icon(
          icon,
          color: isLogout
              ? Colors.red
              : isSelected
                  ? Colors.blue[600] // Use a specific blue shade for selected
                  : Colors.grey[600],
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isLogout
                ? Colors.red
                : isSelected
                    ? Colors.blue[700] // Use a darker blue for selected text
                    : Colors.grey[800],
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        selected: isSelected,
        selectedTileColor: Colors.blue[50],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        onTap: () {
          if (isLogout) {
            _showLogoutDialog();
          } else if (route.isNotEmpty) {
            Navigator.pop(context); // Close drawer
            Navigator.pushReplacementNamed(context, route);
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Halaman belum tersedia'),
                backgroundColor: Colors.orange,
              ),
            );
          }
        },
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.logout, color: Colors.red),
              SizedBox(width: 8),
              Text('Konfirmasi Logout'),
            ],
          ),
          content: const Text('Apakah Anda yakin ingin keluar dari aplikasi?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                // Navigate back to login page and remove all routes
                Navigator.pushNamedAndRemoveUntil(
                  context,
                  '/',
                  (route) => false,
                );
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );
  }

  int get totalAdmin => penggunaList.where((user) => user['role'] == 'admin').length;
  int get totalUser => penggunaList.where((user) => user['role'] == 'user').length;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent, // Set to transparent for background wrapper
      appBar: AppBar(
        title: const Text(
          'Daftar Pengguna',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blue[600],
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
                dropdownColor: Colors.white,
                style: const TextStyle(color: Colors.black),
                onChanged: (value) {
                  if (value == 'profil') {
                    Navigator.pushNamed(context, '/pengaturan-profile');
                  } else if (value == 'logout') {
                    _showLogoutDialog();
                  }
                },
                items: const [
                  DropdownMenuItem(value: 'profil', child: Text('Pengaturan Profil')),
                  DropdownMenuItem(value: 'logout', child: Text('Logout')),
                ],
                hint: const Row(
                  children: [
                    Icon(Icons.person, color: Colors.white),
                    SizedBox(width: 8),
                    Text(
                      "Halo Administrator",
                      style: TextStyle(color: Colors.white, fontSize: 14),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: GradientBackgroundWrapper( // Apply background wrapper
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Statistics Cards
              Row(
                children: [
                  Expanded(
                    child: _buildStatCard(
                      'Total Administrator',
                      totalAdmin,
                      Icons.admin_panel_settings,
                      Colors.blue,
                    ),
                  ),
                  const SizedBox(width: 16),
                  Expanded(
                    child: _buildStatCard(
                      'Total User',
                      totalUser,
                      Icons.people,
                      Colors.green,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 24),
              // Add Button and Table Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    'Data Pengguna',
                    style: TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  ElevatedButton.icon(
                    onPressed: _showAddPenggunaDialog,
                    icon: const Icon(Icons.add, color: Colors.white),
                    label: const Text(
                      'Tambah Data',
                      style: TextStyle(color: Colors.white),
                    ),
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue[600],
                      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Data Table
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    headingRowColor: MaterialStateProperty.all(Colors.grey[50]),
                    headingTextStyle: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                    dataRowHeight: 60,
                    columns: const [
                      DataColumn(label: Text('Nama Lengkap')),
                      DataColumn(label: Text('Username')),
                      DataColumn(label: Text('Role')),
                      DataColumn(label: Text('Tanggal Ditambahkan')),
                      DataColumn(label: Text('Aksi')),
                    ],
                    rows: filteredList.map((item) {
                      return DataRow(
                        cells: [
                          DataCell(
                            Text(
                              item['nama_lengkap'] ?? '-',
                              style: const TextStyle(fontWeight: FontWeight.w500),
                            ),
                          ),
                          DataCell(Text(item['username'] ?? '-')),
                          DataCell(
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: item['role'] == 'admin' ? Colors.blue[100] : Colors.green[100],
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                (item['role'] ?? '-').toUpperCase(),
                                style: TextStyle(
                                  color: item['role'] == 'admin' ? Colors.blue[800] : Colors.green[800],
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                          DataCell(
                            Text(
                              item['created_at']?.toString().split(' ')[0] ?? '-',
                              style: const TextStyle(color: Colors.grey),
                            ),
                          ),
                          DataCell(
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.blue[50],
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: IconButton(
                                    icon: const Icon(Icons.edit, color: Colors.blue, size: 18),
                                    onPressed: () => _showEditPenggunaDialog(item),
                                    tooltip: 'Edit',
                                  ),
                                ),
                                const SizedBox(width: 8),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.red[50],
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: IconButton(
                                    icon: const Icon(Icons.delete, color: Colors.red, size: 18),
                                    onPressed: () => deletePengguna(item['id_user']),
                                    tooltip: 'Hapus',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
              if (filteredList.isEmpty)
                Container(
                  margin: const EdgeInsets.only(top: 20),
                  padding: const EdgeInsets.all(40),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Column(
                      children: [
                        Icon(Icons.people_outline, size: 64, color: Colors.grey),
                        SizedBox(height: 16),
                        Text(
                          'Belum ada data pengguna',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
