import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shared_preferences/shared_preferences.dart'; // Import SharedPreferences
import 'package:image_picker/image_picker.dart';
import 'background_wrapper.dart'; // Import background wrapper
import '../utils/placeholder_page.dart'; // Import PlaceholderPage
// import '../services/user_service.dart'; // Import ini tidak digunakan, jadi dihapus

class PengaturanProfilPage extends StatefulWidget {
  const PengaturanProfilPage({super.key});

  @override
  State<PengaturanProfilPage> createState() => _PengaturanProfilPageState();
}

class _PengaturanProfilPageState extends State<PengaturanProfilPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController namaController = TextEditingController();
  final TextEditingController emailController = TextEditingController();
  final TextEditingController phoneController = TextEditingController();
  final TextEditingController addressController = TextEditingController();
  final TextEditingController currentPassController = TextEditingController();
  final TextEditingController newPassController = TextEditingController();
  final TextEditingController confirmPassController = TextEditingController();
  bool isLoading = false;
  bool isPasswordVisible = false;
  bool isNewPasswordVisible = false;
  bool isConfirmPasswordVisible = false;
  bool isEditingPassword = false;
  String idUser = "1"; // Ganti dengan ID user yang sebenarnya
  String? profileImageUrl;
  File? _selectedImage;
  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    fetchProfile();
  }

  @override
  void dispose() {
    namaController.dispose();
    emailController.dispose();
    phoneController.dispose();
    addressController.dispose();
    currentPassController.dispose();
    newPassController.dispose();
    confirmPassController.dispose();
    super.dispose();
  }

  Future<void> fetchProfile() async {
    setState(() => isLoading = true);
    try {
      // Simulasi fetch data, ganti dengan panggilan API sebenarnya
      // final result = await UserService.getUserProfile(idUser);
      await Future.delayed(const Duration(seconds: 1)); // Simulasi loading
      final result = {
        'success': true,
        'user': {
          'nama_lengkap': 'Administrator',
          'email': 'admin@diskominfo.go.id',
          'phone': '081234567890',
          'address': 'Jl. Jend. Sudirman No.1, Bengkalis',
          'profile_image': 'https://via.placeholder.com/150/0000FF/FFFFFF?text=AD', // Placeholder image
        }
      };

      if (result['success'] == true) { // Perbaikan: Pastikan kondisi adalah boolean
        final user = result['user'] as Map<String, dynamic>;
        namaController.text = user['nama_lengkap'] ?? '';
        emailController.text = user['email'] ?? '';
        phoneController.text = user['phone'] ?? '';
        addressController.text = user['address'] ?? '';
        profileImageUrl = user['profile_image'];
      } else {
        _showSnackBar(result['message'] as String, isError: true);
      }
    } catch (e) {
      _showSnackBar('Terjadi kesalahan saat memuat profil: $e', isError: true);
    }
    setState(() => isLoading = false);
  }

  Future<void> updateProfile() async {
    if (!_formKey.currentState!.validate()) return;
    if (isEditingPassword) {
      if (newPassController.text != confirmPassController.text) {
        _showSnackBar('Password baru dan konfirmasi password tidak cocok', isError: true);
        return;
      }
      if (newPassController.text.length < 6) {
        _showSnackBar('Password baru minimal 6 karakter', isError: true);
        return;
      }
    }

    final data = {
      "id_user": idUser,
      "nama_lengkap": namaController.text.trim(),
      "email": emailController.text.trim(),
      "phone": phoneController.text.trim(),
      "address": addressController.text.trim(),
      if (isEditingPassword) ...{
        "current_password": currentPassController.text,
        "new_password": newPassController.text,
      }
    };

    setState(() => isLoading = true);
    try {
      // Simulasi update data, ganti dengan panggilan API sebenarnya
      // final result = await UserService.updateUserProfile(data);
      await Future.delayed(const Duration(seconds: 1)); // Simulasi loading
      final result = {'success': true, 'message': 'Profil berhasil diperbarui!'};

      _showSnackBar(result['message'] as String, isError: !(result['success'] == true)); // Perbaikan: Pastikan kondisi adalah boolean
            
      if (result['success'] == true) { // Perbaikan: Pastikan kondisi adalah boolean
        currentPassController.clear();
        newPassController.clear();
        confirmPassController.clear();
        setState(() => isEditingPassword = false);
      }
    } catch (e) {
      _showSnackBar('Terjadi kesalahan saat menyimpan profil: $e', isError: true);
    }
    setState(() => isLoading = false);
  }

  void _showSnackBar(String message, {bool isError = false}) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red[600] : Colors.green[600],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  void _navigateToPage(String routeName, String pageName) {
    Navigator.pop(context); // Close drawer first
        
    // Navigate to the respective page
    switch (routeName) {
      case '/dashboard':
        Navigator.pushReplacementNamed(context, '/dashboard');
        break;
      case '/daftar-barang':
        Navigator.pushReplacementNamed(context, '/daftar-barang');
        break;
      case '/daftar-perolehan':
        Navigator.pushReplacementNamed(context, '/daftar-perolehan');
        break;
      case '/daftar-ruangan':
        Navigator.pushReplacementNamed(context, '/daftar-ruangan');
        break;
      case '/daftar-pengguna':
        Navigator.pushReplacementNamed(context, '/daftar-pengguna');
        break;
      case '/pengaturan-profil':
        // Jika sudah di halaman ini, cukup tutup drawer
        // Navigator.pushReplacementNamed(context, '/pengaturan-profil'); // Tidak perlu push lagi
        break;
      case '/peran-hak-akses':
        Navigator.pushReplacementNamed(context, '/peran-hak-akses');
        break;
      default:
        // If route doesn't exist, show a placeholder page
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => PlaceholderPage(title: pageName),
          ),
        );
    }
  }

  // Fungsi untuk handle logout dengan konfirmasi
  Future<void> _handleLogout() async {
    final bool? shouldLogout = await showDialog<bool>(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Konfirmasi Logout'),
          content: const Text('Apakah Anda yakin ingin keluar dari aplikasi?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Batal'),
            ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(true),
              style: TextButton.styleFrom(
                foregroundColor: Colors.red,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );

    if (shouldLogout == true) {
      try {
        SharedPreferences prefs = await SharedPreferences.getInstance();
        await prefs.clear();
        if (mounted) {
          Navigator.pushReplacementNamed(context, '/');
        }
      } catch (e) {
        _showSnackBar('Gagal logout. Silakan coba lagi.', isError: true);
      }
    }
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Container(
        color: Colors.grey[50],
        child: Column(
          children: [
            // Header
            Container(
              height: 120,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue[700]!, Colors.blue[500]!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'INVENTRIS',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Sistem Manajemen Inventaris',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
                        
            // Menu Items
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                children: [
                  _buildMenuSection('DASHBOARD'),
                  _buildMenuItem(
                    icon: Icons.dashboard_outlined,
                    title: 'Dashboard',
                    onTap: () => _navigateToPage('/dashboard', 'Dashboard'),
                  ),
                                    
                  const SizedBox(height: 16),
                  _buildMenuSection('MANAJEMEN'),
                  _buildMenuItem(
                    icon: Icons.inventory_2_outlined,
                    title: 'Data Barang',
                    onTap: () => _navigateToPage('/daftar-barang', 'Data Barang'),
                  ),
                  _buildMenuItem(
                    icon: Icons.build_outlined,
                    title: 'Daftar Perolehan',
                    onTap: () => _navigateToPage('/daftar-perolehan', 'Daftar Perolehan'),
                  ),
                  _buildMenuItem(
                    icon: Icons.meeting_room_outlined,
                    title: 'Data Ruangan',
                    onTap: () => _navigateToPage('/daftar-ruangan', 'Data Ruangan'),
                  ),
                  _buildMenuItem(
                    icon: Icons.people_outline,
                    title: 'Data Pengguna',
                    onTap: () => _navigateToPage('/daftar-pengguna', 'Data Pengguna'),
                  ),
                                    
                  const SizedBox(height: 16),
                  _buildMenuSection('PENGATURAN'),
                  _buildMenuItem(
                    icon: Icons.person_outline,
                    title: 'Pengaturan Profil',
                    isActive: true, // Set active for this page
                    onTap: () {
                      Navigator.pop(context); // Just close drawer since we're already on this page
                    },
                  ),
                  _buildMenuItem(
                    icon: Icons.admin_panel_settings_outlined,
                    title: 'Peran & Hak Akses',
                    onTap: () => _navigateToPage('/peran-hak-akses', 'Peran & Hak Akses'),
                  ),
                ],
              ),
            ),
                        
            // Logout Button
            Container(
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: _handleLogout,
                  icon: const Icon(Icons.logout, color: Colors.white),
                  label: const Text(
                    'Logout',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red[600],
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuSection(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: Colors.grey[600],
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool isActive = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: ListTile(
        leading: Icon(
          icon,
          color: isActive ? Colors.blue[600] : Colors.grey[600],
          size: 22,
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isActive ? Colors.blue[600] : Colors.grey[700],
            fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
            fontSize: 14,
          ),
        ),
        onTap: onTap,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        tileColor: isActive ? Colors.blue[50] : null,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      ),
    );
  }

  Widget _buildProfileHeader() {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [Colors.blue[600]!, Colors.blue[400]!],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.1),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Row(
        children: [
          Stack(
            children: [
              CircleAvatar(
                radius: 40,
                backgroundColor: Colors.white,
                backgroundImage: _selectedImage != null
                    ? FileImage(_selectedImage!)
                    : (profileImageUrl != null 
                            ? NetworkImage(profileImageUrl!) 
                            : null) as ImageProvider<Object>?, // Cast to ImageProvider<Object>?
                child: _selectedImage == null && profileImageUrl == null 
                    ? Icon(Icons.person, size: 40, color: Colors.blue[600])
                    : null,
              ),
              Positioned(
                bottom: 0,
                right: 0,
                child: Container(
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 4,
                        offset: const Offset(0, 2),
                      ),
                    ],
                  ),
                  child: IconButton(
                    icon: Icon(Icons.camera_alt, color: Colors.blue[600], size: 20),
                    onPressed: () {
                      _showImagePickerDialog();
                    },
                    padding: const EdgeInsets.all(8),
                    constraints: const BoxConstraints(),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 20),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  namaController.text.isNotEmpty ? namaController.text : 'Nama Pengguna',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 24,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  emailController.text.isNotEmpty ? emailController.text : 'email@example.com',
                  style: TextStyle(
                    color: Colors.white.withOpacity(0.9),
                    fontSize: 16,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField({
    required TextEditingController controller,
    required String label,
    required IconData icon,
    TextInputType? keyboardType,
    String? Function(String?)? validator,
    bool obscureText = false,
    bool? isPasswordVisible, // Ini adalah parameter, bukan state
    VoidCallback? toggleVisibility,
    int maxLines = 1,
  }) {
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        keyboardType: keyboardType,
        validator: validator,
        obscureText: obscureText && !(isPasswordVisible ?? false), // Perbaikan: Pastikan kondisi boolean
        maxLines: maxLines,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: Colors.blue[600]),
          suffixIcon: toggleVisibility != null
              ? IconButton(
                  icon: Icon(
                    (isPasswordVisible ?? false) ? Icons.visibility : Icons.visibility_off,
                    color: Colors.grey[600],
                  ),
                  onPressed: toggleVisibility,
                )
              : null,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey[300]!),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey[300]!),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.blue[600]!, width: 2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Colors.red, width: 2),
          ),
          filled: true,
          fillColor: Colors.grey[50],
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        ),
      ),
    );
  }

  Widget _buildSectionCard({required String title, required List<Widget> children}) {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
                color: Colors.grey[800],
              ),
            ),
            const SizedBox(height: 16),
            ...children,
          ],
        ),
      ),
    );
  }

  void _showImagePickerDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          title: Row(
            children: [
              Icon(Icons.camera_alt, color: Colors.blue[600]),
              const SizedBox(width: 8),
              const Text('Pilih Foto Profil'),
            ],
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              ListTile(
                leading: const Icon(Icons.camera_alt),
                title: const Text('Ambil Foto'),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.camera);
                },
              ),
              ListTile(
                leading: const Icon(Icons.photo_library),
                title: const Text('Pilih dari Galeri'),
                onTap: () {
                  Navigator.pop(context);
                  _pickImage(ImageSource.gallery);
                },
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: Text(
                'Batal',
                style: TextStyle(color: Colors.grey[600]),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> _pickImage(ImageSource source) async {
    try {
      final XFile? pickedFile = await _picker.pickImage(
        source: source,
        maxWidth: 512,
        maxHeight: 512,
        imageQuality: 80,
      );
            
      if (pickedFile != null) {
        setState(() {
          _selectedImage = File(pickedFile.path);
        });
        _showSnackBar('Foto berhasil dipilih');
                
        // Here you would typically upload the image to your server
        // await _uploadProfileImage(_selectedImage!);
      }
    } catch (e) {
      _showSnackBar('Gagal memilih foto: $e', isError: true);
    }
  }

  Future<void> _uploadProfileImage(File imageFile) async {
    // This is where you would implement the actual upload to your server
    // For now, we'll just simulate the upload
    setState(() => isLoading = true);
        
    try {
      // Simulate API call
      await Future.delayed(const Duration(seconds: 2));
            
      // In a real app, you would upload to your server and get back the URL
      // final uploadResult = await UserService.uploadProfileImage(idUser, imageFile);
            
      setState(() {
        profileImageUrl = imageFile.path; // In real app, this would be the server URL
      });
            
      _showSnackBar('Foto profil berhasil diperbarui');
    } catch (e) {
      _showSnackBar('Gagal mengupload foto: $e', isError: true);
    }
        
    setState(() => isLoading = false);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent, // Penting untuk background image
      appBar: AppBar(
        title: const Text('Pengaturan Profil'),
        backgroundColor: Colors.blue[600], // Tetap solid agar konsisten dengan app bar lain
        foregroundColor: Colors.white,
        elevation: 0,
        systemOverlayStyle: SystemUiOverlayStyle.light, // Sesuaikan dengan warna app bar
        leading: Builder(
          builder: (context) => IconButton(
            icon: const Icon(Icons.menu),
            onPressed: () => Scaffold.of(context).openDrawer(),
          ),
        ),
      ),
      drawer: _buildDrawer(),
      body: GradientBackgroundWrapper( // Tambahkan background wrapper di sini
        child: isLoading
            ? const Center(child: CircularProgressIndicator())
            : Form(
                key: _formKey,
                child: SingleChildScrollView(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      _buildProfileHeader(),
                      const SizedBox(height: 24),
                                            
                      _buildSectionCard(
                        title: 'Informasi Pribadi',
                        children: [
                          _buildTextField(
                            controller: namaController,
                            label: 'Nama Lengkap',
                            icon: Icons.person,
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'Nama lengkap tidak boleh kosong';
                              }
                              return null;
                            },
                          ),
                          _buildTextField(
                            controller: emailController,
                            label: 'Email',
                            icon: Icons.email,
                            keyboardType: TextInputType.emailAddress,
                            validator: (value) {
                              if (value == null || value.trim().isEmpty) {
                                return 'Email tidak boleh kosong';
                              }
                              if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
                                return 'Format email tidak valid';
                              }
                              return null;
                            },
                          ),
                          _buildTextField(
                            controller: phoneController,
                            label: 'Nomor Telepon',
                            icon: Icons.phone,
                            keyboardType: TextInputType.phone,
                            validator: (value) {
                              if (value != null && value.isNotEmpty) {
                                if (!RegExp(r'^[0-9+\-\s]+$').hasMatch(value)) {
                                  return 'Format nomor telepon tidak valid';
                                }
                              }
                              return null;
                            },
                          ),
                          _buildTextField(
                            controller: addressController,
                            label: 'Alamat',
                            icon: Icons.location_on,
                            maxLines: 3,
                          ),
                        ],
                      ),
                                            
                      const SizedBox(height: 16),
                                            
                      _buildSectionCard(
                        title: 'Keamanan',
                        children: [
                          Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text(
                                'Ubah Password',
                                style: TextStyle(
                                  fontSize: 16,
                                  fontWeight: FontWeight.w500,
                                  color: Colors.grey[700],
                                ),
                              ),
                              Switch(
                                value: isEditingPassword,
                                onChanged: (value) {
                                  setState(() {
                                    isEditingPassword = value;
                                    if (!value) {
                                      currentPassController.clear();
                                      newPassController.clear();
                                      confirmPassController.clear();
                                    }
                                  });
                                },
                                activeColor: Colors.blue[600],
                              ),
                            ],
                          ),
                                                        
                          if (isEditingPassword) ...[
                            const SizedBox(height: 16),
                            _buildTextField(
                              controller: currentPassController,
                              label: 'Password Saat Ini',
                              icon: Icons.lock_outline,
                              obscureText: true,
                              isPasswordVisible: isPasswordVisible,
                              toggleVisibility: () {
                                setState(() => isPasswordVisible = !isPasswordVisible);
                              },
                              validator: (value) {
                                if (isEditingPassword && (value == null || value.isEmpty)) {
                                  return 'Password saat ini tidak boleh kosong';
                                }
                                return null;
                              },
                            ),
                            _buildTextField(
                              controller: newPassController,
                              label: 'Password Baru',
                              icon: Icons.lock,
                              obscureText: true,
                              isPasswordVisible: isNewPasswordVisible,
                              toggleVisibility: () {
                                setState(() => isNewPasswordVisible = !isNewPasswordVisible);
                              },
                              validator: (value) {
                                if (isEditingPassword) {
                                  if (value == null || value.isEmpty) {
                                    return 'Password baru tidak boleh kosong';
                                  }
                                  if (value.length < 6) {
                                    return 'Password minimal 6 karakter';
                                  }
                                }
                                return null;
                              },
                            ),
                            _buildTextField(
                              controller: confirmPassController,
                              label: 'Konfirmasi Password Baru',
                              icon: Icons.lock_reset,
                              obscureText: true,
                              isPasswordVisible: isConfirmPasswordVisible,
                              toggleVisibility: () {
                                setState(() => isConfirmPasswordVisible = !isConfirmPasswordVisible);
                              },
                              validator: (value) {
                                if (isEditingPassword) {
                                  if (value == null || value.isEmpty) {
                                    return 'Konfirmasi password tidak boleh kosong';
                                  }
                                  if (value != newPassController.text) {
                                    return 'Password tidak cocok';
                                  }
                                }
                                return null;
                              },
                            ),
                          ],
                        ],
                      ),
                                            
                      const SizedBox(height: 32),
                                            
                      SizedBox(
                        width: double.infinity,
                        height: 56,
                        child: ElevatedButton(
                          onPressed: isLoading ? null : updateProfile,
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[600],
                            foregroundColor: Colors.white,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                            ),
                            elevation: 2,
                          ),
                          child: isLoading
                              ? const SizedBox(
                                  height: 20,
                                  width: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                                  ),
                                )
                              : const Text(
                                  'Simpan Perubahan',
                                  style: TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                        ),
                      ),
                      const SizedBox(height: 16),
                      TextButton(
                        onPressed: () {
                          Navigator.pop(context);
                        },
                        child: Text(
                          'Batal',
                          style: TextStyle(
                            color: Colors.grey[600],
                            fontSize: 16,
                          ),
                        ),
                      ),
                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),
      ),
    );
  }
}
