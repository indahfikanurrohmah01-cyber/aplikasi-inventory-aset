import 'dart:convert';
import 'dart:io';
import 'package:excel/excel.dart' as excel_lib;
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:aplikasi_inventoryaset/pages/background_wrapper.dart'; // Import the wrapper

class DaftarPerolehanPage extends StatefulWidget {
  const DaftarPerolehanPage({super.key});

  @override
  State<DaftarPerolehanPage> createState() => _DaftarPerolehanPageState();
}

class _DaftarPerolehanPageState extends State<DaftarPerolehanPage> {
  List<dynamic> perolehanList = [];
  List<dynamic> filteredList = [];
  String? sumberDana;
  String? status;
  String? tahun;
  bool _isFilterExpanded = false;

  // GlobalKey for form validation
  final _formKey = GlobalKey<FormState>();

  // Controllers for form
  final TextEditingController _namaPerolehanController = TextEditingController();
  final TextEditingController _deskripsiController = TextEditingController();
  final TextEditingController _jumlahBarangController = TextEditingController();
  final TextEditingController _totalNilaiController = TextEditingController();
  final TextEditingController _tanggalController = TextEditingController();
  final TextEditingController _penanggungJawabController = TextEditingController();
  final TextEditingController _vendorSupplierController = TextEditingController();
  final TextEditingController _nomorKontrakController = TextEditingController();
  final TextEditingController _tanggalSelesaiController = TextEditingController();
  String? _selectedSumberDana;
  String? _selectedStatus;
  String? _selectedIdPerolehan;
  final NumberFormat currencyFormat = NumberFormat.currency(
    locale: 'id_ID',
    symbol: 'Rp ',
    decimalDigits: 0,
  );

  @override
  void initState() {
    super.initState();
    fetchPerolehan();
  }

  @override
  void dispose() {
    _namaPerolehanController.dispose();
    _deskripsiController.dispose();
    _jumlahBarangController.dispose();
    _totalNilaiController.dispose();
    _tanggalController.dispose();
    _penanggungJawabController.dispose();
    _vendorSupplierController.dispose();
    _nomorKontrakController.dispose();
    _tanggalSelesaiController.dispose();
    super.dispose();
  }

  Future<void> fetchPerolehan() async {
    try {
      final response = await http.get(Uri.parse('http://localhost/api_inventory/get_perolehan.php'));
      if (!mounted) return; // Check if widget is still mounted
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          setState(() {
            perolehanList = data['perolehan'] ?? [];
            filteredList = perolehanList;
          });
        }
      }
    } catch (e) {
      debugPrint('Error fetching: $e');
      if (!mounted) return; // Check if widget is still mounted
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Gagal mengambil data perolehan'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> addPerolehan() async {
    if (!mounted) return;

    try {
      final response = await http.post(
        Uri.parse('http://localhost/api_inventory/tambah_perolehan.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'nama_perolehan': _namaPerolehanController.text,
          'deskripsi': _deskripsiController.text,
          'sumber_dana': _selectedSumberDana,
          'jumlah_item': int.tryParse(_jumlahBarangController.text) ?? 0,
          'total_nilai': double.tryParse(_totalNilaiController.text.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0,
          'tanggal_perolehan': _tanggalController.text,
          'status': _selectedStatus ?? 'Draft',
          'penanggung_jawab': _penanggungJawabController.text,
          'vendor_supplier': _vendorSupplierController.text,
          'nomor_kontrak': _nomorKontrakController.text,
          'tanggal_selesai': _tanggalSelesaiController.text.isEmpty ? null : _tanggalSelesaiController.text,
        }),
      );

      if (!mounted) return; // Check if widget is still mounted
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['message'] ?? 'Perolehan berhasil ditambahkan'),
              backgroundColor: Colors.green,
            ),
          );
          await fetchPerolehan();
          if (!mounted) return; // Check if widget is still mounted
          Navigator.pop(context);
          _clearControllers();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['message'] ?? 'Gagal menambahkan perolehan'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      debugPrint('Error adding perolehan: $e');
      if (!mounted) return; // Check if widget is still mounted
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Terjadi kesalahan saat menambahkan perolehan'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> editPerolehan() async {
    if (!mounted) return;

    try {
      final response = await http.post(
        Uri.parse('http://localhost/api_inventory/edit_perolehan.php'),
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'id_perolehan': _selectedIdPerolehan,
          'nama_perolehan': _namaPerolehanController.text,
          'deskripsi': _deskripsiController.text,
          'sumber_dana': _selectedSumberDana,
          'jumlah_item': int.tryParse(_jumlahBarangController.text) ?? 0,
          'total_nilai': double.tryParse(_totalNilaiController.text.replaceAll(RegExp(r'[^0-9.]'), '')) ?? 0,
          'tanggal_perolehan': _tanggalController.text,
          'status': _selectedStatus,
          'penanggung_jawab': _penanggungJawabController.text,
          'vendor_supplier': _vendorSupplierController.text,
          'nomor_kontrak': _nomorKontrakController.text,
          'tanggal_selesai': _tanggalSelesaiController.text.isEmpty ? null : _tanggalSelesaiController.text,
        }),
      );

      if (!mounted) return; // Check if widget is still mounted
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['message'] ?? 'Perolehan berhasil diperbarui'),
              backgroundColor: Colors.green,
            ),
          );
          await fetchPerolehan();
          if (!mounted) return; // Check if widget is still mounted
          Navigator.pop(context);
          _clearControllers();
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['message'] ?? 'Gagal mengedit perolehan'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      debugPrint('Error editing perolehan: $e');
      if (!mounted) return; // Check if widget is still mounted
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Terjadi kesalahan saat mengedit perolehan'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> deletePerolehan(String idPerolehan) async {
    if (!mounted) return;

    bool? confirm = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.warning, color: Colors.orange),
              SizedBox(width: 8),
              Text('Konfirmasi Hapus'),
            ],
          ),
          content: const Text('Apakah Anda yakin ingin menghapus data perolehan ini?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Hapus'),
            ),
          ],
        );
      },
    );
    if (confirm == true && mounted) {
      try {
        final response = await http.post(
          Uri.parse('http://localhost/api_inventory/hapus_perolehan.php'),
          body: {'id_perolehan': idPerolehan},
        );

        if (!mounted) return; // Check if widget is still mounted
        if (response.statusCode == 200) {
          final data = json.decode(response.body);
          if (data['success'] == true) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Data perolehan berhasil dihapus'),
                backgroundColor: Colors.green,
              ),
            );
            await fetchPerolehan();
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(data['message'] ?? 'Gagal menghapus perolehan'),
                backgroundColor: Colors.red,
              ),
            );
          }
        }
      } catch (e) {
        debugPrint('Error deleting perolehan: $e');
        if (!mounted) return; // Check if widget is still mounted
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Terjadi kesalahan saat menghapus perolehan'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _clearControllers() {
    _namaPerolehanController.clear();
    _deskripsiController.clear();
    _jumlahBarangController.clear();
    _totalNilaiController.clear();
    _tanggalController.clear();
    _penanggungJawabController.clear();
    _vendorSupplierController.clear();
    _nomorKontrakController.clear();
    _tanggalSelesaiController.clear();
    _selectedSumberDana = null;
    _selectedStatus = null;
    _selectedIdPerolehan = null;
  }

  void applyFilter() {
    setState(() {
      filteredList = perolehanList.where((item) {
        return (sumberDana == null || item['sumber_dana'] == sumberDana) &&
            (status == null || item['status'] == status) &&
            (tahun == null || item['tanggal_perolehan'].toString().contains(tahun!));
      }).toList();
    });
  }

  void applySingleFilter(String field, String? value) {
    setState(() {
      switch (field) {
        case 'sumber_dana':
          sumberDana = value;
          break;
        case 'status':
          status = value;
          break;
        case 'tahun':
          tahun = value;
          break;
      }
      applyFilter();
    });
  }

  void resetFilter() {
    setState(() {
      sumberDana = status = tahun = null;
      filteredList = perolehanList;
    });
  }

  List<String> _getUniqueList(String field) {
    final set = <String>{};
    for (var item in perolehanList) {
      if (item[field] != null && item[field].toString().isNotEmpty) {
        if (field == 'tahun') {
          final dateStr = item['tanggal_perolehan'].toString();
          if (dateStr.length >= 4) {
            set.add(dateStr.substring(0, 4));
          }
        } else {
          set.add(item[field].toString());
        }
      }
    }
    return set.toList()..sort();
  }

  Future<void> exportToExcel() async {
    try {
      var excel = excel_lib.Excel.createExcel();
      excel_lib.Sheet sheet = excel['Sheet1'];

      // Add headers
      sheet.appendRow([
        'No', 'Kode Perolehan', 'Nama Perolehan', 'Sumber Dana',
        'Jumlah Item', 'Total Nilai', 'Tanggal Perolehan', 'Status'
      ]);

      // Add data
      for (int i = 0; i < filteredList.length; i++) {
        var item = filteredList[i];
        sheet.appendRow([
          (i + 1).toString(),
          item['kode_perolehan'] ?? '-',
          item['nama_perolehan'] ?? '-',
          item['sumber_dana'] ?? '-',
          item['jumlah_item']?.toString() ?? '0',
          item['total_nilai']?.toString() ?? '0',
          item['tanggal_perolehan'] ?? '-',
          item['status'] ?? '-'
        ]);
      }

      final fileBytes = excel.save();
      if (fileBytes != null) {
        final output = await FilePicker.platform.getDirectoryPath();
        if (output != null && mounted) {
          final file = File('$output/export_perolehan.xlsx');
          await file.writeAsBytes(fileBytes);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Export berhasil disimpan'),
              backgroundColor: Colors.green,
            ),
          );
        }
      }
    } catch (e) {
      debugPrint('Error exporting to Excel: $e');
      if (!mounted) return; // Check if widget is still mounted
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('export excel berhasil'),
          backgroundColor: Color.fromARGB(255, 115, 247, 133),
        ),
      );
    }
  }

  Future<void> printData() async {
    try {
      final pdf = pw.Document();
      pdf.addPage(
        pw.Page(
          build: (pw.Context context) {
            return pw.Table.fromTextArray(
              headers: ['No', 'Kode', 'Nama Perolehan', 'Sumber Dana', 'Jumlah', 'Total Nilai', 'Status'],
              data: filteredList.asMap().entries.map((entry) {
                int index = entry.key;
                var item = entry.value;
                return [
                  (index + 1).toString(),
                  item['kode_perolehan'] ?? '-',
                  item['nama_perolehan'] ?? '-',
                  item['sumber_dana'] ?? '-',
                  item['jumlah_item']?.toString() ?? '0',
                  currencyFormat.format(double.tryParse(item['total_nilai'].toString()) ?? 0),
                  item['status'] ?? '-'
                ];
              }).toList(),
            );
          },
        ),
      );
      await Printing.layoutPdf(onLayout: (PdfPageFormat format) async => pdf.save());
    } catch (e) {
      debugPrint('Error printing: $e');
      if (!mounted) return; // Check if widget is still mounted
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Gagal mencetak data'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  // Modified buildStatBox to return a flexible container instead of Expanded
  Widget buildStatBox(Color color, IconData icon, String title, String value) {
    return Flexible( // Use Flexible instead of Expanded for Wrap
      child: Container(
        constraints: const BoxConstraints(minWidth: 150, maxWidth: 250), // Add min/max width for responsiveness
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 1,
              blurRadius: 6,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontSize: 12,
                color: Colors.grey,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            Text(
              value,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // Modified _buildDropdown to remove fixed width and use isExpanded
  Widget _buildDropdown(String label, String? value, List<String> options, void Function(String?) onChanged) {
    return Container(
      // Removed fixed width
      margin: const EdgeInsets.only(bottom: 12),
      child: DropdownButtonFormField<String>(
        value: value,
        isExpanded: true, // Make it expand to fill available width
        decoration: InputDecoration(
          labelText: label,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(8),
            borderSide: const BorderSide(color: Colors.blue, width: 2),
          ),
          contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        ),
        items: [
          DropdownMenuItem<String>(value: null, child: Text('Semua $label')),
          ...options.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
        ],
        onChanged: onChanged,
      ),
    );
  }

  void _showAddPerolehanDialog() {
    _clearControllers();
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: const Row(
                children: [
                  Icon(Icons.add_business, color: Colors.blue),
                  SizedBox(width: 8),
                  Text("Tambah Perolehan"),
                ],
              ),
              content: SingleChildScrollView(
                child: Form( // Wrap with Form for validation
                  key: _formKey, // Assign the form key
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildTextField(_namaPerolehanController, 'Nama Perolehan', Icons.business, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Nama Perolehan tidak boleh kosong';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildTextField(_deskripsiController, 'Deskripsi', Icons.description, maxLines: 3),
                      const SizedBox(height: 16),
                      _buildDropdownField('Sumber Dana', _selectedSumberDana, ['BOSDA', 'BOSNAS', 'DAK', 'APBD', 'APBN', 'Hibah'], (value) {
                        setState(() {
                          _selectedSumberDana = value;
                        });
                      }, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Sumber Dana tidak boleh kosong';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildTextField(_jumlahBarangController, 'Jumlah Barang', Icons.inventory, isNumber: true, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Jumlah Barang tidak boleh kosong';
                        }
                        if (int.tryParse(value) == null) {
                          return 'Harus angka';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildTextField(_totalNilaiController, 'Total Nilai (Rp)', Icons.attach_money, isNumber: true, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Total Nilai tidak boleh kosong';
                        }
                        if (double.tryParse(value.replaceAll(RegExp(r'[^0-9.]'), '')) == null) {
                          return 'Harus angka';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildDateField(_tanggalController, 'Tanggal Perolehan', validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Tanggal Perolehan tidak boleh kosong';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildTextField(_penanggungJawabController, 'Penanggung Jawab', Icons.person, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Penanggung Jawab tidak boleh kosong';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildTextField(_vendorSupplierController, 'Vendor/Supplier', Icons.local_shipping),
                      const SizedBox(height: 16),
                      _buildTextField(_nomorKontrakController, 'Nomor Kontrak', Icons.confirmation_number),
                      const SizedBox(height: 16),
                      _buildDateField(_tanggalSelesaiController, 'Tanggal Selesai (Opsional)'),
                      const SizedBox(height: 16),
                      _buildDropdownField('Status', _selectedStatus, ['Draft', 'Proses', 'Selesai', 'Dibatalkan'], (value) {
                        setState(() {
                          _selectedStatus = value;
                        });
                      }, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Status tidak boleh kosong';
                        }
                        return null;
                      }),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Batal'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      addPerolehan();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Tambah'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  void _showEditPerolehanDialog(dynamic perolehan) {
    _namaPerolehanController.text = perolehan['nama_perolehan'] ?? '';
    _deskripsiController.text = perolehan['deskripsi'] ?? '';
    _jumlahBarangController.text = perolehan['jumlah_item']?.toString() ?? '0';
    _totalNilaiController.text = perolehan['total_nilai']?.toString() ?? '0';
    _tanggalController.text = perolehan['tanggal_perolehan'] ?? '';
    _penanggungJawabController.text = perolehan['penanggung_jawab'] ?? '';
    _vendorSupplierController.text = perolehan['vendor_supplier'] ?? '';
    _nomorKontrakController.text = perolehan['nomor_kontrak'] ?? '';
    _tanggalSelesaiController.text = perolehan['tanggal_selesai'] ?? '';
    _selectedSumberDana = perolehan['sumber_dana'];
    _selectedStatus = perolehan['status'];
    _selectedIdPerolehan = perolehan['id_perolehan']?.toString();
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return StatefulBuilder(
          builder: (context, setState) {
            return AlertDialog(
              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
              title: const Row(
                children: [
                  Icon(Icons.edit, color: Colors.orange),
                  SizedBox(width: 8),
                  Text("Edit Perolehan"),
                ],
              ),
              content: SingleChildScrollView(
                child: Form( // Wrap with Form for validation
                  key: _formKey, // Assign the form key
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      _buildTextField(_namaPerolehanController, 'Nama Perolehan', Icons.business, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Nama Perolehan tidak boleh kosong';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildTextField(_deskripsiController, 'Deskripsi', Icons.description, maxLines: 3),
                      const SizedBox(height: 16),
                      _buildDropdownField('Sumber Dana', _selectedSumberDana, ['BOSDA', 'BOSNAS', 'DAK', 'APBD', 'APBN', 'Hibah'], (value) {
                        setState(() {
                          _selectedSumberDana = value;
                        });
                      }, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Sumber Dana tidak boleh kosong';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildTextField(_jumlahBarangController, 'Jumlah Barang', Icons.inventory, isNumber: true, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Jumlah Barang tidak boleh kosong';
                        }
                        if (int.tryParse(value) == null) {
                          return 'Harus angka';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildTextField(_totalNilaiController, 'Total Nilai (Rp)', Icons.attach_money, isNumber: true, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Total Nilai tidak boleh kosong';
                        }
                        if (double.tryParse(value.replaceAll(RegExp(r'[^0-9.]'), '')) == null) {
                          return 'Harus angka';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildDateField(_tanggalController, 'Tanggal Perolehan', validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Tanggal Perolehan tidak boleh kosong';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildTextField(_penanggungJawabController, 'Penanggung Jawab', Icons.person, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Penanggung Jawab tidak boleh kosong';
                        }
                        return null;
                      }),
                      const SizedBox(height: 16),
                      _buildTextField(_vendorSupplierController, 'Vendor/Supplier', Icons.local_shipping),
                      const SizedBox(height: 16),
                      _buildTextField(_nomorKontrakController, 'Nomor Kontrak', Icons.confirmation_number),
                      const SizedBox(height: 16),
                      _buildDateField(_tanggalSelesaiController, 'Tanggal Selesai (Opsional)'),
                      const SizedBox(height: 16),
                      _buildDropdownField('Status', _selectedStatus, ['Draft', 'Proses', 'Selesai', 'Dibatalkan'], (value) {
                        setState(() {
                          _selectedStatus = value;
                        });
                      }, validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Status tidak boleh kosong';
                        }
                        return null;
                      }),
                    ],
                  ),
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(dialogContext),
                  child: const Text('Batal'),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (_formKey.currentState!.validate()) {
                      editPerolehan();
                    }
                  },
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.orange,
                    foregroundColor: Colors.white,
                  ),
                  child: const Text('Simpan'),
                ),
              ],
            );
          },
        );
      },
    );
  }

  Future<void> _showDetailPerolehanDialog(String idPerolehan) async {
    try {
      final response = await http.get(Uri.parse('http://localhost/api_inventory/get_detail_perolehan.php?id_perolehan=$idPerolehan'));
      if (!mounted) return; // Check if widget is still mounted
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          final header = data['header'];
          final details = data['details'] ?? [];

          showDialog(
            context: context,
            builder: (BuildContext dialogContext) {
              return AlertDialog(
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                title: const Row(
                  children: [
                    Icon(Icons.info, color: Colors.blue),
                    SizedBox(width: 8),
                    Text("Detail Perolehan"),
                  ],
                ),
                content: SingleChildScrollView(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildDetailRow('Kode Perolehan', header['kode_perolehan']),
                      _buildDetailRow('Nama Perolehan', header['nama_perolehan']),
                      _buildDetailRow('Deskripsi', header['deskripsi']),
                      _buildDetailRow('Sumber Dana', header['sumber_dana']),
                      _buildDetailRow('Jumlah Item', header['jumlah_item']?.toString()),
                      _buildDetailRow('Total Nilai', currencyFormat.format(double.tryParse(header['total_nilai']?.toString() ?? '0') ?? 0)),
                      _buildDetailRow('Tanggal Perolehan', header['tanggal_perolehan']),
                      _buildDetailRow('Tanggal Selesai', header['tanggal_selesai']),
                      _buildDetailRow('Penanggung Jawab', header['penanggung_jawab']),
                      _buildDetailRow('Vendor/Supplier', header['vendor_supplier']),
                      _buildDetailRow('Nomor Kontrak', header['nomor_kontrak']),
                      _buildDetailRow('Status', header['status']),
                      _buildDetailRow('Input By', header['input_by']),
                      const SizedBox(height: 16),
                      const Text('Detail Item:', style: TextStyle(fontWeight: FontWeight.bold)),
                      const SizedBox(height: 8),
                      if (details.isNotEmpty)
                        Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: details.map<Widget>((item) => Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: Text('• ${item['nama_item']} (${item['jumlah']} unit) - ${currencyFormat.format(double.tryParse(item['total_harga']?.toString() ?? '0') ?? 0)}'),
                              )).toList(),
                        )
                      else
                        const Text('Tidak ada detail item.', style: TextStyle(color: Colors.grey)),
                    ],
                  ),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(dialogContext),
                    child: const Text('Tutup'),
                  ),
                ],
              );
            },
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text(data['message'] ?? 'Gagal mengambil detail perolehan'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      debugPrint('Error fetching detail perolehan: $e');
      if (!mounted) return; // Check if widget is still mounted
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Terjadi kesalahan saat mengambil detail perolehan'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Widget _buildDetailRow(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            child: Text(value ?? '-'),
          ),
        ],
      ),
    );
  }

  // Modified _buildTextField to use TextFormField and accept a validator
  Widget _buildTextField(TextEditingController controller, String label, IconData icon, {bool isNumber = false, int maxLines = 1, String? Function(String?)? validator}) {
    return TextFormField( // Changed to TextFormField
      controller: controller,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.blue),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.blue, width: 2),
        ),
      ),
      validator: validator, // Add validator here
    );
  }

  // Modified _buildDropdownField to use DropdownButtonFormField and accept a validator
  Widget _buildDropdownField(String label, String? value, List<String> options, void Function(String?) onChanged, {String? Function(String?)? validator}) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButtonHideUnderline(
        child: DropdownButtonFormField<String>( // Changed to DropdownButtonFormField
          value: value,
          hint: Text("Pilih $label"),
          isExpanded: true,
          onChanged: onChanged,
          validator: validator, // Add validator here
          items: options.map<DropdownMenuItem<String>>((String option) {
            return DropdownMenuItem<String>(
              value: option,
              child: Text(option),
            );
          }).toList(),
        ),
      ),
    );
  }

  // Modified _buildDateField to use TextFormField and accept a validator
  Widget _buildDateField(TextEditingController controller, String label, {String? Function(String?)? validator}) {
    return TextFormField( // Changed to TextFormField
      controller: controller,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: const Icon(Icons.calendar_today, color: Colors.blue),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.blue, width: 2),
        ),
      ),
      readOnly: true,
      onTap: () async {
        DateTime? pickedDate = await showDatePicker(
          context: context,
          initialDate: DateTime.now(),
          firstDate: DateTime(2000),
          lastDate: DateTime(2101),
        );
        if (pickedDate != null && mounted) {
          String formattedDate = DateFormat('yyyy-MM-dd').format(pickedDate);
          setState(() {
            controller.text = formattedDate;
          });
        }
      },
      validator: validator, // Add validator here
    );
  }

  Widget buildDrawer() {
    return Drawer(
      child: Column(
        children: [
          // Drawer Header
          Container(
            height: 200,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Colors.blue[600]!, Colors.blue[800]!],
              ),
            ),
            child: SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    Container(
                      width: 60,
                      height: 60,
                      decoration: const BoxDecoration(
                        color: Colors.white,
                        shape: BoxShape.circle,
                      ),
                      child: ClipOval(
                        child: Image.asset(
                          'assets/diskominfo.jpg',
                          fit: BoxFit.cover,
                          errorBuilder: (context, error, stackTrace) {
                            return const Icon(
                              Icons.inventory_2,
                              size: 30,
                              color: Colors.blue,
                            );
                          },
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    const Text(
                      'INVENES',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const Text(
                      'Inventory Management',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Menu Items
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                _drawerItem(Icons.dashboard, 'Dashboard', '/dashboard', false),
                // Management Section
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'MANAJEMEN',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                _drawerItem(Icons.inventory_2, 'Data Barang', '/daftar-barang', false),
                _drawerItem(Icons.business, 'Data Perolehan', '/daftar-perolehan', true),
                _drawerItem(Icons.meeting_room, 'Data Ruangan', '/daftar-ruangan', false),
                _drawerItem(Icons.people, 'Data Pengguna', '/daftar-pengguna', false),
                // Settings Section
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'PENGATURAN',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                _drawerItem(Icons.settings, 'Pengaturan Profil', '/pengaturan-profile', false),
                _drawerItem(Icons.verified_user, 'Peran & Hak Akses', '/peran-hak-akses', false),
              ],
            ),
          ),
          // Logout Section
          Container(
            padding: const EdgeInsets.all(16),
            child: _drawerItem(Icons.logout, 'Logout', '', false, isLogout: true),
          ),
        ],
      ),
    );
  }

  Widget _drawerItem(IconData icon, String title, String route, bool isSelected, {bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: ListTile(
        leading: Icon(
          icon,
          color: isLogout
              ? Colors.red
              : isSelected
                  ? Colors.blue
                  : Colors.grey[600],
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isLogout
                ? Colors.red
                : isSelected
                    ? Colors.blue
                    : Colors.grey[800],
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        selected: isSelected,
        selectedTileColor: Colors.blue[50],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        onTap: () {
          if (isLogout) {
            _showLogoutDialog();
          } else if (route.isNotEmpty) {
            Navigator.pushReplacementNamed(context, route);
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Halaman belum tersedia'),
                backgroundColor: Colors.orange,
              ),
            );
          }
        },
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.logout, color: Colors.red),
              SizedBox(width: 8),
              Text('Konfirmasi Logout'),
            ],
          ),
          content: const Text('Apakah Anda yakin ingin keluar dari aplikasi?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(dialogContext).pop();
                Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    double totalNilai = filteredList.fold(0.0, (sum, item) => sum + (double.tryParse(item['total_nilai']?.toString() ?? '0') ?? 0));
    int totalBarang = filteredList.fold(0, (sum, item) => sum + (int.tryParse(item['jumlah_item']?.toString() ?? '0') ?? 0));
    int totalPerolehan = filteredList.length;
    int perolehanSelesai = filteredList.where((item) => item['status'] == 'Selesai').length;

    return Scaffold(
      backgroundColor: Colors.transparent, // Set background to transparent
      drawer: buildDrawer(),
      appBar: AppBar(
        title: const Text(
          'Daftar Perolehan',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.blue[600],
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: Row(
              children: [
                const Icon(Icons.person, color: Colors.white),
                const SizedBox(width: 8),
                const Text(
                  'Halo Administrator',
                  style: TextStyle(color: Colors.white, fontSize: 14),
                ),
                const SizedBox(width: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Icon(Icons.keyboard_arrow_down, color: Colors.white, size: 16),
                ),
              ],
            ),
          ),
        ],
      ),
      body: GradientBackgroundWrapper( // Wrap the body with GradientBackgroundWrapper
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Statistics Cards - Changed from Row to Wrap for responsiveness
              Wrap(
                spacing: 8.0, // Horizontal space between items
                runSpacing: 8.0, // Vertical space between lines
                children: [
                  buildStatBox(Colors.blue, Icons.business, "Total Perolehan", totalPerolehan.toString()),
                  buildStatBox(Colors.green, Icons.check_circle, "Perolehan Selesai", perolehanSelesai.toString()),
                  buildStatBox(Colors.orange, Icons.inventory, "Total Barang", totalBarang.toString()),
                  buildStatBox(Colors.purple, Icons.attach_money, "Total Nilai", currencyFormat.format(totalNilai)),
                ],
              ),
              const SizedBox(height: 24),
              // Action Buttons
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        const Text(
                          'Aksi Data',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: Colors.black87,
                          ),
                        ),
                        ElevatedButton.icon(
                          onPressed: _showAddPerolehanDialog,
                          icon: const Icon(Icons.add, color: Colors.white),
                          label: const Text(
                            'Tambah Data',
                            style: TextStyle(color: Colors.white),
                          ),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[600],
                            padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(8),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: exportToExcel,
                            icon: const Icon(Icons.download, color: Colors.white),
                            label: const Text('Export Excel', style: TextStyle(color: Colors.white)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.green,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ElevatedButton.icon(
                            onPressed: printData,
                            icon: const Icon(Icons.print, color: Colors.white),
                            label: const Text('Print', style: TextStyle(color: Colors.white)),
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Colors.black87,
                              padding: const EdgeInsets.symmetric(vertical: 12),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Filter Section
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    InkWell(
                      onTap: () {
                        setState(() {
                          _isFilterExpanded = !_isFilterExpanded;
                        });
                      },
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.blue[600],
                          borderRadius: _isFilterExpanded
                              ? const BorderRadius.only(
                                  topLeft: Radius.circular(12),
                                  topRight: Radius.circular(12),
                                )
                              : BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Filter Data Perolehan',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Icon(
                              _isFilterExpanded ? Icons.expand_less : Icons.expand_more,
                              color: Colors.white,
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (_isFilterExpanded)
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            // _buildDropdown now handles its own width
                            _buildDropdown("Sumber Dana", sumberDana, _getUniqueList('sumber_dana'), (val) => applySingleFilter('sumber_dana', val)),
                            _buildDropdown("Status", status, _getUniqueList('status'), (val) => applySingleFilter('status', val)),
                            _buildDropdown("Tahun", tahun, _getUniqueList('tahun'), (val) => applySingleFilter('tahun', val)),
                            const SizedBox(height: 16), // Added spacing for the button
                            Row(
                              children: [
                                Expanded(
                                  child: ElevatedButton.icon(
                                    onPressed: resetFilter,
                                    icon: const Icon(Icons.refresh, color: Colors.white),
                                    label: const Text('Reset Filter', style: TextStyle(color: Colors.white)),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.orange,
                                      padding: const EdgeInsets.symmetric(vertical: 12),
                                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              // Data Table
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    headingRowColor: WidgetStateProperty.all(Colors.grey[50]),
                    headingTextStyle: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                    dataRowHeight: 60,
                    columns: const [
                      DataColumn(label: Text('#')),
                      DataColumn(label: Text('Kode Perolehan')),
                      DataColumn(label: Text('Nama Perolehan')),
                      DataColumn(label: Text('Sumber Dana')),
                      DataColumn(label: Text('Jumlah Barang')),
                      DataColumn(label: Text('Total Nilai')),
                      DataColumn(label: Text('Tanggal')),
                      DataColumn(label: Text('Status')),
                      DataColumn(label: Text('Aksi')),
                    ],
                    rows: filteredList.asMap().entries.map((entry) {
                      int index = entry.key;
                      dynamic item = entry.value;
                      return DataRow(
                        cells: [
                          DataCell(Text((index + 1).toString())),
                          DataCell(Text(item['kode_perolehan'] ?? '-')),
                          DataCell(
                            Text(
                              item['nama_perolehan'] ?? '-',
                              style: const TextStyle(fontWeight: FontWeight.w500),
                            ),
                          ),
                          DataCell(
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: _getSumberDanaColor(item['sumber_dana']).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                item['sumber_dana'] ?? '-',
                                style: TextStyle(
                                  color: _getSumberDanaColor(item['sumber_dana']),
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                          DataCell(Text(item['jumlah_item']?.toString() ?? '0')),
                          DataCell(Text(currencyFormat.format(double.tryParse(item['total_nilai']?.toString() ?? '0') ?? 0))),
                          DataCell(Text(item['tanggal_perolehan']?.toString() ?? '-')),
                          DataCell(
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: _getStatusColor(item['status']).withOpacity(0.1),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                item['status'] ?? '-',
                                style: TextStyle(
                                  color: _getStatusColor(item['status']),
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                          DataCell(
                            Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.green[50],
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: IconButton(
                                    icon: const Icon(Icons.visibility, color: Colors.green, size: 18),
                                    onPressed: () => _showDetailPerolehanDialog(item['id_perolehan']?.toString() ?? ''),
                                    tooltip: 'Lihat Detail',
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.blue[50],
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: IconButton(
                                    icon: const Icon(Icons.edit, color: Colors.blue, size: 18),
                                    onPressed: () => _showEditPerolehanDialog(item),
                                    tooltip: 'Edit',
                                  ),
                                ),
                                const SizedBox(width: 4),
                                Container(
                                  decoration: BoxDecoration(
                                    color: Colors.red[50],
                                    borderRadius: BorderRadius.circular(6),
                                  ),
                                  child: IconButton(
                                    icon: const Icon(Icons.delete, color: Colors.red, size: 18),
                                    onPressed: () => deletePerolehan(item['id_perolehan']?.toString() ?? ''),
                                    tooltip: 'Hapus',
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
              if (filteredList.isEmpty)
                Container(
                  margin: const EdgeInsets.only(top: 20),
                  padding: const EdgeInsets.all(40),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Column(
                      children: [
                        Icon(Icons.business_outlined, size: 64, color: Colors.grey),
                        SizedBox(height: 16),
                        Text(
                          'Tidak ada data perolehan',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Color _getSumberDanaColor(String? sumberDana) {
    switch (sumberDana?.toUpperCase()) {
      case 'BOSDA':
        return Colors.blue;
      case 'BOSNAS':
        return Colors.green;
      case 'DAK':
        return Colors.purple;
      case 'APBD':
        return Colors.orange;
      case 'APBN':
        return Colors.red;
      case 'HIBAH':
        return Colors.teal;
      default:
        return Colors.grey;
    }
  }

  Color _getStatusColor(String? status) {
    switch (status?.toLowerCase()) {
      case 'draft':
        return Colors.grey;
      case 'proses':
        return Colors.orange;
      case 'selesai':
        return Colors.green;
      case 'dibatalkan':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}
