import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/foundation.dart'; // Untuk debugPrint

class EditLaporanPage extends StatefulWidget {
  final Map<String, dynamic> laporan;

  const EditLaporanPage({super.key, required this.laporan});

  @override
  State<EditLaporanPage> createState() => _EditLaporanPageState();
}

class _EditLaporanPageState extends State<EditLaporanPage> {
  final _formKey = GlobalKey<FormState>();
  late TextEditingController namaBarangController;
  late TextEditingController deskripsiController;
  
  bool _isSubmitting = false;

  @override
  void initState() {
    super.initState();
    // Inisialisasi controller dengan data laporan yang akan diedit
    namaBarangController = TextEditingController(text: widget.laporan['nama_barang'] ?? '');
    deskripsiController = TextEditingController(text: widget.laporan['deskripsi'] ?? '');
  }

  @override
  void dispose() {
    namaBarangController.dispose();
    deskripsiController.dispose();
    super.dispose();
  }

  Future<void> updateLaporan() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? userId = prefs.getString('userId');
    
    if (userId == null) {
      userId = '4'; // Fallback untuk testing
      await prefs.setString('userId', userId);
    }
    
    debugPrint('Updating laporan with ID: ${widget.laporan['id']}');
    debugPrint('User ID: $userId');
    debugPrint('Nama Barang: ${namaBarangController.text}');
    debugPrint('Deskripsi: ${deskripsiController.text}');

    setState(() {
      _isSubmitting = true;
    });

    try {
      final url = Uri.parse('http://localhost/api_inventory/edit_laporan.php');
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'id': widget.laporan['id'].toString(),
          'id_user': userId,
          'nama_barang': namaBarangController.text,
          'deskripsi': deskripsiController.text,
        }),
      );

      debugPrint('Response status: ${response.statusCode}');
      debugPrint('Response body: ${response.body}');

      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });

        if (response.statusCode == 200) {
          try {
            final result = json.decode(response.body);
            if (result['status'] == 'success') {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text(result['message'] ?? 'Laporan berhasil diperbarui')),
              );
              // Kembali ke halaman sebelumnya dengan hasil success
              Navigator.pop(context, true);
            } else {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Gagal: ${result['message'] ?? 'Terjadi kesalahan'}')),
              );
            }
          } catch (e) {
            debugPrint('Error parsing JSON: $e');
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Error parsing response: $e')),
            );
          }
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('HTTP Error: ${response.statusCode}')),
          );
        }
      }
    } catch (e) {
      debugPrint('Error updating laporan: $e');
      if (mounted) {
        setState(() {
          _isSubmitting = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[100],
      appBar: AppBar(
        title: const Text('Edit Laporan', style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Card(
          elevation: 5,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Icon(Icons.edit, size: 64, color: Colors.blue[600]),
                  const SizedBox(height: 10),
                  Text(
                    'Edit Laporan',
                    style: TextStyle(
                      fontSize: 18, 
                      fontWeight: FontWeight.bold,
                      color: Colors.blue[700],
                    ),
                  ),
                  const SizedBox(height: 20),
                  
                  TextFormField(
                    controller: namaBarangController,
                    decoration: InputDecoration(
                      labelText: 'Nama Barang',
                      hintText: 'Contoh: Laptop, Proyektor',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      prefixIcon: const Icon(Icons.laptop_mac),
                    ),
                    validator: (value) =>
                        value == null || value.trim().isEmpty ? 'Nama barang wajib diisi' : null,
                  ),
                  const SizedBox(height: 16),
                  
                  TextFormField(
                    controller: deskripsiController,
                    decoration: InputDecoration(
                      labelText: 'Deskripsi Laporan',
                      hintText: 'Jelaskan detail masalah atau kondisi barang...',
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      prefixIcon: const Icon(Icons.description),
                      alignLabelWithHint: true,
                    ),
                    maxLines: 4,
                    validator: (value) =>
                        value == null || value.trim().isEmpty ? 'Deskripsi wajib diisi' : null,
                  ),
                  const SizedBox(height: 24),
                  
                  Row(
                    children: [
                      Expanded(
                        child: OutlinedButton.icon(
                          onPressed: () => Navigator.pop(context),
                          icon: const Icon(Icons.cancel),
                          label: const Text('Batal'),
                          style: OutlinedButton.styleFrom(
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _isSubmitting
                              ? null
                              : () {
                                  if (_formKey.currentState!.validate()) {
                                    updateLaporan();
                                  }
                                },
                          icon: _isSubmitting
                              ? const SizedBox(
                                  width: 20,
                                  height: 20,
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    color: Colors.white,
                                  ),
                                )
                              : const Icon(Icons.save),
                          label: Text(_isSubmitting ? 'Menyimpan...' : 'Simpan'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.blue[600],
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 14),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                            textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
