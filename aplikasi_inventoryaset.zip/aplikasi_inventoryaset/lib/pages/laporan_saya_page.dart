import 'package:aplikasi_inventoryaset/pages/pengaturan_profile_user.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter/foundation.dart'; 
import 'package:intl/intl.dart'; 
import 'tambah_laporan.dart'; 
import 'edit_laporan_page.dart';
import 'background_wrapper.dart'; 
import 'user_dashboard_page.dart';
import 'daftar_barang_user_page.dart';
import '../utils/placeholder_page.dart';
import 'status_permintaan_page.dart';
class LaporanSayaPage extends StatefulWidget {
  const LaporanSayaPage({super.key});

  @override
  State<LaporanSayaPage> createState() => _LaporanSayaPageState();
}

class _LaporanSayaPageState extends State<LaporanSayaPage> {
  List<Map<String, dynamic>> _laporanList = [];
  String? _userId;
  String _userName = 'User';
  bool _isLoading = true;
  String _errorMessage = '';

  @override
  void initState() {
    super.initState();
    _initLaporan();
  }

  @override
  void dispose() {
    super.dispose();
  }

  Future<void> _initLaporan() async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });
    SharedPreferences prefs = await SharedPreferences.getInstance();
    _userId = prefs.getString('userId');
    _userName = prefs.getString('user_name') ?? 'User';
    
    if (_userId == null) {
      _userId = '4';
      await prefs.setString('userId', _userId!);
      debugPrint('User ID set to hardcoded value for testing: $_userId');
    }
    debugPrint('User ID: $_userId');

    if (_userId != null) {
      await _fetchLaporan();
    } else {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'User ID tidak ditemukan. Harap login kembali.';
        });
      }
    }
  }

  Future<void> _fetchLaporan() async {
    if (_userId == null) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'User ID tidak tersedia untuk mengambil laporan.';
        });
      }
      return;
    }

    final url = Uri.parse(
      'http://localhost/api_inventory/get_laporan_user.php?id_user=$_userId',
    );
    
    debugPrint('Fetching laporan from: $url');
    
    try {
      final response = await http.get(url);
      debugPrint('Response status: ${response.statusCode}');
      debugPrint('Response body: ${response.body}');
      
      if (mounted) {
        if (response.statusCode == 200) {
          final Map<String, dynamic> data = json.decode(response.body);

          if (data['success'] == true && data.containsKey('laporan') && data['laporan'] is List) {
            setState(() {
              _laporanList = List<Map<String, dynamic>>.from(data['laporan']);
              _isLoading = false;
              _errorMessage = '';
            });
            debugPrint('Successfully loaded ${_laporanList.length} laporan');
          } else {
            setState(() {
              _isLoading = false;
              _errorMessage = data['message'] ?? 'Data laporan tidak valid atau API gagal.';
            });
            debugPrint('API Error: ${data['message']}');
          }
        } else {
          setState(() {
            _isLoading = false;
            _errorMessage = 'Gagal memuat laporan. Status: ${response.statusCode}';
          });
          debugPrint('Failed to load laporan. Status: ${response.statusCode}');
        }
      }
    } catch (e) {
      if (mounted) {
        setState(() {
          _isLoading = false;
          _errorMessage = 'Error fetching laporan: $e';
        });
      }
      debugPrint('Error fetching laporan: $e');
    }
  }

  // Fungsi untuk menghapus laporan
  Future<void> _deleteLaporan(Map<String, dynamic> laporan) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Konfirmasi Hapus'),
        content: Text('Apakah Anda yakin ingin menghapus laporan "${laporan['nama_barang']}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Batal'),
          ),
          TextButton(
            onPressed: () => Navigator.pop(context, true),
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            child: const Text('Hapus'),
          ),
        ],
      ),
    );

    if (confirm != true) return;

    try {
      final url = Uri.parse('http://localhost/api_inventory/hapus_laporan.php');
      final response = await http.post(
        url,
        headers: {'Content-Type': 'application/json'},
        body: json.encode({
          'id': laporan['id'].toString(),
          'id_user': _userId,
        }),
      );

      debugPrint('Delete response status: ${response.statusCode}');
      debugPrint('Delete response body: ${response.body}');

      if (response.statusCode == 200) {
        final result = json.decode(response.body);
        if (result['status'] == 'success') {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text(result['message'] ?? 'Laporan berhasil dihapus')),
            );
            // Refresh data setelah hapus
            await _fetchLaporan();
          }
        } else {
          if (mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Gagal menghapus: ${result['message']}')),
            );
          }
        }
      } else {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('HTTP Error: ${response.statusCode}')),
          );
        }
      }
    } catch (e) {
      debugPrint('Error deleting laporan: $e');
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
    }
  }

  // Fungsi untuk menampilkan menu aksi (edit/hapus)
  void _showActionMenu(Map<String, dynamic> laporan) {
    showModalBottomSheet(
      context: context,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (context) => Container(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.grey[300],
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            const SizedBox(height: 20),
            Text(
              laporan['nama_barang'] ?? 'Laporan',
              style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 20),
            ListTile(
              leading: const Icon(Icons.edit, color: Colors.blue),
              title: const Text('Edit Laporan'),
              onTap: () async {
                Navigator.pop(context); // Tutup bottom sheet
                // Navigasi ke halaman edit
                final result = await Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => EditLaporanPage(laporan: laporan),
                  ),
                );
                // Refresh data jika edit berhasil
                if (result == true) {
                  await _fetchLaporan();
                }
              },
            ),
            ListTile(
              leading: const Icon(Icons.delete, color: Colors.red),
              title: const Text('Hapus Laporan'),
              onTap: () {
                Navigator.pop(context); // Tutup bottom sheet
                _deleteLaporan(laporan); // Hapus laporan
              },
            ),
            const SizedBox(height: 10),
          ],
        ),
      ),
    );
  }

  Color _getStatusColor(String status) {
    switch (status.toLowerCase()) {
      case 'diterima':
        return Colors.green;
      case 'ditolak':
        return Colors.red;
      case 'diproses':
        return Colors.blue;
      case 'pending':
      default:
        return Colors.orange;
    }
  }

  IconData _getStatusIcon(String status) {
    switch (status.toLowerCase()) {
      case 'diterima':
        return Icons.check_circle;
      case 'ditolak':
        return Icons.cancel;
      case 'diproses':
        return Icons.hourglass_full;
      case 'pending':
      default:
        return Icons.pending;
    }
  }

  String _formatDate(String? dateString) {
    if (dateString == null) return 'N/A';
    try {
      final dateTime = DateTime.parse(dateString);
      return DateFormat('dd MMMM yyyy, HH:mm').format(dateTime);
    } catch (e) {
      debugPrint('Error parsing date: $e');
      return dateString;
    }
  }

  Future<void> _handleLogout() async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Konfirmasi Logout'),
        content: const Text('Apakah Anda yakin ingin keluar?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context, false), child: const Text('Batal')),
          TextButton(onPressed: () => Navigator.pop(context, true), style: TextButton.styleFrom(foregroundColor: Colors.red), child: const Text('Logout')),
        ],
      ),
    );
    if (confirm == true && mounted) {
      final prefs = await SharedPreferences.getInstance();
      await prefs.clear();
      Navigator.pushReplacementNamed(context, '/');
    }
  }

 void _navigate(String route, String title) {
  Navigator.pop(context); // close drawer

  if (route == '/laporan-saya') {
    return;
  }

  if (route == '/user-dashboard') {
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (_) => const UserDashboardPage()),
    );
  } else if (route == '/daftar-barang-user') {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const DaftarBarangUserPage()),
    );
  } else if (route == '/status-permintaan') {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => StatusPermintaanPage(userId: _userId!),
      ),
    );
    } else if (route == '/pengaturan-profile-user') {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const PengaturanProfilUserPage()),
    );
  } else {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => PlaceholderPage(title: title)),
    );
  }
}

  Drawer _buildDrawer() => Drawer(
        child: SafeArea(
          child: ListView(
            padding: EdgeInsets.zero,
            children: [
              _drawerHeader(),
              _drawerSection('DASHBOARD'),
              _drawerItem(Icons.dashboard_outlined, 'Dashboard', false, () => _navigate('/user-dashboard', 'Dashboard')),
              _drawerSection('MANAJEMEN BARANG'),
              _drawerItem(Icons.inventory_2_outlined, 'Barang Saya', false, () => _navigate('/daftar-barang-user', 'Barang Saya')),
              _drawerItem(Icons.history, 'Riwayat Permintaan', false, () => _navigate('/riwayat-permintaan', 'Riwayat Permintaan')),
              _drawerItem(Icons.assignment_turned_in, 'Status Permintaan', false, () => _navigate('/status-permintaan', 'Status Permintaan')),
              _drawerItem(Icons.receipt_long, 'Laporan Saya', true, () => _navigate('/laporan-saya', 'Laporan Saya')),
              _drawerSection('PENGATURAN'),
              _drawerItem(Icons.person_outline, 'Pengaturan Profil', false, () => _navigate('/pengaturan-profile-user', 'Pengaturan Profil')),
              const Divider(),
              ListTile(
                leading: const Icon(Icons.logout, color: Colors.red),
                title: const Text('Logout', style: TextStyle(color: Colors.red)),
                onTap: _handleLogout,
              ),
            ],
          ),
        ),
      );

  Widget _drawerHeader() => Container(
        height: 120,
        decoration: BoxDecoration(
          gradient: LinearGradient(colors: [Colors.blue[700]!, Colors.blue[500]!]),
        ),
        child: Center(
          child: ListTile(
            title: const Text('INVENTRIS', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20)),
            subtitle: const Text('Diskominfotik Bengkalis', style: TextStyle(color: Colors.white70)),
            trailing: GestureDetector(
              onTap: _handleLogout,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  Text('Halo, $_userName', style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600)),
                  const Text('Logout', style: TextStyle(color: Colors.white70, fontSize: 12)),
                ],
              ),
            ),
          ),
        ),
      );

  Widget _drawerSection(String title) => Padding(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
        child: Text(title, style: TextStyle(fontSize: 11, fontWeight: FontWeight.w600, color: Colors.grey[600])),
      );

  Widget _drawerItem(IconData icon, String title, bool active, VoidCallback onTap) => ListTile(
        leading: Icon(icon, color: active ? Colors.blue : Colors.grey[600]),
        title: Text(title, style: TextStyle(color: active ? Colors.blue : Colors.grey[800])),
        tileColor: active ? Colors.blue[50] : null,
        onTap: onTap,
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        title: const Text('Laporan Saya', style: TextStyle(fontWeight: FontWeight.bold, color: Colors.white)),
        backgroundColor: Colors.blue[600],
        elevation: 0,
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16.0),
            child: Row(
              children: [
                Text(
                  'Halo, $_userName',
                  style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w600),
                ),
                const SizedBox(width: 8),
                TextButton(
                  onPressed: _handleLogout,
                  style: TextButton.styleFrom(
                    foregroundColor: Colors.white,
                    padding: EdgeInsets.zero,
                    minimumSize: Size.zero,
                    tapTargetSize: MaterialTapTargetSize.shrinkWrap,
                  ),
                  child: const Text(
                    'Logout',
                    style: TextStyle(color: Colors.white70, fontSize: 12),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
      drawer: _buildDrawer(),
      body: GradientBackgroundWrapper(
        child: RefreshIndicator(
          onRefresh: _fetchLaporan,
          child: _isLoading
              ? const Center(child: CircularProgressIndicator())
              : _errorMessage.isNotEmpty
                  ? Center(
                      child: Padding(
                        padding: const EdgeInsets.all(16.0),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            const Icon(Icons.error_outline, color: Colors.red, size: 50),
                            const SizedBox(height: 10),
                            Text(_errorMessage, textAlign: TextAlign.center),
                            const SizedBox(height: 20),
                            ElevatedButton(
                              onPressed: _initLaporan,
                              child: const Text('Coba Lagi'),
                            ),
                          ],
                        ),
                      ),
                    )
                  : _laporanList.isEmpty
                      ? const Center(
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Icon(Icons.info_outline, size: 50, color: Colors.grey),
                              SizedBox(height: 10),
                              Text('Belum ada laporan yang diajukan.'),
                            ],
                          ),
                        )
                      : ListView.builder(
                          itemCount: _laporanList.length,
                          itemBuilder: (context, index) {
                            final laporan = _laporanList[index];
                            final status = laporan['status'] ?? 'pending';
                            final statusColor = _getStatusColor(status);
                            final statusIcon = _getStatusIcon(status);

                            return Card(
                              elevation: 3,
                              margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                              child: InkWell(
                                onTap: () => _showActionMenu(laporan), // Tap untuk menampilkan menu aksi
                                borderRadius: BorderRadius.circular(12),
                                child: Padding(
                                  padding: const EdgeInsets.all(16.0),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          Expanded(
                                            child: Text(
                                              laporan['nama_barang'] ?? 'Nama Barang Tidak Diketahui',
                                              style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
                                              overflow: TextOverflow.ellipsis,
                                            ),
                                          ),
                                          const SizedBox(width: 8),
                                          Row(
                                            children: [
                                              Container(
                                                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                                                decoration: BoxDecoration(
                                                  color: statusColor.withOpacity(0.1),
                                                  borderRadius: BorderRadius.circular(8),
                                                ),
                                                child: Row(
                                                  mainAxisSize: MainAxisSize.min,
                                                  children: [
                                                    Icon(statusIcon, size: 16, color: statusColor),
                                                    const SizedBox(width: 4),
                                                    Text(
                                                      status.toUpperCase(),
                                                      style: TextStyle(color: statusColor, fontWeight: FontWeight.bold, fontSize: 12),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              const SizedBox(width: 8),
                                              Icon(Icons.more_vert, color: Colors.grey[600], size: 20),
                                            ],
                                          ),
                                        ],
                                      ),
                                      const SizedBox(height: 8),
                                      Text(
                                        laporan['deskripsi'] ?? 'Tidak ada deskripsi.',
                                        style: TextStyle(color: Colors.grey[700], fontSize: 14),
                                        maxLines: 2,
                                        overflow: TextOverflow.ellipsis,
                                      ),
                                      const SizedBox(height: 8),
                                      Row(
                                        children: [
                                          const Icon(Icons.calendar_today, size: 16, color: Colors.grey),
                                          const SizedBox(width: 4),
                                          Text(
                                            _formatDate(laporan['tanggal_lapor']),
                                            style: TextStyle(color: Colors.grey[600], fontSize: 12),
                                          ),
                                          const Spacer(),
                                          Text(
                                            'Tap untuk opsi',
                                            style: TextStyle(color: Colors.grey[500], fontSize: 11, fontStyle: FontStyle.italic),
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          },
                        ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (_) => const TambahLaporanPage()),
          );
          
          if (result == true) {
            debugPrint('Laporan berhasil ditambahkan, refreshing data...');
            await _fetchLaporan();
          }
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
