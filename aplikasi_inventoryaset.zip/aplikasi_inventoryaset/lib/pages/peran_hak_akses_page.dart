import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class PeranHakAksesPage extends StatefulWidget {
  const PeranHakAksesPage({Key? key}) : super(key: key);

  @override
  State<PeranHakAksesPage> createState() => _PeranHakAksesPageState();
}

class _PeranHakAksesPageState extends State<PeranHakAksesPage> {
  List<dynamic> allRoles = [];
  List<dynamic> filteredRoles = [];
  int entriesToShow = 10;
  int currentPage = 1;
  String searchQuery = "";
  bool isLoading = false;
  String selectedCategory = "Semua";

  @override
  void initState() {
    super.initState();
    fetchRoles();
  }

  Future<void> fetchRoles() async {
    setState(() {
      isLoading = true;
    });
    try {
      final response = await http.get(
        Uri.parse('http://localhost/api_inventory/get_roles.php'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          allRoles = data;
          filteredRoles = data;
        });

        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Data berhasil dimuat: ${data.length} peran ditemukan'),
            backgroundColor: Colors.green,
            duration: Duration(seconds: 2),
          ),
        );
      } else {
        throw Exception('Gagal memuat data');
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: Gagal memuat data peran'),
          backgroundColor: Colors.red,
          duration: Duration(seconds: 3),
        ),
      );
    } finally {
      setState(() {
        isLoading = false;
      });
    }
  }

  void filterData(String query) {
    setState(() {
      searchQuery = query.toLowerCase();
      filteredRoles = allRoles.where((role) {
        final nama = role['nama']?.toString().toLowerCase() ?? '';
        final description = role['description']?.toString().toLowerCase() ?? '';
        return nama.contains(searchQuery) || description.contains(searchQuery);
      }).toList();
      currentPage = 1;
    });
  }

  void filterByCategory(String category) {
    setState(() {
      selectedCategory = category;
      if (category == "Semua") {
        filteredRoles = allRoles;
      } else {
        filteredRoles = allRoles.where((role) {
          final hakAkses = role['hak_akses'] is String
              ? List<String>.from(jsonDecode(role['hak_akses']))
              : List<String>.from(role['hak_akses']);

          switch (category) {
            case "Barang":
              return hakAkses.any((akses) => akses.contains('barang'));
            case "Perolehan":
              return hakAkses.any((akses) => akses.contains('perolehan'));
            case "Ruangan":
              return hakAkses.any((akses) => akses.contains('ruangan'));
            case "Pengguna":
              return hakAkses.any((akses) => akses.contains('pengguna'));
            default:
              return true;
          }
        }).toList();
      }
      currentPage = 1;
    });
  }

  List<dynamic> get paginatedRoles {
    final start = (currentPage - 1) * entriesToShow;
    final end = start + entriesToShow;
    return filteredRoles.sublist(
        start,
        end > filteredRoles.length ? filteredRoles.length : end);
  }

  int get totalPages => (filteredRoles.length / entriesToShow).ceil();

  void showRoleForm({Map<String, dynamic>? role}) {
    final isEdit = role != null;
    final TextEditingController namaController =
        TextEditingController(text: role?['nama'] ?? '');
    final TextEditingController descriptionController =
        TextEditingController(text: role?['description'] ?? '');

    List<String> selectedAkses = [];
    if (role != null && role['hak_akses'] is List) {
      selectedAkses = List<String>.from(role['hak_akses']);
    } else if (role != null && role['hak_akses'] is String) {
      selectedAkses = List<String>.from(jsonDecode(role['hak_akses']));
    }
    final Map<String, List<String>> kategorizedAkses = {
      "Manajemen Barang": [
        "tambah barang", "lihat barang", "detail barang", "ubah barang", "hapus barang"
      ],
      "Manajemen Perolehan": [
        "tambah perolehan", "lihat perolehan", "detail perolehan", "ubah perolehan", "hapus perolehan"
      ],
      "Manajemen Ruangan": [
        "tambah ruangan", "lihat ruangan", "detail ruangan", "ubah ruangan", "hapus ruangan"
      ],
      "Manajemen Pengguna": [
        "tambah pengguna", "lihat pengguna", "detail pengguna", "ubah pengguna", "hapus pengguna"
      ],
      "Import/Export": [
        "import barang", "export barang", "import ruangan", "export ruangan"
      ],
      "Cetak Laporan": [
        "print barang", "print individual barang"
      ],
      "Sistem": [
        "mengatur profile", "lihat peran dan hak akses",
        "tambah peran dan hak akses", "ubah peran dan hak akses", "hapus peran dan hak akses"
      ]
    };
    showDialog(
      context: context,
      builder: (context) {
        return StatefulBuilder(builder: (context, setModalState) {
          return AlertDialog(
            title: Row(
              children: [
                Icon(
                  isEdit ? Icons.edit : Icons.add,
                  color: Colors.blue.shade700,
                ),
                SizedBox(width: 8),
                Expanded(
                  child: Text(
                    isEdit ? 'Edit Peran' : 'Tambah Peran Baru',
                    style: TextStyle(color: Colors.blue.shade800),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ],
            ),
            content: Container(
              width: double.maxFinite,
              constraints: BoxConstraints(
                maxHeight: MediaQuery.of(context).size.height * 0.8,
              ),
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    // Form Input
                    Card(
                      elevation: 2,
                      child: Padding(
                        padding: EdgeInsets.all(16),
                        child: Column(
                          children: [
                            TextField(
                              controller: namaController,
                              decoration: InputDecoration(
                                labelText: 'Nama Peran *',
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.badge, color: Colors.blue.shade600),
                                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                            ),
                            SizedBox(height: 16),
                            TextField(
                              controller: descriptionController,
                              decoration: InputDecoration(
                                labelText: 'Deskripsi Peran',
                                border: OutlineInputBorder(),
                                prefixIcon: Icon(Icons.description, color: Colors.blue.shade600),
                                contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                              ),
                              maxLines: 2,
                            ),
                          ],
                        ),
                      ),
                    ),
                    SizedBox(height: 16),

                    // Hak Akses Section
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Text(
                            'Hak Akses *',
                            style: TextStyle(
                              fontWeight: FontWeight.bold,
                              fontSize: 16,
                              color: Colors.blue.shade800,
                            ),
                          ),
                        ),
                        Chip(
                          label: Text(
                            '${selectedAkses.length} dipilih',
                            style: TextStyle(fontSize: 11),
                          ),
                          backgroundColor: Colors.blue.shade100,
                        ),
                      ],
                    ),
                    SizedBox(height: 12),

                    // Kategorized Access Rights
                    ...kategorizedAkses.entries.map((entry) {
                      final kategori = entry.key;
                      final aksesInKategori = entry.value;
                      final selectedInCategory = aksesInKategori
                          .where((akses) => selectedAkses.contains(akses))
                          .length;

                      return Card(
                        margin: EdgeInsets.only(bottom: 8),
                        child: ExpansionTile(
                          title: Row(
                            children: [
                              Icon(
                                _getIconForCategory(kategori),
                                color: Colors.blue.shade600,
                                size: 20,
                              ),
                              SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  kategori,
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: Colors.blue.shade800,
                                    fontSize: 14,
                                  ),
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                              Chip(
                                label: Text(
                                  '$selectedInCategory/${aksesInKategori.length}',
                                  style: TextStyle(fontSize: 10),
                                ),
                                backgroundColor: selectedInCategory == aksesInKategori.length
                                    ? Colors.green.shade100
                                    : selectedInCategory > 0
                                        ? Colors.orange.shade100
                                        : Colors.grey.shade100,
                              ),
                            ],
                          ),
                          children: [
                            Padding(
                              padding: EdgeInsets.all(16),
                              child: Column(
                                children: [
                                  // Select All Button
                                  Align(
                                    alignment: Alignment.centerLeft,
                                    child: TextButton.icon(
                                      onPressed: () {
                                        setModalState(() {
                                          if (selectedInCategory == aksesInKategori.length) {
                                            // Deselect all
                                            selectedAkses.removeWhere(
                                                (akses) => aksesInKategori.contains(akses));
                                          } else {
                                            // Select all
                                            for (String akses in aksesInKategori) {
                                              if (!selectedAkses.contains(akses)) {
                                                selectedAkses.add(akses);
                                              }
                                            }
                                          }
                                        });
                                      },
                                      icon: Icon(
                                        selectedInCategory == aksesInKategori.length
                                            ? Icons.deselect
                                            : Icons.select_all,
                                        size: 16,
                                      ),
                                      label: Text(
                                        selectedInCategory == aksesInKategori.length
                                            ? 'Batalkan Semua'
                                            : 'Pilih Semua',
                                        style: TextStyle(fontSize: 12),
                                      ),
                                    ),
                                  ),
                                  // Access Rights Checkboxes
                                  Wrap(
                                    spacing: 6,
                                    runSpacing: 4,
                                    children: aksesInKategori.map((akses) {
                                      final isSelected = selectedAkses.contains(akses);
                                      return FilterChip(
                                        label: Text(
                                          akses,
                                          style: TextStyle(fontSize: 10),
                                        ),
                                        selected: isSelected,
                                        onSelected: (selected) {
                                          setModalState(() {
                                            if (selected) {
                                              selectedAkses.add(akses);
                                            } else {
                                              selectedAkses.remove(akses);
                                            }
                                          });
                                        },
                                        selectedColor: Colors.blue.shade100,
                                        checkmarkColor: Colors.blue.shade700,
                                      );
                                    }).toList(),
                                  ),
                                ],
                              ),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(context),
                child: Text('Batal'),
              ),
              ElevatedButton(
                onPressed: () async {
                  // Validasi
                  if (namaController.text.trim().isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Nama peran harus diisi'),
                        backgroundColor: Colors.red,
                      ),
                    );
                    return;
                  }
                  if (selectedAkses.isEmpty) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Minimal pilih satu hak akses'),
                        backgroundColor: Colors.red,
                      ),
                    );
                    return;
                  }
                  final body = {
                    if (isEdit) "id": role!['id'].toString(),
                    "nama": namaController.text.trim(),
                    "description": descriptionController.text.trim(),
                    "hak_akses": selectedAkses,
                  };
                  final url = isEdit
                      ? 'http://localhost/api_inventory/update_role.php'
                      : 'http://localhost/api_inventory/add_role.php';
                  try {
                    final response = await http.post(
                      Uri.parse(url),
                      headers: {"Content-Type": "application/json"},
                      body: jsonEncode(body),
                    );
                    if (response.statusCode == 200) {
                      final result = jsonDecode(response.body);
                      if (result['success'] == true) {
                        Navigator.pop(context);
                        fetchRoles();
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text(isEdit ? 'Peran berhasil diperbarui!' : 'Peran berhasil ditambahkan!'),
                            backgroundColor: Colors.green,
                          ),
                        );
                      } else {
                        ScaffoldMessenger.of(context).showSnackBar(
                          SnackBar(
                            content: Text('Gagal menyimpan data: ${result['message'] ?? 'Unknown error'}'),
                            backgroundColor: Colors.red,
                          ),
                        );
                      }
                    }
                  } catch (e) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Error: $e'),
                        backgroundColor: Colors.red,
                      ),
                    );
                  }
                },
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.blue.shade700,
                  foregroundColor: Colors.white,
                ),
                child: Text(
                  isEdit ? 'Simpan' : 'Tambah',
                  style: TextStyle(fontSize: 12),
                ),
              ),
            ],
          );
        });
      },
    );
  }

  IconData _getIconForCategory(String category) {
    switch (category) {
      case "Manajemen Barang":
        return Icons.inventory_2;
      case "Manajemen Perolehan":
        return Icons.shopping_cart;
      case "Manajemen Ruangan":
        return Icons.meeting_room;
      case "Manajemen Pengguna":
        return Icons.people;
      case "Import/Export":
        return Icons.import_export;
      case "Cetak Laporan":
        return Icons.print;
      case "Sistem":
        return Icons.settings;
      default:
        return Icons.security;
    }
  }

  void deleteRole(String id, String nama) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: Row(
          children: [
            Icon(Icons.warning, color: Colors.red),
            SizedBox(width: 8),
            Expanded(
              child: Text(
                'Konfirmasi Hapus',
                overflow: TextOverflow.ellipsis,
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: RichText(
            text: TextSpan(
              style: TextStyle(color: Colors.black87),
              children: [
                TextSpan(text: 'Yakin ingin menghapus peran '),
                TextSpan(
                  text: '"$nama"',
                  style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red),
                ),
                TextSpan(text: '? Tindakan ini tidak dapat dibatalkan.'),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text('Batal'),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            onPressed: () => Navigator.pop(context, true),
            child: Text('Hapus'),
          ),
        ],
      ),
    );
    if (confirm == true) {
      try {
        final response = await http.post(
          Uri.parse('http://localhost/api_inventory/delete_role.php'),
          headers: {"Content-Type": "application/json"},
          body: jsonEncode({"id": id}),
        );
        if (response.statusCode == 200) {
          final result = jsonDecode(response.body);
          if (result['success'] == true) {
            fetchRoles();
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Peran "$nama" berhasil dihapus'),
                backgroundColor: Colors.green,
              ),
            );
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text('Gagal menghapus peran: ${result['message'] ?? 'Unknown error'}'),
                backgroundColor: Colors.red,
              ),
            );
          }
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error: $e'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  void _navigateToPage(String route) {
    Navigator.pop(context); // Close the drawer
    Navigator.pushNamed(context, route);
  }

  Widget _buildMenuSection(String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16),
      child: Text(
        title,
        style: TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 14,
          color: Colors.grey.shade600,
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool isActive = false,
    Color? iconColor,
    Color? textColor,
  }) {
    return Container(
      margin: EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: isActive ? Colors.blue.shade100 : null,
      ),
      child: ListTile(
        leading: Icon(
          icon,
          color: iconColor ?? (isActive ? Colors.blue.shade700 : Colors.grey.shade700),
        ),
        title: Text(
          title,
          style: TextStyle(
            color: textColor ?? (isActive ? Colors.blue.shade800 : Colors.black87),
            fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
          ),
          overflow: TextOverflow.ellipsis,
        ),
        onTap: onTap,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final isSmallScreen = screenWidth < 600;

    // Determine the current route to set active state for menu items
    final currentRoute = ModalRoute.of(context)?.settings.name;

    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            Icon(Icons.admin_panel_settings, color: Colors.white),
            SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Peran dan Hak Akses",
                    style: TextStyle(
                        fontSize: isSmallScreen ? 16 : 18,
                        fontWeight: FontWeight.bold),
                    overflow: TextOverflow.ellipsis,
                  ),
                  if (!isSmallScreen)
                    Text(
                      "Kelola peran dan hak akses pengguna",
                      style: TextStyle(fontSize: 12, color: Colors.blue.shade100),
                      overflow: TextOverflow.ellipsis,
                    ),
                ],
              ),
            ),
          ],
        ),
        backgroundColor: Colors.blue.shade700,
        foregroundColor: Colors.white,
        elevation: 4,
        actions: [
          IconButton(
            onPressed: fetchRoles,
            icon: Icon(
              isLoading ? Icons.hourglass_empty : Icons.refresh,
              color: Colors.white,
            ),
            tooltip: 'Refresh Data',
          ),
        ],
      ),
      drawer: Drawer(
        child: Column( // Use Column to place the logout button at the bottom
          children: [
            Container(
              height: 180, // Adjusted height to match the image
              decoration: BoxDecoration(
                color: Colors.blue.shade700,
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(16),
                  bottomRight: Radius.circular(16),
                ),
              ),
              child: Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'INVENTRIS',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 28, // Larger font size for INVENTRIS
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      Text(
                        'Sistem Manajemen Inventaris',
                        style: TextStyle(
                          color: Colors.blue.shade100,
                          fontSize: 14,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            Expanded( // Use Expanded to make the ListView take available space
              child: ListView(
                padding: EdgeInsets.zero,
                children: [
                  _buildMenuSection('DASHBOARD'),
                  _buildMenuItem(
                    icon: Icons.dashboard,
                    title: 'Dashboard',
                    onTap: () => _navigateToPage('/dashboard'),
                    isActive: currentRoute == '/dashboard',
                  ),
                  _buildMenuSection('MANAJEMEN'),
                  _buildMenuItem(
                    icon: Icons.inventory_2_outlined,
                    title: 'Data Barang',
                    onTap: () => _navigateToPage('/daftar-barang'),
                    isActive: currentRoute == '/daftar-barang',
                  ),
                  _buildMenuItem(
                    icon: Icons.build_outlined,
                    title: 'Daftar Perolehan',
                    onTap: () => _navigateToPage('/daftar-perolehan'),
                    isActive: currentRoute == '/daftar-perolehan',
                  ),
                  _buildMenuItem(
                    icon: Icons.meeting_room_outlined,
                    title: 'Data Ruangan',
                    onTap: () => _navigateToPage('/daftar-ruangan'),
                    isActive: currentRoute == '/daftar-ruangan',
                  ),
                  _buildMenuItem(
                    icon: Icons.people_outline,
                    title: 'Data Pengguna',
                    onTap: () => _navigateToPage('/daftar-pengguna'),
                    isActive: currentRoute == '/daftar-pengguna',
                  ),
                  _buildMenuSection('PENGATURAN'),
                  _buildMenuItem(
                    icon: Icons.person_outline,
                    title: 'Pengaturan Profil',
                    onTap: () => _navigateToPage('/pengaturan-profile'),
                    isActive: currentRoute == '/pengaturan-profile', // Set active based on image
                  ),
                  _buildMenuItem(
                    icon: Icons.admin_panel_settings_outlined,
                    title: 'Peran & Hak Akses',
                    onTap: () => _navigateToPage('/peran-hak-akses'),
                    isActive: currentRoute == '/peran-hak-akses',
                  ),
                ],
              ),
            ),
            // Logout Button at the bottom
            Padding(
              padding: const EdgeInsets.all(16.0),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () {
                    Navigator.pop(context); // Close drawer
                    Navigator.pushReplacementNamed(context, '/'); // Navigate to login page
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text('Logout berhasil!'),
                        backgroundColor: Colors.green,
                      ),
                    );
                  },
                  icon: Icon(Icons.logout, color: Colors.white),
                  label: Text(
                    'Logout',
                    style: TextStyle(color: Colors.white),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red.shade600, // Red color for logout button
                    padding: EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          image: DecorationImage(
            image: NetworkImage('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-hFjlrmM9BQJY3YRPZvYuOl7SOTOJdS.png'), // URL gambar gedung Diskominfo
            fit: BoxFit.cover,
            colorFilter: ColorFilter.mode(
              Colors.black.withOpacity(0.3), // Opacity for better readability
              BlendMode.darken,
            ),
          ),
        ),
        child: SingleChildScrollView(
          padding: EdgeInsets.all(isSmallScreen ? 8 : 16),
          child: Column(
            children: [
              // Statistics Cards - Responsive
              isSmallScreen
                  ? Column(
                      children: [
                        _buildStatCard(
                          icon: Icons.security,
                          count: '${allRoles.length}',
                          label: 'Total Peran',
                          color: Colors.blue.shade600,
                        ),
                        SizedBox(height: 8),
                        _buildStatCard(
                          icon: Icons.visibility,
                          count: '${filteredRoles.length}',
                          label: 'Ditampilkan',
                          color: Colors.green.shade600,
                        ),
                      ],
                    )
                  : Row(
                      children: [
                        Expanded(
                          child: _buildStatCard(
                            icon: Icons.security,
                            count: '${allRoles.length}',
                            label: 'Total Peran',
                            color: Colors.blue.shade600,
                          ),
                        ),
                        SizedBox(width: 8),
                        Expanded(
                          child: _buildStatCard(
                            icon: Icons.visibility,
                            count: '${filteredRoles.length}',
                            label: 'Ditampilkan',
                            color: Colors.green.shade600,
                          ),
                        ),
                      ],
                    ),
              SizedBox(height: 16),
              // Controls - Responsive
              Card(
                elevation: 4,
                child: Padding(
                  padding: EdgeInsets.all(16),
                  child: Column(
                    children: [
                      // First Row - Entries and Add Button
                      isSmallScreen
                          ? Column(
                              crossAxisAlignment: CrossAxisAlignment.stretch,
                              children: [
                                Row(
                                  children: [
                                    Text("Tampilkan "),
                                    DropdownButton<int>(
                                      value: entriesToShow,
                                      items: [5, 10, 20, 50].map((e) =>
                                              DropdownMenuItem(value: e, child: Text("$e")))
                                          .toList(),
                                      onChanged: (val) {
                                        setState(() {
                                          entriesToShow = val!;
                                          currentPage = 1;
                                        });
                                      },
                                    ),
                                    Text(" entri"),
                                  ],
                                ),
                                SizedBox(height: 12),
                                SizedBox(
                                  width: double.infinity,
                                  child: ElevatedButton.icon(
                                    onPressed: () => showRoleForm(),
                                    icon: Icon(Icons.add),
                                    label: Text("Tambah Peran"),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue.shade700,
                                      foregroundColor: Colors.white,
                                    ),
                                  ),
                                ),
                              ],
                            )
                          : Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Row(
                                  children: [
                                    Text("Tampilkan "),
                                    DropdownButton<int>(
                                      value: entriesToShow,
                                      items: [5, 10, 20, 50].map((e) =>
                                              DropdownMenuItem(value: e, child: Text("$e")))
                                          .toList(),
                                      onChanged: (val) {
                                        setState(() {
                                          entriesToShow = val!;
                                          currentPage = 1;
                                        });
                                      },
                                    ),
                                    Text(" entri"),
                                  ],
                                ),
                                ElevatedButton.icon(
                                  onPressed: () => showRoleForm(),
                                  icon: Icon(Icons.add),
                                  label: Text("Tambah Peran"),
                                  style: ElevatedButton.styleFrom(
                                    backgroundColor: Colors.blue.shade700,
                                    foregroundColor: Colors.white,
                                  ),
                                ),
                              ],
                            ),
                      SizedBox(height: 16),

                      // Second Row - Search and Filter
                      isSmallScreen
                          ? Column(
                              children: [
                                TextField(
                                  decoration: InputDecoration(
                                    prefixIcon: Icon(Icons.search),
                                    hintText: "Cari nama peran...",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                  ),
                                  onChanged: filterData,
                                ),
                                SizedBox(height: 12),
                                DropdownButtonFormField<String>(
                                  value: selectedCategory,
                                  decoration: InputDecoration(
                                    labelText: "Filter Kategori",
                                    border: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(8),
                                    ),
                                    prefixIcon: Icon(Icons.filter_list),
                                    contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                  ),
                                  items: ["Semua", "Barang", "Perolehan", "Ruangan", "Pengguna"]
                                      .map((category) => DropdownMenuItem(
                                            value: category,
                                            child: Text(category),
                                          ))
                                      .toList(),
                                  onChanged: (value) {
                                    if (value != null) {
                                      filterByCategory(value);
                                    }
                                  },
                                ),
                              ],
                            )
                          : Row(
                              children: [
                                Expanded(
                                  flex: 2,
                                  child: TextField(
                                    decoration: InputDecoration(
                                      prefixIcon: Icon(Icons.search),
                                      hintText: "Cari nama peran atau deskripsi...",
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    ),
                                    onChanged: filterData,
                                  ),
                                ),
                                SizedBox(width: 16),
                                Expanded(
                                  child: DropdownButtonFormField<String>(
                                    value: selectedCategory,
                                    decoration: InputDecoration(
                                      labelText: "Filter Kategori",
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(8),
                                      ),
                                      prefixIcon: Icon(Icons.filter_list),
                                      contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                    ),
                                    items: ["Semua", "Barang", "Perolehan", "Ruangan", "Pengguna"]
                                        .map((category) => DropdownMenuItem(
                                              value: category,
                                              child: Text(category),
                                            ))
                                        .toList(),
                                    onChanged: (value) {
                                      if (value != null) {
                                        filterByCategory(value);
                                      }
                                    },
                                  ),
                                ),
                              ],
                            ),
                    ],
                  ),
                ),
              ),
              SizedBox(height: 16),
              // Content
              Container(
                constraints: BoxConstraints(
                  minHeight: 300,
                  maxHeight: MediaQuery.of(context).size.height * 0.6,
                ),
                child: isLoading
                    ? Center(
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            CircularProgressIndicator(
                              valueColor: AlwaysStoppedAnimation<Color>(Colors.blue.shade700),
                            ),
                            SizedBox(height: 16),
                            Text(
                              'Memuat data peran...',
                              style: TextStyle(color: Colors.grey.shade600),
                            ),
                          ],
                        ),
                      )
                    : filteredRoles.isEmpty
                        ? Center(
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Icon(
                                  Icons.search_off,
                                  size: 64,
                                  color: Colors.grey.shade400,
                                ),
                                SizedBox(height: 16),
                                Text(
                                  'Tidak ada peran ditemukan',
                                  style: TextStyle(
                                    fontSize: 18,
                                    fontWeight: FontWeight.bold,
                                    color: Colors.grey.shade600,
                                  ),
                                  textAlign: TextAlign.center,
                                ),
                                SizedBox(height: 8),
                                Text(
                                  searchQuery.isNotEmpty
                                      ? 'Coba ubah kata kunci pencarian'
                                      : 'Belum ada peran yang dibuat',
                                  style: TextStyle(color: Colors.grey.shade500),
                                  textAlign: TextAlign.center,
                                ),
                                if (searchQuery.isEmpty) ...[
                                  SizedBox(height: 16),
                                  ElevatedButton.icon(
                                    onPressed: () => showRoleForm(),
                                    icon: Icon(Icons.add),
                                    label: Text("Tambah Peran Pertama"),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.blue.shade700,
                                      foregroundColor: Colors.white,
                                    ),
                                  ),
                                ],
                              ],
                            ),
                          )
                        : ListView.builder(
                            shrinkWrap: true,
                            itemCount: paginatedRoles.length,
                            itemBuilder: (context, index) {
                              final role = paginatedRoles[index];
                              final akses = role['hak_akses'] is String
                                  ? List<String>.from(jsonDecode(role['hak_akses']))
                                  : List<String>.from(role['hak_akses']);
                              return Card(
                                elevation: 4,
                                margin: EdgeInsets.symmetric(vertical: 8),
                                shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(12),
                                ),
                                child: Padding(
                                  padding: EdgeInsets.all(16),
                                  child: Column(
                                    crossAxisAlignment: CrossAxisAlignment.start,
                                    children: [
                                      // Header Row
                                      Row(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Expanded(
                                            child: Column(
                                              crossAxisAlignment: CrossAxisAlignment.start,
                                              children: [
                                                Text(
                                                  role['nama'] ?? '-',
                                                  style: TextStyle(
                                                    fontSize: isSmallScreen ? 16 : 18,
                                                    fontWeight: FontWeight.bold,
                                                    color: Colors.blue.shade800,
                                                  ),
                                                  overflow: TextOverflow.ellipsis,
                                                  maxLines: 2,
                                                ),
                                                if (role['description'] != null &&
                                                    role['description'].toString().isNotEmpty)
                                                  Padding(
                                                    padding: EdgeInsets.only(top: 4),
                                                    child: Text(
                                                      role['description'],
                                                      style: TextStyle(
                                                        color: Colors.grey.shade600,
                                                        fontSize: 14,
                                                      ),
                                                      overflow: TextOverflow.ellipsis,
                                                      maxLines: 2,
                                                    ),
                                                  ),
                                              ],
                                            ),
                                          ),
                                          SizedBox(width: 8),
                                          Chip(
                                            label: Text(
                                              '${akses.length} akses',
                                              style: TextStyle(fontSize: 11),
                                            ),
                                            backgroundColor: Colors.blue.shade100,
                                          ),
                                        ],
                                      ),
                                      SizedBox(height: 12),

                                      // Access Rights
                                      Text(
                                        'Hak Akses:',
                                        style: TextStyle(
                                          fontWeight: FontWeight.w600,
                                          color: Colors.grey.shade700,
                                        ),
                                      ),
                                      SizedBox(height: 8),
                                      Wrap(
                                        spacing: 4,
                                        runSpacing: 4,
                                        children: akses.take(isSmallScreen ? 4 : 6).map((e) {
                                          return Chip(
                                            label: Text(
                                              e,
                                              style: TextStyle(fontSize: 10),
                                            ),
                                            backgroundColor: Colors.grey.shade200,
                                          );
                                        }).toList()
                                          ..addAll(akses.length > (isSmallScreen ? 4 : 6)
                                              ? [
                                                  Chip(
                                                    label: Text(
                                                      '+${akses.length - (isSmallScreen ? 4 : 6)} lainnya',
                                                      style: TextStyle(fontSize: 10),
                                                    ),
                                                    backgroundColor: Colors.orange.shade100,
                                                  )
                                                ]
                                              : []),
                                      ),
                                      SizedBox(height: 12),

                                      // Action Buttons
                                      Row(
                                        mainAxisAlignment: MainAxisAlignment.end,
                                        children: [
                                          IconButton(
                                            icon: Icon(Icons.edit, color: Colors.green.shade600),
                                            onPressed: () => showRoleForm(role: role),
                                            tooltip: 'Edit Peran',
                                          ),
                                          IconButton(
                                            icon: Icon(Icons.delete, color: Colors.red.shade600),
                                            onPressed: () => deleteRole(
                                              role['id'].toString(),
                                              role['nama'] ?? 'Unknown',
                                            ),
                                            tooltip: 'Hapus Peran',
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ),
                              );
                            },
                          ),
              ),
            
              if (totalPages > 1)
                Card(
                  elevation: 4,
                  child: Padding(
                    padding: EdgeInsets.all(16),
                    child: Column(
                      children: [
                        if (!isSmallScreen)
                          Text(
                            'Menampilkan ${(currentPage - 1) * entriesToShow + 1} - ${(currentPage * entriesToShow > filteredRoles.length) ? filteredRoles.length : currentPage * entriesToShow} dari ${filteredRoles.length} entri',
                            style: TextStyle(color: Colors.grey.shade600),
                          ),
                        if (!isSmallScreen) SizedBox(height: 8),
                        SingleChildScrollView(
                          scrollDirection: Axis.horizontal,
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              IconButton(
                                onPressed: currentPage > 1 ? () => setState(() => currentPage = 1) : null,
                                icon: Icon(Icons.first_page),
                                tooltip: 'Halaman Pertama',
                              ),
                              IconButton(
                                onPressed: currentPage > 1 ? () => setState(() => currentPage--) : null,
                                icon: Icon(Icons.chevron_left),
                                tooltip: 'Halaman Sebelumnya',
                              ),
                              Container(
                                padding: EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                                decoration: BoxDecoration(
                                  color: Colors.blue.shade100,
                                  borderRadius: BorderRadius.circular(8),
                                ),
                                child: Text(
                                  "Hal $currentPage/$totalPages",
                                  style: TextStyle(
                                    fontWeight: FontWeight.w600,
                                    color: Colors.blue.shade800,
                                    fontSize: 12,
                                  ),
                                ),
                              ),
                              IconButton(
                                onPressed: currentPage < totalPages ? () => setState(() => currentPage++) : null,
                                icon: Icon(Icons.chevron_right),
                                tooltip: 'Halaman Selanjutnya',
                              ),
                              IconButton(
                                onPressed: currentPage < totalPages ? () => setState(() => currentPage = totalPages) : null,
                                icon: Icon(Icons.last_page),
                                tooltip: 'Halaman Terakhir',
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatCard({
    required IconData icon,
    required String count,
    required String label,
    required Color color,
  }) {
    return Card(
      elevation: 4,
      child: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(icon, color: color, size: 32),
            SizedBox(height: 8),
            Text(
              count,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              label,
              style: TextStyle(color: Colors.grey.shade600),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
