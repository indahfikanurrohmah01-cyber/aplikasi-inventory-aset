import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

// Background Wrapper Widget (reused from your previous code)
class BackgroundWrapper extends StatelessWidget {
  final Widget child;
  final bool showOverlay;
  final double overlayOpacity;
  final Color overlayColor;

  const BackgroundWrapper({
    super.key,
    required this.child,
    this.showOverlay = true,
    this.overlayOpacity = 0.85,
    this.overlayColor = Colors.white,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        image: DecorationImage(
          image: NetworkImage('https://hebbkx1anhila5yf.public.blob.vercel-storage.com/image-G0vswoxbNB5BxwViFb6VNhmskcXuly.png'),
          fit: BoxFit.cover,
        ),
      ),
      child: showOverlay
          ? Container(
              decoration: BoxDecoration(
                color: overlayColor.withOpacity(overlayOpacity),
              ),
              child: child,
            )
          : child,
    );
  }
}

// Model untuk data barang (disesuaikan dengan output PHP Anda)
class BarangPemakaian {
  final int idBarang;
  final String kodeBarang;
  final String namaBarang;
  final double harga;
  final String idKategori; // Asumsi ini adalah nama kategori atau ID yang bisa ditampilkan
  final int stok; // Jumlah barang yang dipakai/dikembalikan
  final String satuan;
  final String lokasi;
  final String tanggalPembelian; // Tanggal pembelian, bisa juga dianggap tanggal awal pemakaian
  final String createdAt;
  final String kondisi; // Kondisi barang
  final String material;
  final String tahun;
  final String merk;
  final String? gambarBarang;
  final String statusPermintaan; // Status dari permintaan (pending, diterima, ditolak)
  final String statusPemakaian; // Status pemakaian (dipakai, dikembalikan, rusak, tersedia)

  BarangPemakaian({
    required this.idBarang,
    required this.kodeBarang,
    required this.namaBarang,
    required this.harga,
    required this.idKategori,
    required this.stok,
    required this.satuan,
    required this.lokasi,
    required this.tanggalPembelian,
    required this.createdAt,
    required this.kondisi,
    required this.material,
    required this.tahun,
    required this.merk,
    this.gambarBarang,
    required this.statusPermintaan,
    required this.statusPemakaian,
  });

  factory BarangPemakaian.fromJson(Map<String, dynamic> json) {
    return BarangPemakaian(
      idBarang: int.tryParse(json['id_barang']?.toString() ?? '0') ?? 0,
      kodeBarang: json['kode_barang']?.toString() ?? '',
      namaBarang: json['nama_barang']?.toString() ?? '',
      harga: double.tryParse(json['harga']?.toString() ?? '0.0') ?? 0.0,
      idKategori: json['id_kategori']?.toString() ?? '',
      stok: int.tryParse(json['stok']?.toString() ?? '0') ?? 0,
      satuan: json['satuan']?.toString() ?? '',
      lokasi: json['lokasi']?.toString() ?? '',
      tanggalPembelian: json['tanggal_pembelian']?.toString() ?? '',
      createdAt: json['created_at']?.toString() ?? '',
      kondisi: json['kondisi']?.toString() ?? '',
      material: json['material']?.toString() ?? '',
      tahun: json['tahun']?.toString() ?? '',
      merk: json['merk']?.toString() ?? '',
      gambarBarang: json['gambar_barang']?.toString(),
      statusPermintaan: json['status_permintaan']?.toString() ?? '',
      statusPemakaian: json['status_pemakaian']?.toString() ?? '',
    );
  }
}

// Service untuk API (disesuaikan dengan output PHP dan filter status)
class BarangService {
  static const String baseUrl = 'http://localhost/api_inventory';

  Future<List<BarangPemakaian>> getBarangByUser(String userId, String statusFilter) async {
    try {
      String url = '$baseUrl/get_barang_by_user.php?userId=$userId';
      // Tambahkan filter status jika bukan 'semua'
      // if (statusFilter.toLowerCase() != 'semua') {
      //   url += '&status=${statusFilter.toLowerCase()}';
      // }
      final response = await http.get(
        Uri.parse(url),
        headers: {'Content-Type': 'application/json'},
      );
      // print('Response Status: ${response.statusCode}');
      // print('Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          // PHP mengembalikan data di bawah kunci 'barang', bukan 'data'
          List<dynamic> barangListJson = data['barang'] ?? [];
          return barangListJson.map((item) => BarangPemakaian.fromJson(item)).toList();
        } else {
          throw Exception(data['message'] ?? 'Gagal mengambil data');
        }
      } else {
        throw Exception('HTTP Error: ${response.statusCode}');
      }
    } catch (e) {
      // print('Service Error: $e');
      throw Exception('Error: $e');
    }
  }
}

// Halaman Riwayat Pemakaian
class RiwayatPemakaianPage extends StatefulWidget {
  final String userId; // Menerima userId melalui konstruktor
  const RiwayatPemakaianPage({super.key, required this.userId});

  @override
  State<RiwayatPemakaianPage> createState() => _RiwayatPemakaianPageState();
}

class _RiwayatPemakaianPageState extends State<RiwayatPemakaianPage> {
  final BarangService _barangService = BarangService();
  List<BarangPemakaian> _barangList = [];
  bool _isLoading = true;
  String _errorMessage = '';
  String _filterStatus = 'semua'; // Default filter
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadBarangData(); // Langsung panggil _loadBarangData karena userId sudah ada
  }

  Future<void> _loadBarangData() async {
    setState(() {
      _isLoading = true;
      _errorMessage = '';
    });
    try {
      // print('Fetching data for user ID: ${widget.userId} with status: $_filterStatus');
      // Panggil service dengan userId dari widget dan selalu 'semua' untuk status filter
      // Ini akan menghasilkan URL tanpa parameter &status
      final barangList = await _barangService.getBarangByUser(widget.userId, 'semua');
      // print('Fetched ${barangList.length} items');
      setState(() {
        _barangList = barangList;
        _isLoading = false;
      });
    } catch (e) {
      // print('Load data error: $e');
      setState(() {
        _errorMessage = e.toString();
        _isLoading = false;
      });
    }
  }

  // Getter untuk barang yang difilter (berdasarkan pencarian saja, status sudah difilter API)
  List<BarangPemakaian> get _filteredBarang {
    List<BarangPemakaian> filtered = _barangList;
    if (_searchController.text.isNotEmpty) {
      filtered = filtered.where((barang) =>
            barang.namaBarang.toLowerCase().contains(_searchController.text.toLowerCase()) ||
            barang.idKategori.toLowerCase().contains(_searchController.text.toLowerCase()) ||
            barang.kondisi.toLowerCase().contains(_searchController.text.toLowerCase()) ||
            barang.merk.toLowerCase().contains(_searchController.text.toLowerCase()))
          .toList();
    }
    // Filter berdasarkan status pemakaian lokal setelah data diambil
    if (_filterStatus.toLowerCase() != 'semua') {
      filtered = filtered.where((barang) => barang.statusPemakaian.toLowerCase() == _filterStatus.toLowerCase()).toList();
    }
    return filtered;
  }

  // Fungsi pembantu untuk menampilkan warna, ikon, dan teks berdasarkan status_pemakaian
  Color _getStatusColor(String statusPemakaian) {
    switch (statusPemakaian.toLowerCase()) {
      case 'dipakai':
        return Colors.blue;
      case 'dikembalikan':
        return Colors.green;
      case 'rusak':
        return Colors.red;
      case 'tersedia':
        return Colors.grey;
      default:
        return Colors.orange; // Default untuk status lain
    }
  }

  IconData _getStatusIcon(String statusPemakaian) {
    switch (statusPemakaian.toLowerCase()) {
      case 'dipakai':
        return Icons.build_circle;
      case 'dikembalikan':
        return Icons.check_circle;
      case 'rusak':
        return Icons.error;
      case 'tersedia':
        return Icons.inventory_2_outlined;
      default:
        return Icons.info_outline;
    }
  }

  String _getStatusText(String statusPemakaian) {
    switch (statusPemakaian.toLowerCase()) {
      case 'dipakai':
        return 'SEDANG DIGUNAKAN';
      case 'dikembalikan':
        return 'SUDAH DIKEMBALIKAN';
      case 'rusak':
        return 'RUSAK';
      case 'tersedia':
        return 'TERSEDIA';
      default:
        return 'TIDAK DIKETAHUI';
    }
  }

  Widget _buildBarangCard(BarangPemakaian barang) {
    final statusColor = _getStatusColor(barang.statusPemakaian);
    final statusIcon = _getStatusIcon(barang.statusPemakaian);
    final statusText = _getStatusText(barang.statusPemakaian);

    return Card(
      margin: const EdgeInsets.only(bottom: 12.0),
      elevation: 6, // Tingkatkan elevasi untuk bayangan yang lebih menonjol
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      color: Colors.blue.shade50, // Latar belakang kartu dengan warna biru sangat muda
      child: Padding( // Hapus InkWell di sini, karena tombol DETAIL akan menangani tap
        padding: const EdgeInsets.all(18.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        barang.namaBarang,
                        style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Colors.blue[800], // Warna teks judul lebih gelap
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        'Kategori: ${barang.idKategori}',
                        style: TextStyle(
                          color: Colors.blueGrey[700], // Warna teks kategori
                          fontSize: 15,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Kondisi: ${barang.kondisi}',
                        style: TextStyle(
                          color: Colors.blueGrey[700], // Warna teks kondisi
                          fontSize: 15,
                        ),
                      ),
                    ],
                  ),
                ),
                // Tombol DETAIL menggantikan tag status
                OutlinedButton.icon(
                  onPressed: () => _showDetailDialog(barang),
                  icon: const Icon(Icons.info_outline, size: 18),
                  label: const Text('DETAIL'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: Colors.blue[700],
                    side: BorderSide(color: Colors.blue[700]!),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                    textStyle: const TextStyle(fontSize: 13, fontWeight: FontWeight.w600),
                  ),
                ),
              ],
            ),
            Divider(height: 28, thickness: 1, color: Colors.blue.shade100), // Divider lebih tebal dan warna biru muda
            _buildInfoRow(
              Icons.calendar_today,
              'Tanggal Pembelian',
              barang.tanggalPembelian,
            ),
            _buildInfoRow(
              Icons.location_on_outlined,
              'Lokasi',
              barang.lokasi,
            ),
            _buildInfoRow(
              Icons.numbers,
              'Jumlah',
              '${barang.stok} ${barang.satuan}',
            ),
            _buildInfoRow(
              Icons.label_outline,
              'Merk',
              barang.merk,
            ),
            _buildInfoRow(
              Icons.calendar_view_month,
              'Tahun',
              barang.tahun,
            ),
            _buildInfoRow(
              Icons.texture,
              'Material',
              barang.material,
            ),
            // Menambahkan status pemakaian sebagai info row terpisah
            _buildInfoRow(
              statusIcon, // Menggunakan ikon status yang sesuai
              'Status Pemakaian',
              statusText, // Menggunakan teks status yang sesuai
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(icon, size: 20, color: Colors.blue[600]), // Warna ikon info menjadi biru yang lebih kuat
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.blueGrey[500], // Warna label info
                  ),
                ),
                Text(
                  value,
                  style: TextStyle(
                    fontSize: 15,
                    fontWeight: FontWeight.w600,
                    color: Colors.blueGrey[900], // Warna nilai info lebih gelap
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  void _showDetailDialog(BarangPemakaian barang) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: Text(barang.namaBarang),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text('Kode Barang: ${barang.kodeBarang}'),
              Text('Kategori: ${barang.idKategori}'),
              Text('Harga: ${barang.harga}'),
              Text('Jumlah: ${barang.stok} ${barang.satuan}'),
              Text('Lokasi: ${barang.lokasi}'),
              Text('Tanggal Pembelian: ${barang.tanggalPembelian}'),
              Text('Dibuat Pada: ${barang.createdAt}'),
              Text('Kondisi: ${barang.kondisi}'),
              Text('Material: ${barang.material}'),
              Text('Tahun: ${barang.tahun}'),
              Text('Merk: ${barang.merk}'),
              Text('Status Permintaan: ${barang.statusPermintaan}'),
              Text('Status Pemakaian: ${barang.statusPemakaian}'),
              if (barang.gambarBarang != null && barang.gambarBarang!.isNotEmpty)
                Padding(
                  padding: const EdgeInsets.only(top: 16.0),
                  child: Image.network(
                    barang.gambarBarang!,
                    fit: BoxFit.contain,
                    errorBuilder: (context, error, stackTrace) => const Text('Gambar tidak dapat dimuat.'),
                  ),
                ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Tutup'),
          ),
        ],
      ),
    );
  }

  Widget _buildListView() {
    if (_isLoading) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(
              valueColor: AlwaysStoppedAnimation<Color>(Colors.blue[700]!),
            ),
            const SizedBox(height: 16),
            Text(
              'Memuat riwayat pemakaian...',
              style: TextStyle(
                color: Colors.grey[600],
                fontSize: 16,
              ),
            ),
          ],
        ),
      );
    }

    if (_errorMessage.isNotEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error, size: 64, color: Colors.red),
            const SizedBox(height: 16),
            Text(
              'Terjadi Kesalahan',
              style: Theme.of(context).textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            Text(_errorMessage, textAlign: TextAlign.center),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loadBarangData,
              child: const Text('Coba Lagi'),
            ),
          ],
        ),
      );
    }

    if (_filteredBarang.isEmpty) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.history_toggle_off,
              size: 80,
              color: Colors.grey[300],
            ),
            const SizedBox(height: 16),
            Text(
              'Tidak ada riwayat pemakaian',
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey[600],
                fontWeight: FontWeight.w500,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Belum ada riwayat pemakaian barang untuk status ini',
              style: TextStyle(
                fontSize: 14,
                color: Colors.grey[500],
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: _loadBarangData,
      child: ListView.builder(
        padding: const EdgeInsets.all(16.0),
        itemCount: _filteredBarang.length,
        itemBuilder: (context, index) {
          return _buildBarangCard(_filteredBarang[index]);
        },
      ),
    );
  }

  // Drawer Header (reused)
  Widget _drawerHeader() {
    return DrawerHeader(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.blue[700]!, Colors.blue[800]!],
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          CircleAvatar(
            radius: 30,
            backgroundColor: Colors.white,
            child: Icon(
              Icons.person,
              size: 35,
              color: Colors.blue[700],
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Halo, Indahfika',
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.w600,
            ),
          ),
          Text(
            'User ID: ${widget.userId}',
            style: TextStyle(
              color: Colors.white.withOpacity(0.8),
              fontSize: 14,
            ),
          ),
        ],
      ),
    );
  }

  // Drawer Section (reused)
  Widget _drawerSection(String title) {
    return Container(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 8),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 12,
          fontWeight: FontWeight.w600,
          color: Colors.grey[600],
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  // Drawer Item (reused)
  Widget _drawerItem(IconData icon, String title, bool isActive, VoidCallback onTap) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(8),
        color: isActive ? Colors.blue[50] : null,
      ),
      child: ListTile(
        leading: Icon(
          icon,
          color: isActive ? Colors.blue[700] : Colors.grey[600],
          size: 22,
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isActive ? Colors.blue[700] : Colors.grey[700],
            fontWeight: isActive ? FontWeight.w600 : FontWeight.w500,
            fontSize: 14,
          ),
        ),
        onTap: onTap,
        dense: true,
        visualDensity: const VisualDensity(vertical: -2),
      ),
    );
  }

  // Navigation logic (diperbaiki untuk menerima NavigatorState dan ScaffoldMessengerState)
  void _navigate(NavigatorState navigator, ScaffoldMessengerState messenger, String route, String title) {
    // Tutup drawer terlebih dahulu
    if (navigator.canPop()) {
      navigator.pop(); // Tutup drawer
    }
    messenger.showSnackBar(
      SnackBar(
        content: Text('Navigasi ke halaman $title...'),
        duration: const Duration(milliseconds: 500),
        backgroundColor: const Color.fromARGB(255, 89, 232, 173),
      ),
    );
    // Navigasi
    switch (route) {
      case '/user-dashboard':
        if (mounted) {
          navigator.pushReplacementNamed(route);
        }
        break;
      case '/daftar-barang-user':
        if (mounted) {
          navigator.pushNamed(route);
        }
        break;
      case '/daftar-ruangan-user':
        if (mounted) {
          navigator.pushNamed(route);
        }
        break;
      case '/riwayat-pemakaian':
        // Ini adalah halaman saat ini, tidak perlu navigasi, cukup tutup drawer
        break;
      case '/laporan-saya':
        if (mounted) {
          navigator.pushNamed(route);
        }
        break;
      case '/': // Mengarahkan ke HomePage
        if (mounted) {
          navigator.pushNamed(route);
        }
        break;
      case '/pengaturan-profile-user': // Rute yang diperbaiki
        if (mounted) {
          navigator.pushNamed(route);
        }
        break;
      case '/status-permintaan':
        if (mounted) {
          navigator.pushNamed(
            route,
            arguments: {'userId': widget.userId},
          );
        }
        break;
      case '/riwayat-permintaan-page':
        if (mounted) {
          navigator.pushNamed(route);
        }
        break;
      default:
        if (mounted) {
          messenger.showSnackBar(
            SnackBar(
              content: Text('Route $route not found'),
              backgroundColor: Colors.red,
            ),
          );
        }
    }
  }

  // Logout logic (diperbaiki untuk menerima NavigatorState dan ScaffoldMessengerState)
  void _logout(NavigatorState navigator, ScaffoldMessengerState messenger) {
    showDialog(
      context: context, // Gunakan context dari State untuk showDialog
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        title: Row(
          children: [
            Icon(Icons.logout, color: Colors.red[600]),
            const SizedBox(width: 8),
            const Text('Logout'),
          ],
        ),
        content: const Text('Apakah Anda yakin ingin keluar dari aplikasi?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext), // Pop dialog menggunakan dialogContext
            child: Text(
              'Batal',
              style: TextStyle(color: Colors.grey[600]),
            ),
          ),
          ElevatedButton(
            onPressed: () async {
              Navigator.pop(dialogContext); // Tutup dialog
              if (navigator.canPop()) { // Cek apakah bisa pop (misal: drawer terbuka)
                navigator.pop(); // Tutup drawer jika terbuka
              }
              final prefs = await SharedPreferences.getInstance();
              await prefs.clear();
              if (mounted) {
                messenger.showSnackBar(
                  const SnackBar(
                    content: Text('Berhasil logout'),
                    backgroundColor: Colors.green,
                    duration: Duration(seconds: 1),
                  ),
                );
                // Navigasi ke halaman login dan hapus semua rute sebelumnya
                navigator.pushNamedAndRemoveUntil(
                  '/', // Menggunakan rute '/' yang sudah didefinisikan (HomePage atau LoginPage)
                  (Route<dynamic> route) => false,
                );
              }
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red[600],
              foregroundColor: Colors.white,
            ),
            child: const Text('Logout'),
          ),
        ],
      ),
    );
  }

  // Show Profile Dialog (diperbaiki untuk menerima NavigatorState dan ScaffoldMessengerState)
  void _showProfile(NavigatorState navigator, ScaffoldMessengerState messenger) {
    showDialog(
      context: context, // Gunakan context dari State untuk showDialog
      builder: (dialogContext) => AlertDialog(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
        title: const Text('Profil Pengguna'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                CircleAvatar(
                  radius: 30,
                  backgroundColor: Colors.blue[100],
                  child: Icon(Icons.person, size: 30, color: Colors.blue[700]),
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const Text(
                        'Indahfika',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'indahfika@diskominfo.go.id',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey,
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Divider(),
            const SizedBox(height: 8),
            _buildProfileInfo('User ID', widget.userId),
            _buildProfileInfo('Role', 'User'),
            _buildProfileInfo('Status', 'Aktif'),
            _buildProfileInfo('Department', 'Diskominfo'),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(dialogContext), // Pop dialog menggunakan dialogContext
            child: Text(
              'Tutup',
              style: TextStyle(color: Colors.grey[600]),
            ),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.pop(dialogContext); // Pop dialog menggunakan dialogContext
              _navigate(navigator, messenger, '/pengaturan-profile-user', 'Pengaturan Profil'); // Rute yang diperbaiki
            },
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.blue[700],
              foregroundColor: Colors.white,
            ),
            child: const Text('Edit Profil'),
          ),
        ],
      ),
    );
  }

  // Build Profile Info (reused)
  Widget _buildProfileInfo(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 80,
            child: Text(
              '$label:',
              style: TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.grey[700],
              ),
            ),
          ),
          Expanded(
            child: Text(
              value,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return BackgroundWrapper(
      child: Builder( // Builder ini penting untuk mendapatkan context yang benar untuk Scaffold
        builder: (BuildContext scaffoldContext) {
          final navigator = Navigator.of(scaffoldContext);
          final messenger = ScaffoldMessenger.of(scaffoldContext);
          return Scaffold(
            backgroundColor: Colors.transparent,
            appBar: AppBar(
              title: const Text('Riwayat Pemakaian Barang'),
              backgroundColor: Colors.blue[700],
              foregroundColor: Colors.white,
              actions: [
                IconButton(
                  icon: const Icon(Icons.refresh),
                  onPressed: _loadBarangData,
                  tooltip: 'Refresh',
                ),
                IconButton(
                  icon: const Icon(Icons.person_outline),
                  onPressed: () => _showProfile(navigator, messenger), // Teruskan navigator dan messenger
                  tooltip: 'Profil',
                ),
                PopupMenuButton<String>(
                  icon: const Icon(Icons.more_vert),
                  onSelected: (value) {
                    switch (value) {
                      case 'profile':
                        _showProfile(navigator, messenger); // Teruskan navigator dan messenger
                        break;
                      case 'settings':
                        _navigate(navigator, messenger, '/pengaturan-profile-user', 'Pengaturan Profil'); // Rute yang diperbaiki
                        break;
                      case 'logout':
                        _logout(navigator, messenger); // Teruskan navigator dan messenger
                        break;
                    }
                  },
                  itemBuilder: (BuildContext context) => [
                    const PopupMenuItem<String>(
                      value: 'profile',
                      child: Row(
                        children: [
                          Icon(Icons.person_outline, size: 20),
                          SizedBox(width: 8),
                          Text('Profil'),
                        ],
                      ),
                    ),
                    const PopupMenuItem<String>(
                      value: 'settings',
                      child: Row(
                        children: [
                          Icon(Icons.settings_outlined, size: 20),
                          SizedBox(width: 8),
                          Text('Pengaturan'),
                        ],
                      ),
                    ),
                    const PopupMenuItem<String>(
                      value: 'logout',
                      child: Row(
                        children: [
                          Icon(Icons.logout, size: 20, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Logout', style: TextStyle(color: Colors.red)),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            drawer: Drawer( // Tambahkan Drawer di sini
              child: ListView(
                padding: EdgeInsets.zero,
                children: <Widget>[
                  _drawerHeader(),
                  _drawerSection('DASHBOARD'),
                  _drawerItem(Icons.dashboard, 'Dashboard', false, () => _navigate(navigator, messenger, '/user-dashboard', 'Dashboard')), // Teruskan navigator dan messenger
                  _drawerSection('MANAJEMEN BARANG'),
                  _drawerItem(Icons.inventory_2_outlined, 'Barang Saya', false, () => _navigate(navigator, messenger, '/daftar-barang-user', 'Daftar Barang User')), // Teruskan navigator dan messenger
                  _drawerItem(Icons.history, 'Riwayat Pemakaian', true, () => _navigate(navigator, messenger, '/riwayat-pemakaian', 'Riwayat Pemakaian')), // Teruskan navigator dan messenger
                  _drawerItem(Icons.receipt_long, 'Riwayat Permintaan', false, () => _navigate(navigator, messenger, '/riwayat-permintaan-page', 'Riwayat Permintaan')), // Teruskan navigator dan messenger
                  _drawerItem(Icons.check_circle_outline, 'Status Permintaan', false, () => _navigate(navigator, messenger, '/status-permintaan', 'Status Permintaan')), // Teruskan navigator dan messenger
                  _drawerItem(Icons.description, 'Laporan Saya', false, () => _navigate(navigator, messenger, '/laporan-saya', 'Laporan Saya')), // Teruskan navigator dan messenger
                  _drawerSection('PENGATURAN'),
                  _drawerItem(Icons.settings, 'Pengaturan Profil', false, () => _navigate(navigator, messenger, '/pengaturan-profile-user', 'Pengaturan Profil')), // Rute yang diperbaiki
                  _drawerItem(Icons.logout, 'Logout', false, () => _logout(navigator, messenger)), // Teruskan navigator dan messenger
                ],
              ),
            ),
            body: Column(
              children: [
                // Search dan Filter
                Container(
                  padding: const EdgeInsets.all(16.0),
                  decoration: BoxDecoration(
                    color: Colors.blue.shade50, // Warna latar belakang yang lebih terang
                    boxShadow: [
                      BoxShadow(
                        color: Colors.grey.withOpacity(0.1),
                        spreadRadius: 1,
                        blurRadius: 3,
                        offset: const Offset(0, 2), // changes position of shadow
                      ),
                    ],
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Search Bar
                      TextField(
                        controller: _searchController,
                        decoration: InputDecoration(
                          hintText: 'Cari nama barang, kategori, kondisi, atau merk...',
                          prefixIcon: const Icon(Icons.search, color: Colors.blue), // Warna ikon pencarian
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide.none, // Hapus border default
                          ),
                          enabledBorder: OutlineInputBorder( // Border saat tidak fokus
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(color: Colors.blue.shade100, width: 1),
                          ),
                          focusedBorder: OutlineInputBorder( // Border saat fokus
                            borderRadius: BorderRadius.circular(10),
                            borderSide: BorderSide(color: Colors.blue.shade700, width: 2),
                          ),
                          filled: true,
                          fillColor: Colors.white,
                          contentPadding: const EdgeInsets.symmetric(vertical: 12, horizontal: 16), // Padding konten
                        ),
                        onChanged: (value) => setState(() {}), // Trigger rebuild for filtering
                      ),
                      const SizedBox(height: 10),
                      // Filter Status
                      Row(
                        children: [
                          const Text('Filter Status Pemakaian: '),
                          const SizedBox(width: 10),
                          Expanded(
                            child: DropdownButton<String>(
                              value: _filterStatus,
                              isExpanded: true,
                              icon: const Icon(Icons.arrow_drop_down, color: Colors.blue), // Warna ikon dropdown
                              underline: Container( // Hapus underline default
                                height: 0,
                                color: Colors.transparent,
                              ),
                              style: TextStyle(
                                color: Colors.blue[700], // Warna teks dropdown
                                fontSize: 14,
                                fontWeight: FontWeight.w500,
                              ),
                              items: ['semua', 'dipakai', 'dikembalikan', 'rusak']
                                  .map((status) => DropdownMenuItem(
                                        value: status,
                                        child: Text(
                                          status.toUpperCase(),
                                          style: TextStyle(color: Colors.blue[700]), // Warna teks item dropdown
                                        ),
                                      ))
                                  .toList(),
                              onChanged: (value) {
                                setState(() {
                                  _filterStatus = value!;
                                });
                              },
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
                // Content
                Expanded(
                  child: _buildListView(),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }
}