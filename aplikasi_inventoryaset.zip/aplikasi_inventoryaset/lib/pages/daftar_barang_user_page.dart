import 'dart:convert';
import 'dart:io';
import 'package:excel/excel.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:flutter/foundation.dart' as foundation;
import 'package:aplikasi_inventoryaset/pages/add_barang_page.dart';

const String currentUserId = 'user4'; // Contoh: Ganti dengan ID pengguna sebenarnya

class DaftarBarangUserPage extends StatefulWidget {
  const DaftarBarangUserPage({super.key});

  @override
  State<DaftarBarangUserPage> createState() => _DaftarBarangUserPageState();
}

class _DaftarBarangUserPageState extends State<DaftarBarangUserPage> {
  List<dynamic> barangList = [];
  List<dynamic> filteredList = [];
  String? lokasi;
  String? kondisi;
  String? tahun;
  String? material;
  String? merk;
  bool _isFilterExpanded = false;

  @override
  void initState() {
    super.initState();
    fetchBarang();
  }

  Future<void> fetchBarang() async {
    try {
      final response = await http.get(Uri.parse('http://localhost/api_inventory/get_barang_by_user.php?userId=4'));
      if (!mounted) return;

      debugPrint('API Response Status Code: ${response.statusCode}');
      debugPrint('API Response Body: ${response.body}');

      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          setState(() {
            barangList = data['barang'] as List<dynamic>;
            filteredList = barangList;
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(
              content: Text('Error: ${data['message']}'),
              backgroundColor: Colors.red,
            ),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to load data: Server responded with status ${response.statusCode}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    } catch (e) {
      if (!mounted) return;
      debugPrint('Error fetching: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Gagal memuat data barang: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void applyFilter() {
    setState(() {
      filteredList = barangList.where((item) {
        return (lokasi == null || item['lokasi'] == lokasi) &&
            (kondisi == null || item['kondisi'] == kondisi) &&
            (tahun == null || item['tahun'].toString() == tahun) &&
            (material == null || item['material'] == material) &&
            (merk == null || item['merk'] == merk);
      }).toList();
    });
  }

  void applySingleFilter(String field, String? value) {
    setState(() {
      switch (field) {
        case 'lokasi':
          lokasi = value;
          break;
        case 'kondisi':
          kondisi = value;
          break;
        case 'tahun':
          tahun = value;
          break;
        case 'material':
          material = value;
          break;
        case 'merk':
          merk = value;
          break;
      }
      applyFilter();
    });
  }

  void resetFilter() {
    setState(() {
      lokasi = kondisi = tahun = material = merk = null;
      filteredList = barangList;
    });
  }

  Future<void> importFile() async {
    FilePickerResult? result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['xlsx'],
    );
    if (!mounted) return;
    if (result != null) {
      File file = File(result.files.single.path!);
      var bytes = file.readAsBytesSync();
      var excel = Excel.decodeBytes(bytes);
      for (var table in excel.tables.keys) {
        for (var row in excel.tables[table]!.rows.skip(1)) {
          debugPrint(row.map((e) => e?.value).join(', '));
        }
      }
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Import berhasil dibaca'),
          backgroundColor: Colors.green,
        ),
      );
    }
  }

  Future<void> exportToExcel() async {
    var excel = Excel.createExcel();
    Sheet sheet = excel['Sheet1'];
    sheet.appendRow(['Kode', 'Nama', 'Material', 'Merk', 'Kondisi', 'Tahun']);
    for (var item in filteredList) {
      sheet.appendRow([
        item['kode_barang'],
        item['nama_barang'],
        item['material'],
        item['merk'],
        item['kondisi'],
        item['tahun'].toString()
      ]);
    }
    final fileBytes = excel.save();
    if (foundation.kIsWeb) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Export Excel berhasil! File akan diunduh.'),
          backgroundColor: Colors.green,
        ),
      );
    } else {
      try {
        final String? directory = await FilePicker.platform.getDirectoryPath();
        if (!mounted) return;
        if (directory != null) {
          final file = File('$directory/export_barang.xlsx');
          await file.writeAsBytes(fileBytes!);
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Export berhasil disimpan'),
              backgroundColor: Colors.green,
            ),
          );
        } else {
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Penyimpanan dibatalkan atau tidak ada folder dipilih.'),
              backgroundColor: Colors.orange,
            ),
          );
        }
      } catch (e) {
        if (!mounted) return;
        debugPrint("Error exporting on platform: $e");
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Error export: ${e.toString()}'),
            backgroundColor: Colors.red,
          ),
        );
      }
    }
  }

  Future<void> printData() async {
    final pdf = pw.Document();
    pdf.addPage(pw.Page(
        pageFormat: PdfPageFormat.a4.landscape,
        build: (pw.Context context) {
          return pw.TableHelper.fromTextArray(
            headers: ['Kode', 'Nama', 'Material', 'Merk', 'Kondisi', 'Tahun'],
            data: filteredList.map((item) => [
                  item['kode_barang'],
                  item['nama_barang'],
                  item['material'],
                  item['merk'],
                  item['kondisi'],
                  item['tahun'].toString()
                ]).toList(),
            headerStyle: pw.TextStyle(fontWeight: pw.FontWeight.bold, color: PdfColors.white),
            headerDecoration: const pw.BoxDecoration(color: PdfColors.indigo600),
            cellAlignment: pw.Alignment.centerLeft,
            cellPadding: const pw.EdgeInsets.all(8),
            border: pw.TableBorder.all(color: PdfColors.grey),
          );
        }));
    await Printing.layoutPdf(onLayout: (PdfPageFormat format) async => pdf.save());
  }

  List<String> _getUniqueList(String field) {
    final set = <String>{};
    for (var item in barangList) {
      if (item[field] != null && item[field].toString().isNotEmpty) {
        set.add(item[field].toString());
      }
    }
    return set.toList();
  }

  Widget buildStatBox(Color color, IconData icon, String title, int value) {
    return Expanded(
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.1),
              spreadRadius: 1,
              blurRadius: 6,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(icon, color: color, size: 24),
            ),
            const SizedBox(height: 12),
            Text(
              title,
              style: const TextStyle(
                fontSize: 12,
                color: Colors.grey,
                fontWeight: FontWeight.w500,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 4),
            Text(
              value.toString(),
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Colors.black87,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildDropdown(
      String label, String? value, List<String> options, void Function(String?) onChanged) {
    return Flexible(
      child: Container(
        margin: const EdgeInsets.only(bottom: 12),
        constraints: const BoxConstraints(minWidth: 150, maxWidth: 200),
        child: DropdownButtonFormField<String>(
          value: value,
          decoration: InputDecoration(
            labelText: label,
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(8),
              borderSide: BorderSide(color: Colors.indigo[400]!, width: 2),
            ),
            contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          ),
          items: [
            DropdownMenuItem<String>(value: null, child: Text('Semua $label')),
            ...options.map((e) => DropdownMenuItem(value: e, child: Text(e))).toList(),
          ],
          onChanged: onChanged,
        ),
      ),
    );
  }

  Widget buildDrawer() {
    return Drawer(
      child: Column(
        children: [
          // Drawer Header
          Container(
            height: 200,
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Colors.indigo[400]!, Colors.indigo[600]!],
              ),
            ),
            child: const SafeArea(
              child: Padding(
                padding: EdgeInsets.all(20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.end,
                  children: [
                    CircleAvatar(
                      radius: 30,
                      backgroundColor: Colors.white,
                      child: Icon(
                        Icons.inventory_2,
                        size: 30,
                        color: Colors.indigo,
                      ),
                    ),
                    SizedBox(height: 12),
                    Text(
                      'INVENTRIS',
                      style: TextStyle(
                        color: Colors.white,
                        fontSize: 24,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    Text(
                      'Diskominfo Bengkalis',
                      style: TextStyle(
                        color: Colors.white70,
                        fontSize: 14,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          // Menu Items
          Expanded(
            child: ListView(
              padding: EdgeInsets.zero,
              children: [
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'DASHBOARD',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                _drawerItem(Icons.dashboard, 'Dashboard', '/user-dashboard', false),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'MANAJEMEN BARANG',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                _drawerItem(Icons.inventory_2, 'Daftar Barang', '/daftar-barang-user', true),
                _drawerItem(Icons.meeting_room, 'Daftar Ruangan', '/daftar-ruangan-user', false),
                _drawerItem(Icons.history, 'Riwayat Pemakaian', '/riwayat-pemakaian', false),
                _drawerItem(Icons.receipt_long, 'Laporan Saya', '/laporan-saya', false),
                const Padding(
                  padding: EdgeInsets.fromLTRB(16, 16, 16, 8),
                  child: Text(
                    'PENGATURAN',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey,
                    ),
                  ),
                ),
                _drawerItem(Icons.settings, 'Pengaturan Profil', '/pengaturan-profile-user', false),
              ],
            ),
          ),
          // Logout Section
          Container(
            padding: const EdgeInsets.all(16),
            child: _drawerItem(Icons.logout, 'Logout', '', false, isLogout: true),
          ),
        ],
      ),
    );
  }

  Widget _drawerItem(IconData icon, String title, String route, bool isSelected,
      {bool isLogout = false}) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: ListTile(
        leading: Icon(
          icon,
          color: isLogout
              ? Colors.red
              : isSelected
                  ? Colors.indigo
                  : Colors.grey[600],
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isLogout
                ? Colors.red
                : isSelected
                    ? Colors.indigo
                    : Colors.grey[800],
            fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
          ),
        ),
        selected: isSelected,
        selectedTileColor: Colors.indigo[50],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        onTap: () {
          if (isLogout) {
            _showLogoutDialog();
          } else if (route.isNotEmpty) {
            Navigator.pushReplacementNamed(context, route);
          } else {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Halaman belum tersedia'),
                backgroundColor: Colors.orange,
              ),
            );
          }
        },
      ),
    );
  }

  void _showLogoutDialog() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: const Row(
            children: [
              Icon(Icons.logout, color: Colors.red),
              SizedBox(width: 8),
              Text('Konfirmasi Logout'),
            ],
          ),
          content: const Text('Apakah Anda yakin ingin keluar dari aplikasi?'),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Batal'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.of(context).pop();
                Navigator.pushNamedAndRemoveUntil(context, '/', (route) => false);
              },
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.red,
                foregroundColor: Colors.white,
              ),
              child: const Text('Logout'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      drawer: buildDrawer(),
      appBar: AppBar(
        title: const Text(
          'Daftar Barang',
          style: TextStyle(
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        backgroundColor: Colors.indigo[400],
        elevation: 0,
        iconTheme: const IconThemeData(color: Colors.white),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 16),
            child: DropdownButtonHideUnderline(
              child: DropdownButton<String>(
                icon: const Icon(Icons.keyboard_arrow_down, color: Colors.white),
                dropdownColor: Colors.white,
                style: const TextStyle(color: Colors.black),
                onChanged: (value) {
                  if (value == 'profil') {
                    Navigator.pushNamed(context, '/pengaturan-profile');
                  } else if (value == 'logout') {
                    _showLogoutDialog();
                  }
                },
                items: const [
                  DropdownMenuItem(value: 'profil', child: Text('Pengaturan Profil')),
                  DropdownMenuItem(value: 'logout', child: Text('Logout')),
                ],
                hint: const Row(
                  children: [
                    Icon(Icons.person, color: Colors.white),
                    SizedBox(width: 8),
                    Text(
                      "Halo User",
                      style: TextStyle(color: Colors.white, fontSize: 14),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Colors.indigo[50]!, Colors.purple[50]!],
          ),
        ),
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Statistics Cards
              LayoutBuilder(
                builder: (context, constraints) {
                  if (constraints.maxWidth < 600) {
                    return Column(
                      children: [
                        Row(
                          children: [
                            buildStatBox(Colors.indigo, Icons.inventory, "Total Barang Dikelola",
                                barangList.length),
                            buildStatBox(Colors.green, Icons.check_circle, "Kondisi Baik",
                                barangList.where((e) => e['kondisi'] == 'Baik').length),
                          ],
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            buildStatBox(Colors.orange, Icons.warning, "Rusak Ringan",
                                barangList.where((e) => e['kondisi'] == 'Kurang Baik' || e['kondisi'] == 'Rusak Ringan').length),
                            buildStatBox(Colors.red, Icons.cancel, "Rusak Berat",
                                barangList.where((e) => e['kondisi'] == 'Rusak Berat').length),
                          ],
                        ),
                      ],
                    );
                  } else {
                    return Row(
                      children: [
                        buildStatBox(
                            Colors.indigo, Icons.inventory, "Total Barang Dikelola", barangList.length),
                        buildStatBox(Colors.green, Icons.check_circle, "Kondisi Baik",
                            barangList.where((e) => e['kondisi'] == 'Baik').length),
                        buildStatBox(Colors.orange, Icons.warning, "Rusak Ringan",
                            barangList.where((e) => e['kondisi'] == 'Kurang Baik' || e['kondisi'] == 'Rusak Ringan').length),
                        buildStatBox(Colors.red, Icons.cancel, "Rusak Berat",
                            barangList.where((e) => e['kondisi'] == 'Rusak Berat').length),
                      ],
                    );
                  }
                },
              ),
              const SizedBox(height: 24),
              // Action Buttons
              Container(
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Aksi Data',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: Colors.black87,
                      ),
                    ),
                    const SizedBox(height: 12),
                    LayoutBuilder(builder: (context, constraints) {
                      if (constraints.maxWidth < 600) {
                        return Column(
                          children: [
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: importFile,
                                icon: const Icon(Icons.upload_file, color: Colors.white),
                                label: const Text('Import Excel',
                                    style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.indigo[400],
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: exportToExcel,
                                icon: const Icon(Icons.download, color: Colors.white),
                                label: const Text('Export Excel',
                                    style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                            const SizedBox(height: 8),
                            SizedBox(
                              width: double.infinity,
                              child: ElevatedButton.icon(
                                onPressed: printData,
                                icon: const Icon(Icons.print, color: Colors.white),
                                label: const Text('Print', style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.black87,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                          ],
                        );
                      } else {
                        return Row(
                          children: [
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: importFile,
                                icon: const Icon(Icons.upload_file, color: Colors.white),
                                label: const Text('Import Excel',
                                    style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.indigo[400],
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: exportToExcel,
                                icon: const Icon(Icons.download, color: Colors.white),
                                label: const Text('Export Excel',
                                    style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.green,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                            const SizedBox(width: 8),
                            Expanded(
                              child: ElevatedButton.icon(
                                onPressed: printData,
                                icon: const Icon(Icons.print, color: Colors.white),
                                label: const Text('Print', style: TextStyle(color: Colors.white)),
                                style: ElevatedButton.styleFrom(
                                  backgroundColor: Colors.black87,
                                  padding: const EdgeInsets.symmetric(vertical: 12),
                                  shape: RoundedRectangleBorder(
                                      borderRadius: BorderRadius.circular(8)),
                                ),
                              ),
                            ),
                          ],
                        );
                      }
                    }),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              // Filter Section
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: Column(
                  children: [
                    InkWell(
                      onTap: () {
                        setState(() {
                          _isFilterExpanded = !_isFilterExpanded;
                        });
                      },
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.indigo[400],
                          borderRadius: _isFilterExpanded
                              ? const BorderRadius.only(
                                  topLeft: Radius.circular(12),
                                  topRight: Radius.circular(12),
                                )
                              : BorderRadius.circular(12),
                        ),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            const Text(
                              'Filter Data Barang',
                              style: TextStyle(
                                color: Colors.white,
                                fontWeight: FontWeight.bold,
                                fontSize: 16,
                              ),
                            ),
                            Icon(
                              _isFilterExpanded ? Icons.expand_less : Icons.expand_more,
                              color: Colors.white,
                            ),
                          ],
                        ),
                      ),
                    ),
                    if (_isFilterExpanded)
                      Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          children: [
                            Wrap(
                              spacing: 12,
                              runSpacing: 8,
                              alignment: WrapAlignment.center,
                              children: [
                                _buildDropdown("Lokasi", lokasi, _getUniqueList('lokasi'),
                                    (val) => applySingleFilter('lokasi', val)),
                                _buildDropdown("Kondisi", kondisi, _getUniqueList('kondisi'),
                                    (val) => applySingleFilter('kondisi', val)),
                                _buildDropdown("Tahun", tahun, _getUniqueList('tahun'),
                                    (val) => applySingleFilter('tahun', val)),
                                _buildDropdown("Bahan", material, _getUniqueList('material'),
                                    (val) => applySingleFilter('material', val)),
                                _buildDropdown("Merk", merk, _getUniqueList('merk'),
                                    (val) => applySingleFilter('merk', val)),
                              ],
                            ),
                            const SizedBox(height: 16),
                            Row(
                              children: [
                                Expanded(
                                  child: ElevatedButton.icon(
                                    onPressed: resetFilter,
                                    icon: const Icon(Icons.refresh, color: Colors.white),
                                    label:
                                        const Text('Reset Filter', style: TextStyle(color: Colors.white)),
                                    style: ElevatedButton.styleFrom(
                                      backgroundColor: Colors.orange,
                                      padding: const EdgeInsets.symmetric(vertical: 12),
                                      shape: RoundedRectangleBorder(
                                          borderRadius: BorderRadius.circular(8)),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: 24),
              // Data Table Header
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    'Data Barang (${filteredList.length} item)',
                    style: const TextStyle(
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 16),
              // Data Table
              Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: Colors.grey.withOpacity(0.1),
                      spreadRadius: 1,
                      blurRadius: 6,
                      offset: const Offset(0, 3),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: DataTable(
                    headingRowColor: MaterialStateColor.resolveWith((states) => Colors.grey[50]!),
                    headingTextStyle: const TextStyle(
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                    dataRowHeight: 60,
                    columns: const [
                      DataColumn(label: Text('Kode Barang')),
                      DataColumn(label: Text('Nama Barang')),
                      DataColumn(label: Text('Bahan')),
                      DataColumn(label: Text('Merk')),
                      DataColumn(label: Text('Kondisi')),
                      DataColumn(label: Text('Tahun')),
                    ],
                    rows: filteredList.map((item) {
                      return DataRow(
                        cells: [
                          DataCell(
                            Text(
                              item['kode_barang'] ?? '-',
                              style: const TextStyle(fontWeight: FontWeight.w500),
                            ),
                          ),
                          DataCell(Text(item['nama_barang'] ?? '-')),
                          DataCell(Text(item['material'] ?? '-')),
                          DataCell(Text(item['merk'] ?? '-')),
                          DataCell(
                            Container(
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                              decoration: BoxDecoration(
                                color: Color.fromARGB(
                                  (255 * 0.1).round(),
                                  _getConditionColor(item['kondisi']).red,
                                  _getConditionColor(item['kondisi']).green,
                                  _getConditionColor(item['kondisi']).blue,
                                ),
                                borderRadius: BorderRadius.circular(12),
                              ),
                              child: Text(
                                item['kondisi'] ?? '-',
                                style: TextStyle(
                                  color: _getConditionColor(item['kondisi']),
                                  fontWeight: FontWeight.w500,
                                  fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                          DataCell(Text(item['tahun']?.toString() ?? '-')),
                        ],
                      );
                    }).toList(),
                  ),
                ),
              ),
              if (filteredList.isEmpty)
                Container(
                  margin: const EdgeInsets.only(top: 20),
                  padding: const EdgeInsets.all(40),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: const Center(
                    child: Column(
                      children: [
                        Icon(Icons.inventory_outlined, size: 64, color: Colors.grey),
                        SizedBox(height: 16),
                        Text(
                          'Tidak ada data barang',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.grey,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final result = await Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const AddBarangPage()),
          );
          if (result == true) {
            fetchBarang();
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(
                content: Text('Barang berhasil ditambahkan!'),
                backgroundColor: Colors.green,
              ),
            );
          }
        },
        label: const Text('Tambah Barang', style: TextStyle(color: Colors.white)),
        icon: const Icon(Icons.add, color: Colors.white),
        backgroundColor: Colors.indigo[600],
      ),
    );
  }

  Color _getConditionColor(String? kondisi) {
    switch (kondisi?.toLowerCase()) {
      case 'baik':
        return Colors.green;
      case 'kurang baik':
      case 'rusak ringan':
        return Colors.orange;
      case 'rusak berat':
        return Colors.red;
      default:
        return Colors.grey;
    }
  }
}
