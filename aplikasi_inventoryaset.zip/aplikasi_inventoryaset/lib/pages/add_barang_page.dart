import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';

class AddBarangPage extends StatefulWidget {
  const AddBarangPage({Key? key}) : super(key: key);

  @override
  _AddBarangPageState createState() => _AddBarangPageState();
}

class _AddBarangPageState extends State<AddBarangPage> {
  final _formKey = GlobalKey<FormState>();
  final TextEditingController namaController = TextEditingController();
  final TextEditingController kodeController = TextEditingController();
  final TextEditingController hargaController = TextEditingController();
  final TextEditingController satuanController = TextEditingController();
  final TextEditingController lokasiController = TextEditingController();
  final TextEditingController tanggalController = TextEditingController();
  final TextEditingController materialController = TextEditingController();
  final TextEditingController tahunController = TextEditingController();
  final TextEditingController merkController = TextEditingController();
  final TextEditingController kondisiController = TextEditingController();
  final TextEditingController idKategoriController = TextEditingController();
  final TextEditingController stokController = TextEditingController();

  bool _isLoading = false;
  int userId = 4; // You can make this dynamic based on logged-in user

  @override
  void dispose() {
    namaController.dispose();
    kodeController.dispose();
    hargaController.dispose();
    satuanController.dispose();
    lokasiController.dispose();
    tanggalController.dispose();
    materialController.dispose();
    tahunController.dispose();
    merkController.dispose();
    kondisiController.dispose();
    idKategoriController.dispose();
    stokController.dispose();
    super.dispose();
  }

  Future<void> tambahBarang() async {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    setState(() {
      _isLoading = true;
    });

    final Map<String, String> requestBody = {
      "nama_barang": namaController.text.trim(),
      "kode_barang": kodeController.text.trim(),
      "harga": hargaController.text.trim(),
      "satuan": satuanController.text.trim(),
      "lokasi": lokasiController.text.trim(),
      "tanggal_pembelian": tanggalController.text.trim(),
      "material": materialController.text.trim(),
      "tahun": tahunController.text.trim(),
      "merk": merkController.text.trim(),
      "kondisi": kondisiController.text.trim(),
      "id_kategori": idKategoriController.text.trim(),
      "stok": stokController.text.trim().isEmpty ? "1" : stokController.text.trim(),
      "userId": userId.toString(),
    };

    try {
      final response = await http.post(
        Uri.parse("http://localhost/api_inventory/add_barang.php"),
        body: requestBody,
      );

      if (!mounted) return;

      if (response.statusCode == 200) {
        try {
          final data = jsonDecode(response.body);
          
          if (data['success'] == true) {
            _showSnackBar("Sukses: ${data['message']}", isError: false);
            Navigator.pop(context);
          } else {
            _showSnackBar("Gagal: ${data['message']}", isError: true);
          }
        } catch (jsonError) {
          _showSnackBar("Error: Respons server tidak valid. Response: ${response.body}", isError: true);
        }
      } else {
        _showSnackBar("HTTP Error: ${response.statusCode}", isError: true);
      }
    } catch (e) {
      if (!mounted) return;
      _showSnackBar("Terjadi kesalahan: $e", isError: true);
    } finally {
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  void _showSnackBar(String message, {bool isError = false}) {
    if (!mounted) return;
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.red[600] : Colors.green[600],
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        duration: Duration(seconds: isError ? 4 : 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text("Tambah Barang", style: TextStyle(fontWeight: FontWeight.bold)),
        backgroundColor: Colors.blue[600],
        foregroundColor: Colors.white,
        elevation: 0,
      ),
      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Card(
                elevation: 2,
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                child: Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.inventory_2, color: Colors.blue[600], size: 24),
                          const SizedBox(width: 8),
                          const Text(
                            "Informasi Barang",
                            style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                          ),
                        ],
                      ),
                      const SizedBox(height: 4),
                      Text(
                        "Lengkapi form di bawah untuk menambahkan barang baru",
                        style: TextStyle(color: Colors.grey[600], fontSize: 14),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              
              _buildTextField("Nama Barang", namaController, isRequired: true),
              _buildTextField("Kode Barang", kodeController, isRequired: true),
              _buildTextField("Harga", hargaController, isNumber: true),
              _buildTextField("Stok", stokController, isNumber: true, hint: "Jumlah stok barang"),
              _buildTextField("Satuan", satuanController),
              _buildTextField("Lokasi", lokasiController),
              _buildTextField("Tanggal Pembelian", tanggalController, hint: "YYYY-MM-DD"),
              _buildTextField("Material", materialController),
              _buildTextField("Tahun", tahunController, isNumber: true),
              _buildTextField("Merk", merkController),
              _buildTextField("Kondisi", kondisiController),
              _buildTextField("ID Kategori", idKategoriController, isNumber: true),
              
              const SizedBox(height: 24),
              
              SizedBox(
                height: 50,
                child: ElevatedButton(
                  onPressed: _isLoading ? null : tambahBarang,
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.blue[600],
                    foregroundColor: Colors.white,
                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                    elevation: 2,
                  ),
                  child: _isLoading
                      ? const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            SizedBox(
                              width: 20,
                              height: 20,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                              ),
                            ),
                            SizedBox(width: 12),
                            Text("Menyimpan..."),
                          ],
                        )
                      : const Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            Icon(Icons.save),
                            SizedBox(width: 8),
                            Text("Simpan Barang", style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
                          ],
                        ),
                ),
              ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildTextField(
    String label, 
    TextEditingController controller, {
    bool isNumber = false,
    bool isRequired = false,
    String? hint,
  }) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 16),
      child: TextFormField(
        controller: controller,
        keyboardType: isNumber ? TextInputType.number : TextInputType.text,
        validator: isRequired ? (value) {
          if (value == null || value.trim().isEmpty) {
            return '$label wajib diisi';
          }
          return null;
        } : null,
        decoration: InputDecoration(
          labelText: label,
          hintText: hint,
          border: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
          ),
          enabledBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.grey[300]!),
          ),
          focusedBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: BorderSide(color: Colors.blue[600]!, width: 2),
          ),
          errorBorder: OutlineInputBorder(
            borderRadius: BorderRadius.circular(12),
            borderSide: const BorderSide(color: Colors.red, width: 2),
          ),
          filled: true,
          fillColor: Colors.white,
          contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
      ),
    );
  }
}
