import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;

class EditRuanganPage extends StatefulWidget {
  final Map<String, dynamic> ruangan;

  const EditRuanganPage({Key? key, required this.ruangan}) : super(key: key);

  @override
  _EditRuanganPageState createState() => _EditRuanganPageState();
}

class _EditRuanganPageState extends State<EditRuanganPage> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController _namaRuanganController = TextEditingController();
  TextEditingController _deskripsiController = TextEditingController();
  TextEditingController _tanggalController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _namaRuanganController.text = widget.ruangan['nama_ruangan'];
    _deskripsiController.text = widget.ruangan['deskripsi'];
    _tanggalController.text = widget.ruangan['tanggal'];
  }

  // Fungsi untuk menyimpan perubahan
  Future<void> _saveChanges() async {
    if (_formKey.currentState!.validate()) {
      // Ambil nilai input dari form
      String namaRuangan = _namaRuanganController.text;
      String deskripsi = _deskripsiController.text;
      String tanggal = _tanggalController.text;

      // Log data yang akan dikirim
      print('Data yang dikirim: ${{
        'id_ruangan': widget.ruangan['id_ruangan'],
        'nama_ruangan': namaRuangan,
        'deskripsi': deskripsi,
        'tanggal': tanggal,
      }}');

      try {
        // Kirim data ke API untuk update
        final response = await http.post(
          Uri.parse('http://localhost/api_inventory/update_ruangan.php'),
          body: {
            'id_ruangan': widget.ruangan['id_ruangan'].toString(),
            'nama_ruangan': namaRuangan,
            'deskripsi': deskripsi,
            'tanggal': tanggal,
          },
        );

        final data = json.decode(response.body);
        if (data['success'] == true) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Data berhasil diperbarui')),
          );
          Navigator.pop(context); // Kembali ke halaman sebelumnya setelah berhasil
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text(data['message'] ?? 'Gagal memperbarui')),
          );
        }
      } catch (e) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Terjadi kesalahan saat menghubungi server')),
        );
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Ruangan'),
        backgroundColor: Colors.indigo[400],
        elevation: 0,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              TextFormField(
                controller: _namaRuanganController,
                decoration: const InputDecoration(labelText: 'Nama Ruangan'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Nama Ruangan tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _deskripsiController,
                decoration: const InputDecoration(labelText: 'Deskripsi'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Deskripsi tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _tanggalController,
                decoration: const InputDecoration(labelText: 'Tanggal Ditambahkan'),
                validator: (value) {
                  if (value == null || value.isEmpty) {
                    return 'Tanggal tidak boleh kosong';
                  }
                  return null;
                },
              ),
              const SizedBox(height: 20),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  ElevatedButton(
                    onPressed: _saveChanges,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.blue,
                    ),
                    child: const Text('Simpan Perubahan'),
                  ),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.pop(context); // Kembali tanpa perubahan
                    },
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.grey,
                    ),
                    child: const Text('Batal'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
