import 'dart:convert';
import 'dart:io'; // Keep this for potential non-web platforms, but handle web separately for file ops
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:file_picker/file_picker.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:printing/printing.dart';
import 'package:intl/intl.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/foundation.dart' show kIsWeb; // Import for platform detection
// import 'package:aplikasi_inventoryaset/pages/background_wrapper.dart'; // Removed this import as it's no longer used for image background

class DaftarRuanganPage extends StatefulWidget {
  const DaftarRuanganPage({super.key});

  @override
  State<DaftarRuanganPage> createState() => _DaftarRuanganPageState();
}

class _DaftarRuanganPageState extends State<DaftarRuanganPage> with TickerProviderStateMixin {
  List<dynamic> ruanganList = [];
  List<dynamic> filteredList = [];
  String? selectedDeskripsi;
  String? selectedTanggal;
  bool isLoading = true;
  bool isFilterExpanded = false;
  String searchQuery = '';
  final TextEditingController _searchController = TextEditingController();
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  // Controllers for adding and editing new ruangan
  final TextEditingController _namaRuanganController = TextEditingController();
  final TextEditingController _deskripsiController = TextEditingController();
  final TextEditingController _kapasitasController = TextEditingController();
  final TextEditingController _fasilitasController = TextEditingController();
  final TextEditingController _lokasiController = TextEditingController();

  // Form key for validation
  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 300),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeInOut),
    );
    fetchRuangan();
  }

  @override
  void dispose() {
    _searchController.dispose();
    _animationController.dispose();
    _namaRuanganController.dispose();
    _deskripsiController.dispose();
    _kapasitasController.dispose();
    _fasilitasController.dispose();
    _lokasiController.dispose();
    super.dispose();
  }

  Future<void> fetchRuangan() async {
    setState(() {
      isLoading = true;
    });
    try {
      final response = await http.get(
        Uri.parse('http://localhost/api_inventory/get_ruangan.php'),
      );
      if (!mounted) return; // Check if widget is still mounted
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          setState(() {
            ruanganList = List<Map<String, dynamic>>.from(data['ruangan'] ?? []);
            filteredList = ruanganList;
            isLoading = false;
          });
          _animationController.forward();
        } else {
          setState(() {
            isLoading = false;
          });
          _showSnackBar(data['message'] ?? 'Gagal mengambil data ruangan', Colors.red);
        }
      } else {
        setState(() {
          isLoading = false;
        });
        _showSnackBar('Server error: ${response.statusCode}', Colors.red);
      }
    } catch (e) {
      setState(() {
        isLoading = false;
      });
      _showSnackBar('Error: $e', Colors.red);
    }
  }

  Future<List<dynamic>> fetchItemsByRoom(String idRuangan) async {
    try {
      final response = await http.get(
        Uri.parse('http://localhost/api_inventory/get_items_by_room.php?id_ruangan=$idRuangan'),
      );
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          return data['items'] ?? [];
        } else {
          debugPrint('Failed to load items: ${data['message']}');
          return [];
        }
      } else {
        debugPrint('Server error fetching items: ${response.statusCode}');
        return [];
      }
    } catch (e) {
      debugPrint('Error fetching items: $e');
      return [];
    }
  }

  void _applySearch() {
    setState(() {
      filteredList = ruanganList.where((item) {
        final matchesSearch = searchQuery.isEmpty ||
            item['nama_ruangan'].toString().toLowerCase().contains(searchQuery.toLowerCase()) ||
            item['deskripsi'].toString().toLowerCase().contains(searchQuery.toLowerCase()) ||
            (item['lokasi']?.toString().toLowerCase().contains(searchQuery.toLowerCase()) ?? false);
        final matchesDeskripsi = selectedDeskripsi == null ||
            item['deskripsi']?.toString() == selectedDeskripsi;
        final matchesTanggal = selectedTanggal == null ||
            item['tanggal_dibuat']?.toString() == selectedTanggal ||
            item['created_at']?.toString() == selectedTanggal ||
            item['tanggal']?.toString() == selectedTanggal;
        return matchesSearch && matchesDeskripsi && matchesTanggal;
      }).toList();
    });
  }

  void _resetFilter() {
    setState(() {
      selectedDeskripsi = null;
      selectedTanggal = null;
      searchQuery = '';
      _searchController.clear();
      filteredList = ruanganList;
    });
  }

  void _editRuangan(Map<String, dynamic> item) {
    // Pre-fill controllers with existing data
    _namaRuanganController.text = item['nama_ruangan']?.toString() ?? '';
    _deskripsiController.text = item['deskripsi']?.toString() ?? '';
    _kapasitasController.text = item['kapasitas']?.toString() ?? '';
    _fasilitasController.text = item['fasilitas']?.toString() ?? '';
    _lokasiController.text = item['lokasi']?.toString() ?? '';

    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: const Text('Edit Ruangan', style: TextStyle(fontWeight: FontWeight.bold)),
        content: SingleChildScrollView(
          child: Form( // Wrap with Form for validation
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildTextField(_namaRuanganController, 'Nama Ruangan', Icons.business, validator: (value) => value!.isEmpty ? 'Nama Ruangan tidak boleh kosong' : null),
                const SizedBox(height: 12),
                _buildTextField(_deskripsiController, 'Deskripsi', Icons.description, validator: (value) => value!.isEmpty ? 'Deskripsi tidak boleh kosong' : null),
                const SizedBox(height: 12),
                _buildTextField(_kapasitasController, 'Kapasitas', Icons.people, isNumber: true, validator: (value) => value!.isEmpty ? 'Kapasitas tidak boleh kosong' : null),
                const SizedBox(height: 12),
                _buildTextField(_fasilitasController, 'Fasilitas (pisahkan dengan koma)', Icons.extension),
                const SizedBox(height: 12),
                _buildTextField(_lokasiController, 'Lokasi', Icons.location_on, validator: (value) => value!.isEmpty ? 'Lokasi tidak boleh kosong' : null),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) { // Validate form
                Navigator.of(ctx).pop(); // Close the dialog
                await _submitEditRuangan(item['id_ruangan'].toString());
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue[600]),
            child: const Text('Simpan', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Future<void> _submitEditRuangan(String idRuangan) async {
    final String namaRuangan = _namaRuanganController.text;
    final String deskripsi = _deskripsiController.text;
    final String kapasitas = _kapasitasController.text;
    final String fasilitas = _fasilitasController.text;
    final String lokasi = _lokasiController.text;

    _showLoadingDialog('Memperbarui ruangan...');
    try {
      final response = await http.post(
        Uri.parse('http://localhost/api_inventory/update_ruangan.php'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'id_ruangan': idRuangan,
          'nama_ruangan': namaRuangan,
          'deskripsi': deskripsi,
          'kapasitas': kapasitas,
          'fasilitas': fasilitas,
          'lokasi': lokasi,
        },
      );
      if (!mounted) return; // Check if widget is still mounted
      Navigator.pop(context); // Close loading dialog
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          _showSnackBar('Ruangan "$namaRuangan" berhasil diperbarui', Colors.green);
          await fetchRuangan(); // Refresh data
        } else {
          _showSnackBar(data['message'] ?? 'Gagal memperbarui ruangan', Colors.red);
        }
      } else {
        _showSnackBar('Server error: ${response.statusCode}', Colors.red);
      }
    } catch (e) {
      if (!mounted) return; // Check if widget is still mounted
      Navigator.pop(context); // Close loading dialog
      _showSnackBar('Error: $e', Colors.red);
    }
  }

  void _confirmDelete(String id, String namaRuangan) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: Row(
          children: [
            Icon(Icons.warning, color: Colors.orange[600]),
            const SizedBox(width: 10),
            const Text('Konfirmasi Hapus'),
          ],
        ),
        content: Text('Apakah Anda yakin ingin menghapus ruangan "$namaRuangan"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () {
              Navigator.of(ctx).pop();
              _deleteRuangan(id, namaRuangan);
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
            child: const Text('Hapus', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Future<void> _deleteRuangan(String id, String namaRuangan) async {
    try {
      _showLoadingDialog('Menghapus ruangan...');
      final response = await http.post(
        Uri.parse('http://localhost/api_inventory/delete_ruangan.php'),
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {'id_ruangan': id},
      );
      if (!mounted) return; // Check if widget is still mounted
      Navigator.pop(context); // Close loading dialog
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          _showSnackBar('Ruangan "$namaRuangan" berhasil dihapus', Colors.green);
          await fetchRuangan(); // Refresh data
        } else {
          _showSnackBar(data['message'] ?? 'Gagal menghapus ruangan', Colors.red);
        }
      } else {
        _showSnackBar('Server error: ${response.statusCode}', Colors.red);
      }
    } catch (e) {
      if (!mounted) return; // Check if widget is still mounted
      Navigator.pop(context); // Close loading dialog
      _showSnackBar('Error: $e', Colors.red);
    }
  }

  Future<void> _printData() async {
    try {
      _showLoadingDialog('Menyiapkan dokumen...');
      final pdf = pw.Document();
      pdf.addPage(
        pw.Page(
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            return pw.Column(
              crossAxisAlignment: pw.CrossAxisAlignment.start,
              children: [
                pw.Header(
                  level: 0,
                  child: pw.Text('Daftar Ruangan',
                      style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
                ),
                pw.Text('Tanggal Cetak: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}',
                    style: const pw.TextStyle(fontSize: 12)),
                pw.SizedBox(height: 20),
                pw.Table.fromTextArray(
                  headers: ['Nama Ruangan', 'Deskripsi', 'Kapasitas', 'Tanggal'],
                  data: filteredList.map((item) => [
                    item['nama_ruangan']?.toString() ?? '-',
                    item['deskripsi']?.toString() ?? '-',
                    item['kapasitas']?.toString() ?? '-',
                    item['tanggal_dibuat']?.toString() ?? item['created_at']?.toString() ?? item['tanggal']?.toString() ?? '-'
                  ]).toList(),
                ),
              ],
            );
          },
        ),
      );
      if (!mounted) return; // Check if widget is still mounted
      Navigator.pop(context); // Close loading dialog
      await Printing.layoutPdf(
        onLayout: (PdfPageFormat format) async => pdf.save(),
        name: 'daftar_ruangan_${DateFormat('yyyyMMdd').format(DateTime.now())}.pdf',
      );
    } catch (e) {
      if (!mounted) return; // Check if widget is still mounted
      Navigator.pop(context);
      _showSnackBar('Error print: $e', Colors.red);
    }
  }

  // --- START: PDF Export Function (Modified for Web Compatibility) ---
  Future<void> _exportDataToPdf() async {
    try {
      _showLoadingDialog('Menyiapkan dokumen ekspor...');
      final pdf = pw.Document();
      pdf.addPage(
        pw.MultiPage( // Use MultiPage for content that might span multiple pages
          pageFormat: PdfPageFormat.a4,
          build: (pw.Context context) {
            return [
              pw.Header(
                level: 0,
                child: pw.Text('Data Ruangan',
                    style: pw.TextStyle(fontSize: 24, fontWeight: pw.FontWeight.bold)),
              ),
              pw.Text('Tanggal Export: ${DateFormat('dd/MM/yyyy HH:mm').format(DateTime.now())}',
                  style: const pw.TextStyle(fontSize: 12)),
              pw.SizedBox(height: 20),
              pw.Table.fromTextArray(
                headers: ['ID', 'Nama Ruangan', 'Deskripsi', 'Kapasitas', 'Fasilitas', 'Lokasi', 'Tanggal Dibuat'],
                data: filteredList.map((item) => [
                  item['id_ruangan']?.toString() ?? '-',
                  item['nama_ruangan']?.toString() ?? '-',
                  item['deskripsi']?.toString() ?? '-',
                  item['kapasitas']?.toString() ?? '-',
                  item['fasilitas']?.toString() ?? '-',
                  item['lokasi']?.toString() ?? '-',
                  item['tanggal_dibuat']?.toString() ?? item['created_at']?.toString() ?? item['tanggal']?.toString() ?? '-'
                ]).toList(),
              ),
            ];
          },
        ),
      );
      if (!mounted) return; // Check if widget is still mounted
      Navigator.pop(context); // Close loading dialog
      // Handle PDF saving differently for web and other platforms
      if (kIsWeb) {
        // For web, use Printing.sharePdf or just open a new tab with the PDF
        await Printing.sharePdf(bytes: await pdf.save(), filename: 'data_ruangan_${DateFormat('yyyyMMdd').format(DateTime.now())}.pdf');
      } else {
        // For mobile/desktop, use file_picker to save
        final directory = await FilePicker.platform.getDirectoryPath();
        if (directory != null) {
          final file = File('$directory/data_ruangan_${DateFormat('yyyyMMdd').format(DateTime.now())}.pdf');
          await file.writeAsBytes(await pdf.save());
          _showSnackBar('PDF berhasil diekspor ke $directory', Colors.green);
        } else {
          _showSnackBar('Penyimpanan dibatalkan.', Colors.orange);
        }
      }
    } catch (e) {
      if (!mounted) return; // Check if widget is still mounted
      Navigator.pop(context);
      if (kIsWeb && e.toString().contains('UnimplementedError')) {
           _showSnackBar('Fitur export ke file lokal tidak didukung di Web. Gunakan tombol Print/Share.', Colors.red);
      } else {
           _showSnackBar('Error export: $e', Colors.red);
      }
    }
  }
  // --- END: PDF Export Function (Modified for Web Compatibility) ---

  void _showLoadingDialog(String message) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          content: Row(
            children: [
              const CircularProgressIndicator(),
              const SizedBox(width: 20),
              Text(message),
            ],
          ),
        );
      },
    );
  }

  void _showSnackBar(String message, Color color) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: color,
        duration: const Duration(seconds: 3),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
      ),
    );
  }

  List<String> _getUniqueList(String field) {
    final set = <String>{};
    for (var item in ruanganList) {
      String? value;
      // Handle different possible field names from database
      switch (field) {
        case 'deskripsi':
          value = item['deskripsi']?.toString();
          break;
        case 'tanggal':
          value = item['tanggal_dibuat']?.toString() ??
              item['created_at']?.toString() ??
              item['tanggal']?.toString();
          break;
        case 'status':
          value = item['status']?.toString();
          break;
        case 'lokasi':
          value = item['lokasi']?.toString();
          break;
        default:
          value = item[field]?.toString();
      }
      if (value != null && value.isNotEmpty) {
        set.add(value);
      }
    }
    return set.toList();
  }

  // Function to add a room (already implemented from previous request)
  Future<void> _addRuangan() async {
    _namaRuanganController.clear();
    _deskripsiController.clear();
    _kapasitasController.clear();
    _fasilitasController.clear();
    _lokasiController.clear();
    setState(() {
      _formKey.currentState?.reset(); // Reset form state for new entry
    });

    await showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
        title: const Text('Tambah Ruangan Baru', style: TextStyle(fontWeight: FontWeight.bold)),
        content: SingleChildScrollView(
          child: Form( // Wrap with Form for validation
            key: _formKey,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _buildTextField(_namaRuanganController, 'Nama Ruangan', Icons.business, validator: (value) => value!.isEmpty ? 'Nama Ruangan tidak boleh kosong' : null),
                const SizedBox(height: 12),
                _buildTextField(_deskripsiController, 'Deskripsi', Icons.description, validator: (value) => value!.isEmpty ? 'Deskripsi tidak boleh kosong' : null),
                const SizedBox(height: 12),
                _buildTextField(_kapasitasController, 'Kapasitas', Icons.people, isNumber: true, validator: (value) => value!.isEmpty ? 'Kapasitas tidak boleh kosong' : null),
                const SizedBox(height: 12),
                _buildTextField(_fasilitasController, 'Fasilitas (pisahkan dengan koma)', Icons.extension),
                const SizedBox(height: 12),
                _buildTextField(_lokasiController, 'Lokasi', Icons.location_on, validator: (value) => value!.isEmpty ? 'Lokasi tidak boleh kosong' : null),
              ],
            ),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Batal'),
          ),
          ElevatedButton(
            onPressed: () async {
              if (_formKey.currentState!.validate()) { // Validate form
                Navigator.of(ctx).pop(); // Close the dialog
                await _submitAddRuangan();
              }
            },
            style: ElevatedButton.styleFrom(backgroundColor: Colors.blue[600]),
            child: const Text('Tambah', style: TextStyle(color: Colors.white)),
          ),
        ],
      ),
    );
  }

  Future<void> _submitAddRuangan() async {
    final String namaRuangan = _namaRuanganController.text;
    final String deskripsi = _deskripsiController.text;
    final String kapasitas = _kapasitasController.text;
    final String fasilitas = _fasilitasController.text;
    final String lokasi = _lokasiController.text;

    _showLoadingDialog('Menambahkan ruangan...');
    try {
      final response = await http.post(
        Uri.parse('http://localhost/api_inventory/add_ruangan.php'), // Assuming this endpoint exists
        headers: {'Content-Type': 'application/x-www-form-urlencoded'},
        body: {
          'nama_ruangan': namaRuangan,
          'deskripsi': deskripsi,
          'kapasitas': kapasitas,
          'fasilitas': fasilitas,
          'lokasi': lokasi,
        },
      );
      if (!mounted) return; // Check if widget is still mounted
      Navigator.pop(context); // Close loading dialog
      if (response.statusCode == 200) {
        final data = json.decode(response.body);
        if (data['success'] == true) {
          _showSnackBar('Ruangan "$namaRuangan" berhasil ditambahkan', Colors.green);
          await fetchRuangan(); // Refresh data
        } else {
          _showSnackBar(data['message'] ?? 'Gagal menambahkan ruangan', Colors.red);
        }
      } else {
        _showSnackBar('Server error: ${response.statusCode}', Colors.red);
      }
    } catch (e) {
      if (!mounted) return; // Check if widget is still mounted
      Navigator.pop(context); // Close loading dialog
      _showSnackBar('Error: $e', Colors.red);
    }
  }

  // New function to show room details including items
  Future<void> _showDetailRuanganDialog(Map<String, dynamic> ruangan) async {
    _showLoadingDialog('Mengambil detail ruangan...');
    final List<dynamic> itemsInRoom = await fetchItemsByRoom(ruangan['id_ruangan'].toString());
    if (!mounted) return; // Check if widget is still mounted
    Navigator.pop(context); // Close loading dialog

    showDialog(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Row(
            children: [
              const Icon(Icons.info, color: Colors.blue),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  'Detail Ruangan: ${ruangan['nama_ruangan'] ?? '-'}',
                  style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _buildDetailRow('Nama Ruangan', ruangan['nama_ruangan']),
                _buildDetailRow('Deskripsi', ruangan['deskripsi']),
                _buildDetailRow('Kapasitas', ruangan['kapasitas']?.toString()),
                _buildDetailRow('Lokasi', ruangan['lokasi']),
                _buildDetailRow('Fasilitas', ruangan['fasilitas']),
                _buildDetailRow('Tanggal Dibuat', ruangan['tanggal_dibuat'] ?? ruangan['created_at'] ?? ruangan['tanggal']),
                const SizedBox(height: 16),
                const Text('Barang di Ruangan Ini:', style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
                const SizedBox(height: 8),
                if (itemsInRoom.isNotEmpty)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: itemsInRoom.map<Widget>((item) => Padding(
                      padding: const EdgeInsets.only(bottom: 4),
                      child: Text('• ${item['nama_barang']} (Jumlah: ${item['jumlah'] ?? 'N/A'})'),
                    )).toList(),
                  )
                else
                  const Text('Tidak ada barang di ruangan ini.', style: TextStyle(color: Colors.grey)),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(dialogContext),
              child: const Text('Tutup'),
            ),
          ],
        );
      },
    );
  }

  Widget _buildDetailRow(String label, String? value) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              '$label:',
              style: const TextStyle(fontWeight: FontWeight.w500),
            ),
          ),
          Expanded(
            child: Text(value ?? '-'),
          ),
        ],
      ),
    );
  }

  Widget _buildTextField(TextEditingController controller, String label, IconData icon, {bool isNumber = false, int maxLines = 1, String? Function(String?)? validator}) {
    return TextFormField(
      controller: controller,
      keyboardType: isNumber ? TextInputType.number : TextInputType.text,
      maxLines: maxLines,
      decoration: InputDecoration(
        labelText: label,
        prefixIcon: Icon(icon, color: Colors.blue),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: const BorderSide(color: Colors.blue, width: 2),
        ),
      ),
      validator: validator, // Add validator
    );
  }

  Widget _buildDropdownField(String label, String? value, List<String> options, void Function(String?) onChanged, {String? Function(String?)? validator}) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey.shade300),
        borderRadius: BorderRadius.circular(8),
      ),
      padding: const EdgeInsets.symmetric(horizontal: 12),
      child: DropdownButtonHideUnderline(
        child: DropdownButtonFormField<String>( // Changed to DropdownButtonFormField
          value: value,
          hint: Text("Pilih $label"),
          isExpanded: true,
          onChanged: onChanged,
          items: options.map<DropdownMenuItem<String>>((String option) {
            return DropdownMenuItem<String>(
              value: option,
              child: Text(option),
            );
          }).toList(),
          validator: validator, // Add validator
        ),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: Container(
        color: Colors.grey[50],
        child: Column(
          children: [
            // Header
            Container(
              height: 120,
              width: double.infinity,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [Colors.blue[700]!, Colors.blue[500]!],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      const Text(
                        'INVENTRIS',
                        style: TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1.2,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        'Sistem Manajemen Inventaris',
                        style: TextStyle(
                          color: Colors.white.withOpacity(0.9),
                          fontSize: 12,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            // Menu Items
            Expanded(
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 8),
                children: [
                  _buildMenuSection('DASHBOARD'),
                  _buildMenuItem(
                    icon: Icons.dashboard_outlined,
                    title: 'Dashboard',
                    onTap: () => Navigator.pushReplacementNamed(context, '/dashboard'),
                  ),
                  const SizedBox(height: 16),
                  _buildMenuSection('MANAJEMEN'),
                  _buildMenuItem(
                    icon: Icons.inventory_2_outlined,
                    title: 'Data Barang',
                    onTap: () => Navigator.pushReplacementNamed(context, '/daftar-barang'),
                  ),
                  _buildMenuItem(
                    icon: Icons.build_outlined,
                    title: 'Daftar Perolehan',
                    onTap: () => Navigator.pushReplacementNamed(context, '/daftar-perolehan'),
                  ),
                  _buildMenuItem(
                    icon: Icons.meeting_room_outlined,
                    title: 'Data Ruangan',
                    isActive: true,
                    onTap: () => Navigator.pop(context),
                  ),
                  _buildMenuItem(
                    icon: Icons.people_outline,
                    title: 'Data Pengguna',
                    onTap: () => Navigator.pushReplacementNamed(context, '/daftar-pengguna'),
                  ),
                  const SizedBox(height: 16),
                  _buildMenuSection('PENGATURAN'),
                  _buildMenuItem(
                    icon: Icons.person_outline,
                    title: 'Pengaturan Profil',
                    onTap: () => Navigator.pushReplacementNamed(context, '/pengaturan-profile'),
                  ),
                  _buildMenuItem(
                    icon: Icons.admin_panel_settings_outlined,
                    title: 'Peran & Hak Akses',
                    onTap: () => Navigator.pushReplacementNamed(context, '/peran-hak-askes'),
                  ),
                ],
              ),
            ),
            // Logout Button
            Container(
              padding: const EdgeInsets.all(16),
              child: SizedBox(
                width: double.infinity,
                child: ElevatedButton.icon(
                  onPressed: () async {
                    bool? shouldLogout = await showDialog<bool>(
                      context: context,
                      builder: (BuildContext context) {
                        return AlertDialog(
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
                          title: const Text('Konfirmasi Logout'),
                          content: const Text('Apakah Anda yakin ingin keluar?'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.of(context).pop(false),
                              child: const Text('Batal'),
                            ),
                            ElevatedButton(
                              onPressed: () => Navigator.of(context).pop(true),
                              style: ElevatedButton.styleFrom(backgroundColor: Colors.red),
                              child: const Text('Ya, Keluar', style: TextStyle(color: Colors.white)),
                            ),
                          ],
                        );
                      },
                    );
                    if (shouldLogout == true) {
                      SharedPreferences prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (mounted) {
                        Navigator.pushReplacementNamed(context, '/');
                      }
                    }
                  },
                  icon: const Icon(Icons.logout, color: Colors.white),
                  label: const Text(
                    'Logout',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.red[600],
                    padding: const EdgeInsets.symmetric(vertical: 12),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(8),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMenuSection(String title) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 8, 16, 4),
      child: Text(
        title,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w600,
          color: Colors.grey[600],
          letterSpacing: 0.5,
        ),
      ),
    );
  }

  Widget _buildMenuItem({
    required IconData icon,
    required String title,
    required VoidCallback onTap,
    bool isActive = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      child: ListTile(
        leading: Icon(
          icon,
          color: isActive ? Colors.blue[600] : Colors.grey[600],
          size: 22,
        ),
        title: Text(
          title,
          style: TextStyle(
            color: isActive ? Colors.blue[600] : Colors.grey[700],
            fontWeight: isActive ? FontWeight.w600 : FontWeight.normal,
            fontSize: 14,
          ),
        ),
        onTap: onTap,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(8),
        ),
        tileColor: isActive ? Colors.blue[50] : null,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      ),
    );
  }

  Widget _buildToolbar() {
    return Card(
      elevation: 2,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // Search Bar
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Cari ruangan...',
                prefixIcon: const Icon(Icons.search),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(8),
                  borderSide: BorderSide.none,
                ),
                filled: true,
                fillColor: Colors.grey[100],
                contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              ),
              onChanged: (value) {
                setState(() {
                  searchQuery = value;
                });
                _applySearch();
              },
            ),
            const SizedBox(height: 16),
            // Action Buttons (Print and Export)
            LayoutBuilder(
              builder: (context, constraints) {
                if (constraints.maxWidth < 450) {
                  return Column(
                    children: [
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _printData,
                          icon: const Icon(Icons.print, color: Colors.white),
                          label: const Text('Print', style: TextStyle(color: Colors.white)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey[700],
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                        ),
                      ),
                      const SizedBox(height: 12),
                      SizedBox(
                        width: double.infinity,
                        child: ElevatedButton.icon(
                          onPressed: _exportDataToPdf, // Call the new export function
                          icon: const Icon(Icons.download, color: Colors.white),
                          label: const Text('Export', style: TextStyle(color: Colors.white)),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal[600], // Warna untuk Export
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                        ),
                      ),
                    ],
                  );
                } else {
                  return Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _printData,
                          icon: const Icon(Icons.print),
                          label: const Text('Print'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.grey[700],
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                        ),
                      ),
                      const SizedBox(width: 12), // Spasi antara tombol
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: _exportDataToPdf, // Call the new export function
                          icon: const Icon(Icons.download),
                          label: const Text('Export'),
                          style: ElevatedButton.styleFrom(
                            backgroundColor: Colors.teal[600], // Warna untuk Export
                            foregroundColor: Colors.white,
                            padding: const EdgeInsets.symmetric(vertical: 12),
                            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                          ),
                        ),
                      ),
                    ],
                  );
                }
              },
            ),
            const SizedBox(height: 16),
            // Filter Toggle
            InkWell(
              onTap: () {
                setState(() {
                  isFilterExpanded = !isFilterExpanded;
                });
              },
              child: Container(
                width: double.infinity, // Ensure it takes full width
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.blue[600],
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Icon(Icons.filter_list, color: Colors.white),
                    const SizedBox(width: 8),
                    const Expanded(
                      child: Text(
                        'Filter Data',
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    Icon(
                      isFilterExpanded ? Icons.expand_less : Icons.expand_more,
                      color: Colors.white,
                    ),
                  ],
                ),
              ),
            ),
            // Filter Options
            AnimatedContainer(
              duration: const Duration(milliseconds: 300),
              height: isFilterExpanded ? null : 0,
              curve: Curves.easeInOut,
              child: isFilterExpanded ? Padding(
                padding: const EdgeInsets.only(top: 16), // Add padding here
                child: Column(
                  children: [
                    LayoutBuilder(
                      builder: (context, constraints) {
                        if (constraints.maxWidth < 450) {
                          return Column(
                            children: [
                              _buildDropdownField(
                                "Filter Deskripsi",
                                selectedDeskripsi,
                                _getUniqueList('deskripsi'),
                                (val) {
                                  setState(() {
                                    selectedDeskripsi = val;
                                  });
                                  _applySearch();
                                },
                              ),
                              const SizedBox(height: 12),
                              _buildDropdownField(
                                "Filter Tanggal",
                                selectedTanggal,
                                _getUniqueList('tanggal'),
                                (val) {
                                  setState(() {
                                    selectedTanggal = val;
                                  });
                                  _applySearch();
                                },
                              ),
                            ],
                          );
                        } else {
                          return Row(
                            children: [
                              Expanded(
                                child: _buildDropdownField(
                                  "Filter Deskripsi",
                                  selectedDeskripsi,
                                  _getUniqueList('deskripsi'),
                                  (val) {
                                    setState(() {
                                      selectedDeskripsi = val;
                                    });
                                    _applySearch();
                                  },
                                ),
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: _buildDropdownField(
                                  "Filter Tanggal",
                                  selectedTanggal,
                                  _getUniqueList('tanggal'),
                                  (val) {
                                    setState(() {
                                      selectedTanggal = val;
                                    });
                                    _applySearch();
                                  },
                                ),
                              ),
                            ],
                          );
                        }
                      },
                    ),
                    const SizedBox(height: 12),
                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        onPressed: _resetFilter,
                        icon: const Icon(Icons.clear, color: Colors.white),
                        label: const Text('Reset Filter', style: TextStyle(color: Colors.white)),
                        style: ElevatedButton.styleFrom(
                          backgroundColor: Colors.orange[600],
                          padding: const EdgeInsets.symmetric(vertical: 12),
                          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
                        ),
                      ),
                    ),
                  ],
                ),
              ) : null,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRuanganCard(Map<String, dynamic> item) {
    return Card(
      elevation: 2,
      margin: const EdgeInsets.only(bottom: 12),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Container(
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: Colors.blue[100],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Icon(Icons.meeting_room, color: Colors.blue[600]),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        item['nama_ruangan']?.toString() ?? '-',
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        item['deskripsi']?.toString() ?? '-',
                        style: TextStyle(
                          fontSize: 14,
                          color: Colors.grey[600],
                        ),
                      ),
                    ],
                  ),
                ),
                // Action buttons for each card
                PopupMenuButton<String>(
                  onSelected: (value) {
                    if (value == 'detail') {
                      _showDetailRuanganDialog(item);
                    } else if (value == 'edit') {
                      _editRuangan(item);
                    } else if (value == 'delete') {
                      _confirmDelete(
                        item['id_ruangan']?.toString() ?? '',
                        item['nama_ruangan']?.toString() ?? 'Ruangan',
                      );
                    }
                  },
                  itemBuilder: (context) => [
                    const PopupMenuItem(
                      value: 'detail',
                      child: Row(
                        children: [
                          Icon(Icons.visibility, color: Colors.green),
                          SizedBox(width: 8),
                          Text('Lihat Detail'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'edit',
                      child: Row(
                        children: [
                          Icon(Icons.edit, color: Colors.blue),
                          SizedBox(width: 8),
                          Text('Edit'),
                        ],
                      ),
                    ),
                    const PopupMenuItem(
                      value: 'delete',
                      child: Row(
                        children: [
                          Icon(Icons.delete, color: Colors.red),
                          SizedBox(width: 8),
                          Text('Hapus'),
                        ],
                      ),
                    ),
                  ],
                ),
              ],
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                if (item['kapasitas'] != null)
                  _buildInfoChip(Icons.people, 'Kapasitas: ${item['kapasitas']}'),
                if (item['tanggal_dibuat'] != null || item['created_at'] != null)
                  _buildInfoChip(
                    Icons.calendar_today,
                    'Dibuat: ${item['tanggal_dibuat'] ?? item['created_at'] ?? item['tanggal'] ?? '-'}'
                  ),
                if (item['lokasi'] != null)
                  _buildInfoChip(Icons.location_on, 'Lokasi: ${item['lokasi']}'),
                if (item['status'] != null)
                  _buildInfoChip(
                    Icons.info,
                    'Status: ${item['status']}',
                    color: item['status'] == 'Aktif' ? Colors.green : Colors.orange,
                  ),
              ],
            ),
            if (item['fasilitas'] != null && item['fasilitas']
                .toString()
                .isNotEmpty) ...[
              const SizedBox(height: 12),
              const Divider(height: 1, thickness: 1),
              const SizedBox(height: 12),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Fasilitas:',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.bold,
                      color: Colors.grey[700],
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    item['fasilitas']?.toString() ?? '-',
                    style: TextStyle(
                      fontSize: 14,
                      color: Colors.grey[600],
                    ),
                  ),
                ],
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildInfoChip(IconData icon, String text, {Color? color}) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color?.withOpacity(0.1) ?? Colors.grey[200],
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 16, color: color ?? Colors.grey[700]),
          const SizedBox(width: 6),
          Text(
            text,
            style: TextStyle(fontSize: 12, color: color ?? Colors.grey[800]),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent, // Set background to transparent
      drawer: _buildDrawer(),
      appBar: AppBar(
        title: const Text(
          'Daftar Ruangan',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
        backgroundColor: Colors.blue[700],
        elevation: 0, // Remove shadow for seamless background
        iconTheme: const IconThemeData(color: Colors.white),
      ),
      body: Stack( // Use Stack to layer the background image and content
        children: [
          Positioned.fill(
            child: Container(
              decoration: const BoxDecoration(
                image: DecorationImage(
                  image: AssetImage('assets/diskominfo.jpg'), // Path to your Diskominfo building image
                  fit: BoxFit.cover,
                ),
              ),
            ),
          ),
          SafeArea(
            child: Column(
              children: [
                Padding(
                  padding: const EdgeInsets.all(16.0),
                  child: _buildToolbar(),
                ),
                Expanded(
                  child: isLoading
                      ? const Center(child: CircularProgressIndicator())
                      : filteredList.isEmpty
                          ? Center(
                              child: FadeTransition(
                                opacity: _fadeAnimation,
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    Icon(
                                      Icons.meeting_room_outlined,
                                      size: 80,
                                      color: Colors.grey[400],
                                    ),
                                    const SizedBox(height: 16),
                                    Text(
                                      'Belum ada data ruangan.',
                                      style: TextStyle(
                                        fontSize: 18,
                                        color: Colors.grey[600],
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            )
                          : FadeTransition(
                              opacity: _fadeAnimation,
                              child: ListView.builder(
                                padding: const EdgeInsets.symmetric(horizontal: 16.0),
                                itemCount: filteredList.length,
                                itemBuilder: (context, index) {
                                  return _buildRuanganCard(filteredList[index]);
                                },
                              ),
                            ),
                ),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _addRuangan,
        icon: const Icon(Icons.add, color: Colors.white),
        label: const Text(
          'Tambah Ruangan',
          style: TextStyle(color: Colors.white),
        ),
        backgroundColor: Colors.green[600],
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
      ),
    );
  }
}
