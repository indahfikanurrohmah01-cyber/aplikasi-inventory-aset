import 'package:flutter/material.dart';

// Import semua halaman dari folder pages
import 'pages/login_page.dart';
import 'pages/register_page.dart';
import 'pages/dashboard_page.dart'; // Dashboard Admin
import 'pages/user_dashboard_page.dart'; // Dashboard Pengguna
import 'pages/daftar_barang_page.dart';
import 'pages/daftar_barang_user_page.dart';
import 'pages/daftar_ruangan_page.dart';
import 'pages/daftar_ruangan_user_page.dart';
import 'pages/edit_ruangan_page.dart';
import 'pages/edit_barang_page.dart';
import 'pages/daftar_pengguna_page.dart';
import 'pages/daftar_perolehan_page.dart';
import 'pages/pengaturan_profile.dart';
import 'pages/peran_hak_akses_page.dart';
import 'pages/laporan_saya_page.dart'; // Halaman laporan user
import 'pages/tambah_laporan.dart'; // Halaman tambah laporan
import 'pages/status_permintaan_page.dart'; // Halaman status permintaan
import 'pages/pengaturan_profile_user.dart';
import 'pages/admin_laporan_page.dart';
import 'pages/riwayat_pemakaian_page.dart.dart'; // ✅ Tambahkan import ini

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aplikasi Inventory Aset',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        primarySwatch: Colors.teal,
        useMaterial3: true,
      ),
      initialRoute: '/', // Awal ke Login Page
      routes: {
        '/': (context) => const LoginPage(),
        '/register': (context) => const RegisterPage(),
        '/dashboard': (context) => DashboardPage(),
        '/user-dashboard': (context) => const UserDashboardPage(),
        '/daftar-barang': (context) => const DaftarBarangPage(),
        '/daftar-barang-user': (context) => const DaftarBarangUserPage(),
        '/daftar-ruangan': (context) => const DaftarRuanganPage(),
        '/daftar-ruangan-user': (context) => const DaftarRuanganUserPage(),
        '/daftar-pengguna': (context) => const DaftarPenggunaPage(),
        '/daftar-perolehan': (context) => const DaftarPerolehanPage(),
        '/pengaturan-profile': (context) => const PengaturanProfilPage(),
        '/pengaturan-profile-user': (context) => const PengaturanProfilUserPage(),
        '/peran-hak-akses': (context) => const PeranHakAksesPage(),
        '/laporan-saya': (context) => const LaporanSayaPage(),
        '/tambah-laporan': (context) => const TambahLaporanPage(),
        '/riwayat-pemakaian': (context) => const RiwayatPemakaianPage(userId:'4',),
        '/admin-laporan': (context) => const AdminLaporanPage(userId:'1',),


        // Halaman status permintaan dengan userId sebagai argumen
        '/status-permintaan': (context) {
          final args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
          return StatusPermintaanPage(userId: args['userId']);
        },

        // Rute edit dengan parameter (barang & ruangan)
        '/edit-barang': (context) {
          final args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
          return EditBarangPage(barang: args);
        },
        '/edit-ruangan': (context) {
          final args = ModalRoute.of(context)!.settings.arguments as Map<String, dynamic>;
          return EditRuanganPage(ruangan: args);
        },
      },
    );
  }
}