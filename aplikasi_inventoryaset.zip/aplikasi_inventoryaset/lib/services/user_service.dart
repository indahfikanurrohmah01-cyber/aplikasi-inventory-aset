import 'dart:io';
class UserService {
  static Future<Map<String, dynamic>> getUserProfile(String userId) async {
    // Simulate API call
    await Future.delayed(const Duration(seconds: 1));
    
    // Mock response
    return {
      'success': true,
      'user': {
        'nama_lengkap': 'Administrator',
        'email': 'admin@gmail.com',
        'phone': '+62 812 3456 7890',
        'address': 'Jl. Contoh No. 123, Jakarta',
        'profile_image': null,
      }
    };
  }
  
  static Future<Map<String, dynamic>> updateUserProfile(Map<String, dynamic> data) async {
    // Simulate API call
    await Future.delayed(const Duration(seconds: 2));
    
    // Mock response
    return {
      'success': true,
      'message': 'Profil berhasil diperbarui'
    };
  }

  static Future<Map<String, dynamic>> uploadProfileImage(String userId, File imageFile) async {
    // Simulate API call for image upload
    await Future.delayed(const Duration(seconds: 2));
    
    // In a real implementation, you would:
    // 1. Convert image to multipart form data
    // 2. Send POST request to your upload endpoint
    // 3. Return the uploaded image URL
    
    // Mock response
    return {
      'success': true,
      'message': 'Foto profil berhasil diupload',
      'image_url': 'https://example.com/uploads/profile_${userId}_${DateTime.now().millisecondsSinceEpoch}.jpg'
    };
  }
}
